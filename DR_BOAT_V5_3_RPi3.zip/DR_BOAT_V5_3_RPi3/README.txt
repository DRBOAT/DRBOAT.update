DR.BOAT V5.3 — Raspberry Pi 3 / OpenPlotter

V5.3 maneuver-simulator update highlights
- Choose 1, 2, 3 or 4 active tugs for each maneuver.
- Any tug can be assigned to any of six working stations.
- Each tug has three operating modes: STOP/FOLLOW, PULL and PUSH.
- PULL orders: Tight Line, Slow Tight Line, Half Tight Line, Full Tight Line.
- PUSH orders: Lean On, Mini Push, Slow Push, Half Power Push, Full Power Push.
- Tug clock position is relative to vessel heading: 12 o'clock is dead ahead.
- Center Lead Bow stays ahead of the bow fairlead and follows the vessel dynamically.
- Center Lead Aft follows the aft fairlead dynamically.
- STOP/FOLLOW keeps the tug in relative position without force on the target vessel.
- Tug forces generate vessel translation and rotation with damping/inertia.
- Simplified solid-quay collision boundaries stop the vessel passing through training berths.
- Live HDG, SOG and ROT are shown on the maneuver chart.
- Vessel movement is deliberately slower for training.
- Long station labels were removed from the chart; small securing-point markers remain.
- Larger training map with wheel zoom, mouse drag pan and double-click view reset.
- Current control is mouse-based; action/station structure is kept ready for future voice-command mapping.

Important
This is a simplified training simulator and is NOT a certified ship-handling model or navigation system.
The Mina Zayed-style background is a training representation only and is NOT FOR NAVIGATION.
