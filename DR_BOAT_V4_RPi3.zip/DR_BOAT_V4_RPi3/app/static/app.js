
const statuses = [
  ["KVH Heading Sensor", true],
  ["GNSS Receiver", true],
  ["FiFi Monitor Control", true],
  ["FiFi Pump Control", true],
  ["Hydraulic Steering Controller", true],
  ["Engine Control Unit", true],
  ["Line Release 1", true],
  ["Line Release 2", true],
  ["LiDAR", true],
  ["Camera", true],
  ["4G / 5G Modem", true],
  ["Starlink", false],
  ["Signal K", true],
  ["OpenCPN Link", true]
];

function renderStatus(){
  const root = document.getElementById("statusList");
  root.innerHTML = statuses.map(([n,on]) =>
    `<div class="status-item"><span><i class="dot ${on?'on':'off'}"></i>${n}</span><b class="${on?'ok':''}">${on?'CONNECTED':'OFFLINE'}</b></div>`
  ).join("");
}
renderStatus();

document.getElementById("connectionsBtn").onclick = ()=>document.getElementById("statusDrawer").classList.add("open");
document.getElementById("closeDrawer").onclick = ()=>document.getElementById("statusDrawer").classList.remove("open");

document.getElementById("openCpnBtn").onclick = async ()=>{
  try{
    const r = await fetch("/api/opencpn",{method:"POST"});
    const j = await r.json();
    if(!j.ok) alert("OpenCPN could not be launched: "+(j.error||"unknown error"));
  }catch(e){ alert("OpenCPN launch request failed.");}
};

function setPump(on){
  const el = document.getElementById("pumpState");
  el.textContent = on ? "ON" : "OFF";
  el.style.color = on ? "#40e095" : "#ff5f6d";
}
function setFireAngle(v){
  document.getElementById("fireAngleValue").textContent = String(v).padStart(3,"0");
  document.getElementById("fireNeedle").style.transform = `rotate(${v}deg)`;
}
function updateThrottle(v){
  v = Number(v);
  let mode = "NEUTRAL";
  if(v>0) mode="AHEAD";
  if(v<0) mode="ASTERN";
  document.getElementById("throttleMode").textContent = mode;
  document.getElementById("throttlePct").textContent = `${Math.abs(v)}%`;
  const rpm = Math.round(Math.abs(v) * 32);
  document.getElementById("e1rpm").textContent = rpm;
  document.getElementById("e2rpm").textContent = rpm;
  const lph = (Math.abs(v)*0.62).toFixed(1);
  document.getElementById("e1fuel").textContent = `${lph} L/h`;
  document.getElementById("e2fuel").textContent = `${lph} L/h`;
}
function setRudder(v){
  v = Number(v);
  document.getElementById("rudderPointer").style.transform = `rotate(${v}deg)`;
  let text = "MIDSHIP 0°";
  if(v<0) text = `PORT ${Math.abs(v)}°`;
  if(v>0) text = `STARBOARD ${v}°`;
  document.getElementById("rudderValue").textContent = text;
}
function lineAction(which, secure){
  const state = document.getElementById(which+"State");
  const line = document.getElementById(which+"Line");
  state.textContent = secure ? "SECURE" : "RELEASED";
  state.style.color = secure ? "#40e095" : "#ffc857";
  line.classList.toggle("detached", !secure);
}
