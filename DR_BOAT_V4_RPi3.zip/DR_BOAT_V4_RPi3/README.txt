DOCTOR BOAT CONTROL MARINE INTELLIGENCE V4
Raspberry Pi 3 lightweight shore-control build

INSTALL
1) Extract DR_BOAT_V4_RPi3.zip
2) Open Terminal in the extracted folder
3) Run:
   chmod +x install.sh
   ./install.sh
4) Double-click the new desktop icon:
   Doctor Boat Control Marine Intelligence V4

NOTES
- V3 is NOT deleted or modified.
- V4 uses only Python 3 standard library for the local server.
- Panels are resizable with the drag handle at the lower-right corner.
- OpenCPN button asks the OS to launch the installed `opencpn` application.
- Live camera, sensors, engine hours, fuel consumption, LiDAR returns and control outputs are currently UI/simulation placeholders until real hardware endpoints are connected.
- The update script reads:
  https://raw.githubusercontent.com/DRBOAT/DRBOAT.update/main/version.json
