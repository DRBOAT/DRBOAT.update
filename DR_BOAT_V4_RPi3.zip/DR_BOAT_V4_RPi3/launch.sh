#!/usr/bin/env bash
set -e
APP_DIR="$HOME/doctor_boat_v4/app"
cd "$APP_DIR"
pkill -f "server.py" 2>/dev/null || true
nohup python3 "$APP_DIR/server.py" >/tmp/doctor_boat_v4.log 2>&1 &
sleep 1
python3 - <<'PY'
import webbrowser
webbrowser.open("http://127.0.0.1:8765/index.html")
PY
