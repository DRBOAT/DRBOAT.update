#!/usr/bin/env bash
set -e
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/doctor_boat_v4"
DESKTOP="$HOME/Desktop"
mkdir -p "$DEST" "$DESKTOP"

# Preserve existing V3; only replace V4.
rm -rf "$DEST/app"
cp -a "$SRC_DIR/app" "$DEST/"
cp "$SRC_DIR/launch.sh" "$DEST/launch.sh"
cp "$SRC_DIR/update.sh" "$DEST/update.sh"
cp "$SRC_DIR/VERSION" "$DEST/VERSION"
chmod +x "$DEST/launch.sh" "$DEST/update.sh" "$DEST/app/server.py"

cat > "$DESKTOP/Doctor Boat Control Marine Intelligence V4.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Doctor Boat Control Marine Intelligence V4
Comment=Doctor Boat shore control station
Exec=$DEST/launch.sh
Icon=applications-engineering
Terminal=false
Categories=Utility;
EOF
chmod +x "$DESKTOP/Doctor Boat Control Marine Intelligence V4.desktop"

echo "DONE."
echo "V4 installed at: $DEST"
echo "V3 was not modified."
echo "Double-click: Doctor Boat Control Marine Intelligence V4"
