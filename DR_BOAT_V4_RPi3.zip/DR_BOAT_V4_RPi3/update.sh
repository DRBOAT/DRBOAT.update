#!/usr/bin/env bash
set -e
VERSION_URL="https://raw.githubusercontent.com/DRBOAT/DRBOAT.update/main/version.json"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

python3 - "$VERSION_URL" "$TMP" <<'PY'
import sys, json, urllib.request, hashlib, pathlib, zipfile, subprocess, shutil, os
version_url, tmp = sys.argv[1], pathlib.Path(sys.argv[2])
with urllib.request.urlopen(version_url, timeout=20) as r:
    meta=json.load(r)
url=meta["package_url"]
want=meta["sha256"].lower()
zip_path=tmp/"update.zip"
with urllib.request.urlopen(url, timeout=60) as r, open(zip_path,"wb") as f:
    shutil.copyfileobj(r,f)
got=hashlib.sha256(zip_path.read_bytes()).hexdigest()
if got != want:
    raise SystemExit(f"SHA256 mismatch: expected {want}, got {got}")
with zipfile.ZipFile(zip_path) as z:
    z.extractall(tmp/"pkg")
root = next((p for p in (tmp/"pkg").iterdir() if p.is_dir()), tmp/"pkg")
subprocess.check_call(["bash", str(root/"install.sh")])
print("UPDATE COMPLETE:", meta["version"])
PY
