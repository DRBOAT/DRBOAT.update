DR.BOAT V3.2 — Raspberry Pi 3

Implemented:
- FLEET LIST with all 15 requested vessels.
- ASD vs Conventional vessel presentation.
- OpenCPN GPX markers at exact supplied coordinates:
  M/T SEMAIH 24.5260413, 54.3779452
  M/T AL FANCI 24.5268661, 54.3791750
  JAWAD 1 24.4664698, 54.6087392
- Camera focus no longer moves the native OpenCPN window. It uses a live OpenCPN mini snapshot to avoid toolbars escaping to the desktop.
- Command Center compressed to fit map, cameras and both tug telemetry/thruster panels on one screen.
- Engine 1, Engine 2, Generator 1 and Generator 2 fuel-rate fields in L/h.
- Maneuver fuel integration in liters.
- Maneuver Library total fuel plus provisional training performance score.
- JAWAD 1 dedicated FiFi / Fire Fighting UI plus Conventional propulsion presentation.
- Real propulsion and FiFi outputs remain disabled until real gateway and independent safety hardware are integrated.

OpenCPN static marker test:
Press LOAD TEST VESSEL MARKERS after OpenCPN is running.
