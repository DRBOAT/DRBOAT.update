#!/bin/bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
APPDIR="$HOME/.local/share/drboat"
BINDIR="$HOME/.local/bin"
DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
[ -z "$DESKTOP_DIR" ] && DESKTOP_DIR="$HOME/Desktop"
LAUNCHER="$BINDIR/drboat"
DESKTOP_FILE="$DESKTOP_DIR/DR-BOAT.desktop"
echo "Installing DR.BOAT V3.2 for Raspberry Pi 3..."
if [ -f /etc/apt/sources.list.d/openplotterNodejs.list ] && grep -q "node_18" /etc/apt/sources.list.d/openplotterNodejs.list; then
  sudo mv /etc/apt/sources.list.d/openplotterNodejs.list /etc/apt/sources.list.d/openplotterNodejs.list.disabled || true
fi
sudo apt-get update
sudo apt-get install -y python3 python3-pyqt5 xdotool
mkdir -p "$BINDIR" "$DESKTOP_DIR"
TMPDATA=""
if [ -d "$APPDIR/data/missions" ]; then TMPDATA="$(mktemp -d)"; cp -a "$APPDIR/data/missions" "$TMPDATA/"; fi
BACKUP="$HOME/.local/share/drboat-v3-backup"
rm -rf "$BACKUP"
if [ -d "$APPDIR" ]; then cp -a "$APPDIR" "$BACKUP"; fi
rm -rf "$APPDIR"; mkdir -p "$APPDIR"; cp -a "$SRC/." "$APPDIR/"
if [ -n "$TMPDATA" ] && [ -d "$TMPDATA/missions" ]; then mkdir -p "$APPDIR/data"; rm -rf "$APPDIR/data/missions"; cp -a "$TMPDATA/missions" "$APPDIR/data/"; rm -rf "$TMPDATA"; fi
cat > "$LAUNCHER" <<EOF
#!/bin/bash
cd "$APPDIR"
exec python3 "$APPDIR/main.py"
EOF
chmod +x "$LAUNCHER"
cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=DR.BOAT V3.2
Comment=Intelligent Marine Control, Training and AI Center
Exec=$LAUNCHER
Icon=$APPDIR/static/drboat_logo.png
Terminal=false
Categories=Utility;
StartupNotify=true
EOF
chmod +x "$DESKTOP_FILE"
gio set "$DESKTOP_FILE" metadata::trusted true >/dev/null 2>&1 || true
echo "DONE."
echo "DR.BOAT V3.2 installed."
