DR.BOAT V5 — Raspberry Pi 3

V5 HIGHLIGHTS
- Built directly from the confirmed working V4 Raspberry Pi copy.
- JAWAD 1 removed from Command Center/header and placed inside Fleet List only.
- Exact 15-vessel Fleet List restored from V3.1/V3.2 data.
- Double-click JAWAD 1 in Fleet List to open dedicated control.
- JAWAD 1 twin engine levers (Port / Starboard).
- Pilot & Tug Master Training Simulator restored.
- Mina Zayed chart-style training scene with slower target-vessel movement.
- Container, bulk, tanker, general cargo and jack-up barge training targets.
- Four tug allocation with six correct securing points:
  Center Lead Bow, Center Lead Aft, Starboard Bow, Starboard Quarter, Port Bow, Port Quarter.
- Tugs move toward the selected securing point instead of all lines going to vessel centre.
- Existing OpenCPN, camera, telemetry, FiFi, LiDAR, line-release, logging and update framework retained.

SAFETY
This V5 package is a training/control-interface prototype. Real propulsion, steering, FiFi and line-release commands require independently engineered hardware safety layers, feedback and emergency-stop circuits.
