#!/usr/bin/env python3
import sys, json
from pathlib import Path
try:
    from osgeo import ogr
except Exception as e:
    print('python3-gdal / osgeo is required: '+str(e), file=sys.stderr); sys.exit(2)
if len(sys.argv)!=3:
    print('usage: s57_extract.py INPUT.000 OUTPUT.geojson', file=sys.stderr); sys.exit(2)
src,out=sys.argv[1],Path(sys.argv[2])
# S57_OPTIONS asks GDAL to expose useful primitives when available.
ds=ogr.Open(src,0)
if ds is None:
    print('GDAL could not open S-57 dataset: '+src,file=sys.stderr); sys.exit(3)
features=[]
for li in range(ds.GetLayerCount()):
    layer=ds.GetLayerByIndex(li); lname=layer.GetName()
    layer.ResetReading()
    for feat in layer:
        geom=feat.GetGeometryRef()
        if geom is None: continue
        try: gj=json.loads(geom.ExportToJson())
        except Exception: continue
        props={'_s57_layer':lname}
        defn=feat.GetDefnRef()
        for i in range(defn.GetFieldCount()):
            fd=defn.GetFieldDefn(i); name=fd.GetName()
            try: val=feat.GetField(i)
            except Exception: val=None
            if val is not None: props[name]=val
        features.append({'type':'Feature','geometry':gj,'properties':props})
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({'type':'FeatureCollection','features':features},separators=(',',':')))
print(f'{len(features)} features from {ds.GetLayerCount()} layers')
