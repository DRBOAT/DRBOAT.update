#!/bin/bash
set -e
APPDIR="$HOME/.local/share/drboat"
BACKUP="$HOME/.local/share/drboat-v2-backup"
if [ ! -d "$BACKUP" ]; then
  echo "No V2.3 backup found."
  exit 1
fi
TMPDATA=""
if [ -d "$APPDIR/data" ]; then
  TMPDATA="$(mktemp -d)"
  cp -a "$APPDIR/data" "$TMPDATA/"
fi
rm -rf "$APPDIR"
cp -a "$BACKUP" "$APPDIR"
if [ -n "$TMPDATA" ] && [ -d "$TMPDATA/data" ]; then
  rm -rf "$APPDIR/data"
  cp -a "$TMPDATA/data" "$APPDIR/data"
  rm -rf "$TMPDATA"
fi
echo "Rollback complete. DR.BOAT V2.3 restored."
