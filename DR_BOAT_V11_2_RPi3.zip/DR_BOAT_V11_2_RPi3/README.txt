DR.BOAT V5.3 — Raspberry Pi 3 / OpenPlotter

V5.3 maneuver-simulator update highlights
- Choose 1, 2, 3 or 4 active tugs for each maneuver.
- Any tug can be assigned to any of six working stations.
- Each tug has three operating modes: STOP/FOLLOW, PULL and PUSH.
- PULL orders: Tight Line, Slow Tight Line, Half Tight Line, Full Tight Line.
- PUSH orders: Lean On, Mini Push, Slow Push, Half Power Push, Full Power Push.
- Tug clock position is relative to vessel heading: 12 o'clock is dead ahead.
- Center Lead Bow stays ahead of the bow fairlead and follows the vessel dynamically.
- Center Lead Aft follows the aft fairlead dynamically.
- STOP/FOLLOW keeps the tug in relative position without force on the target vessel.
- Tug forces generate vessel translation and rotation with damping/inertia.
- Simplified solid-quay collision boundaries stop the vessel passing through training berths.
- Live HDG, SOG and ROT are shown on the maneuver chart.
- Vessel movement is deliberately slower for training.
- Long station labels were removed from the chart; small securing-point markers remain.
- Larger training map with wheel zoom, mouse drag pan and double-click view reset.
- Current control is mouse-based; action/station structure is kept ready for future voice-command mapping.

Important
This is a simplified training simulator and is NOT a certified ship-handling model or navigation system.
The Mina Zayed-style background is a training representation only and is NOT FOR NAVIGATION.

=== V5.4 UPDATE ===
- Full Ahead own-ship reference speed tuned to approximately 10 kn in the training model.
- Compact ship propulsion and rudder controls moved onto the chart at the lower-right.
- Tug approach/clock response increased significantly.
- PULL and PUSH force response strengthened with progressive power levels.
- Side PUSH tugs now approach the hull/fender contact position before force is applied.
- START MANEUVER now opens a pre-maneuver technical Bollard Pull Assessment.
- Assessment assumes 50,000 t displacement and 50 t bollard pull per selected tug in this phase.
- Assessment shows vessel reference dimensions, windage area, underwater lateral area, wind/current forces, available BP, required BP and margin.
- Reference calculation uses drag-force form F = 0.5*rho*Cd*A*V^2 with a 20% operating margin.
- Training assessment only: not a certified or port-approved towage plan.
- Desktop launcher generation now points to the stable ~/.local/bin/drboat launcher to prevent repeat double-click failures.

=== V5.5 UPDATE — DOCTOR BOAT AI POSITIONING SYSTEM ===
- New top-level dashboard: DOCTOR BOAT AI POSITIONING SYSTEM.
- Independent metric UTM grid display inside DR.BOAT; OpenCPN is not required to open this page.
- Add Chart Directory selector for local marine-chart folders on Raspberry Pi.
- Chart index recognizes common OpenCPN chart-file families including BSB/KAP, S-57/ENC, MBTiles/SQLite and raster files.
- UTM own-ship display includes Zone, Easting, Northing and Heading.
- Position source cards: GNSS, IMU, INS, Log Speed, LiDAR, Vision, Radar and AI Positioning System.
- GNSS panel explicitly identifies GPS, Galileo, GLONASS and BeiDou.
- Final Position panel prepared for Easting, Northing, Lat/Lon, Heading, Speed, Confidence and active source.
- Chart-directory choice is stored in data/positioning_settings.json.
- Architecture is prepared for future physical-sensor feeds and sensor-fusion logic.

Chart renderer status
V5.5 indexes native OpenCPN chart directories without launching OpenCPN. The UTM display is fully independent.
Native decoding/drawing of encrypted/proprietary or vector BSB/S-57 chart content is not bundled in this dependency-light Raspberry Pi 3 build yet; the chart-file selection/API is in place for the next decoder integration step.

V5.6 POSITIONING UPDATE
- DR Boat AI Positioning System naming
- Larger map and compact sensor panel
- Zoom controls and mouse-wheel zoom
- Heading + speed on map
- Measure Distance: metres, NM and bearing
- Draw Route with sequential waypoints, leg summary and Route History
- Track recording and Track History
- Working WGS84 UTM to Latitude/Longitude conversion
- Maximize map mode
- CM93 directory detection/indexing

V6.0 VECTOR CHART UPDATE
- Built-in DR Boat Vector Chart Manager
- Native GeoJSON vector chart rendering on the UTM map
- S-57 ENC (.000/.001/.002/.s57/.enc) support through GDAL/ogr2ogr
- V6 installer installs gdal-bin automatically
- S-57 is converted locally to a cached GeoJSON layer and displayed inside DR Boat
- CM93 databases are detected and indexed; no false rendering claim is made because CM93 needs a dedicated decoder
- Route, Track, Measure Distance, vessel symbol and UTM grid remain overlaid above vector charts
- Existing positioning settings, route history and track history are preserved during V6 install


V7.0 FIRST-VECTOR-CHART UPDATE
- Actual S-57 extraction uses Python GDAL (python3-gdal), iterating every S-57 layer and rendering the resulting vector features inside DR Boat.
- Chart Manager now has LOAD SELECTED CHART and double-click loading.
- Pan by dragging the map in PAN mode; mouse wheel or buttons zoom.
- FIT CHART centers and fits the loaded vector chart.
- Built-in DR Boat demo vector chart proves the renderer immediately; it is explicitly TEST ONLY / NOT FOR NAVIGATION.
- CM93 remains detected/indexed but is not falsely claimed as decoded.

V7.1 WORLD BASE MAP
- Built-in lightweight world land/sea orientation map
- WORLD MAP button loads the base map instantly without downloading chart data
- Base map is explicitly marked NOT FOR NAVIGATION
- S-57 ENC remains the supported real vector nautical chart path
- CM93 remains detected/indexed but requires a dedicated decoder

V8.0 S-57 ENC ENGINE
- Real S-57 datasource inspection with ogrinfo
- Exports all discovered S-57 object-class layers with ogr2ogr
- Merges exported layers into the DR Boat vector renderer
- Common DEPARE/DRGARE/LNDARE/BUAARE/COALNE layers get basic maritime-style portrayal
- Existing Zoom/Pan/Fit/UTM/Route/Track overlays remain active
- Built-in world orientation map remains available
- CM93 is still detected/indexed only; a dedicated decoder is still required
IMPORTANT: DR Boat V8 is a research/prototype display, not type-approved ECDIS and not a substitute for official carriage equipment.

V8.1 HOTFIX
- Fixed startup crash: PositioningSystemPage.load_demo_chart is now implemented.
- Added/validated load_chart_path for real S-57 and GeoJSON loading.
- Demo vector loads and fits automatically.
- Installer now stages its own files before replacing ~/.local/share/drboat, preventing self-deletion during in-place updates.

V8.2 REAL WORLD VECTOR BASE MAP
- Replaced the old schematic world outline with real Natural Earth vector country/land geometry.
- World vector base map loads automatically when AI Positioning System opens.
- Global map supports mouse-wheel zoom, drag pan, right-click Lat/Lon + UTM coordinates.
- Global UTM zone grid is overlaid on the world vector map.
- Loading an S-57 ENC switches to the local meter-based UTM navigation/chart view.
- Existing S-57 renderer remains available as the real nautical vector overlay path.
- CM93 database remains detected/indexed; its dedicated decoder/renderer is the next separate stage.
- Prototype/research display only; not a type-approved ECDIS.

V8.3 LAYERED NAVIGATION MAP UPDATE
----------------------------------
- Permanent Natural Earth world vector base map remains behind all loaded charts.
- S-57 ENC .000 cells and GeoJSON load as georeferenced overlays; they no longer replace the world map.
- Loading an ENC fits the view to the ENC coverage WITHOUT moving the DR BOAT vessel position.
- Default no-GNSS vessel start position is fixed at Mina Zayed, Abu Dhabi.
- Navigation vessel is no longer driven by fleet/training simulator data.
- New RECENTER control restores vessel-follow after manual map drag.
- Manual drag turns follow OFF; RECENTER turns follow ON and centers the current vessel position.
- Three navigation orientations: NORTH UP, HEAD UP and COURSE UP.
- UTM grid remains a geographic/map layer; local metre grid is shown at useful local zooms.
- GNSS adapter hook apply_gnss_fix(lat, lon, heading, speed, course) is ready for later receiver integration.
- S-57 update cells .001/.002/... are hidden from Chart Manager and are not loadable as standalone charts.
- Chart Manager title now follows the actual installed version.
- Only one Doctor Boat desktop launcher is maintained by the installer.
- Existing chart directory, chart cache, routes, tracks and mission data are preserved during update.

IMPORTANT
---------
V8.3 is a research/prototype navigation display, not a type-approved ECDIS. S-57 portrayal is an evolving
DR BOAT renderer and is not yet full IHO S-52 presentation. S-63 encrypted/licensed ENC decryption is not included.
CM93 remains detection/indexing only.


=== V8.4 PROFESSIONAL MAP / LIVE GNSS UPDATE ===
- New compact "C" professional map-toolbar layout with reduced button footprint.
- Narrow right-side map tool rail for zoom, recenter, view modes, measure, route, track and pan.
- Dense local UTM metre-grid removed completely; only low-zoom UTM-zone reference remains.
- OpenCPN-inspired own-ship silhouette replaces the old triangle.
- Own ship is light when GNSS is live and red when GNSS is lost.
- GNSS timeout: 3 seconds without valid RMC changes status to GNSS LOST.
- Built-in UDP NMEA0183 receiver on port 10110 for iPhone/external GNSS.
- Reads RMC position/speed/course, GGA satellites/HDOP, and HDT heading when supplied.
- Track is rendered in yellow.
- Map layer selector: VECTOR / SATELLITE / HYBRID / MARINE.
- SATELLITE uses Esri World Imagery as an optional online reference layer.
- HYBRID uses Esri imagery plus OpenSeaMap seamark overlay.
- MARINE uses OpenStreetMap base plus OpenSeaMap seamarks.
- Online tile layers require internet and are cached locally for performance; provider terms/attribution apply.
- Online/reference layers are NOT official ENC and are NOT a substitute for type-approved ECDIS.
- Existing S-57/GeoJSON ENC overlay and local chart directory support remain available.
- CM93 native decoding and S-63 licensing/decryption remain unsupported.

=== V8.5 PROFESSIONAL NAVIGATION OPERATIONS UPDATE ===
- Command Center now uses the built-in DR BOAT map engine instead of the embedded OpenCPN map panel.
- Command Center map can switch VECTOR / SATELLITE / HYBRID / MARINE.
- AIS is a map overlay independent of map background. Local single-fragment AIS NMEA position reports (AIVDM/AIVDO message types 1/2/3/18) are decoded from UDP 10110 and shown as targets.
- Double-click AIS target for MMSI, position, SOG, COG, heading, age, CPA and TCPA.
- Fleet layer is separate from AIS and accepts real fleet positions only; no invented operational coordinates are generated.
- Voyage Dashboard opens after route completion with voyage name, total distance, planned speed, duration, ETA and per-leg table.
- Planned speed can be changed live to recalculate ETA and leg times.
- Route waypoints can be dragged with the mouse after route creation; geometry updates immediately.
- Route / Voyage Library supports Open/Edit, Rename, Duplicate and Delete.
- Track recorder stores named track, duration, distance and average speed; Track History can reopen/hide/delete recorded tracks.
- Marine/User Marks can be placed on the map, dragged, saved, edited and deleted. Double-click shows Lat/Lon and UTM details.
- Operational layers (AIS, Fleet, Routes, Tracks, Marine Marks) remain independent from the selected map background.
- V8.4 startup regression caused by the missing _refresh_final_labels method is corrected in this source.

SAFETY: Research/prototype navigation software. Not type-approved ECDIS and not a substitute for official charts, approved AIS/ECDIS equipment, bridge procedures or COLREG-compliant watchkeeping.

============================================================
V9.2.0 NAVIGATION WORKSTATION UPDATE
============================================================
- Active Route by right-click on a route: Activate / Deactivate / Follow / Reverse / Properties.
- Active route changes to red and enables a live bottom navigation strip.
- Live navigation strip: next waypoint, DTW, BTW, XTE, actual SOG, TTG and ETA.
- ETA during active navigation uses actual GNSS SOG; voyage-planning dashboard retains editable planned speed.
- True application full-screen navigation mode: hides DR BOAT header/nav/tool panels and exits with Esc.
- Display palettes: DAY / DUSK / NIGHT / NIGHT RED.
- Heading update is applied at incoming HDT rate rather than waiting for the next RMC position sentence.
- Professional own-ship symbol, optional heading time-vector, Range Rings and EBL/VRM.
- LiDAR 360-degree simulation layer centered on own ship; default simulated range 200 m. The UI is designed so the simulation source can later be replaced by a real LiDAR adapter.
- AI NAV foundation panel: Observe -> Analyze -> Prepare Decision -> Execute architecture. Advisory only in V9.2.
- Autopilot heading-hold/calibration foundation panel. V9.2 DOES NOT output commands to a motor controller or steering pump.
- Safety tools: MOB mark, anchor-radius watch, compact alert strip.
- AIS CPA/TCPA warning can surface in the compact alert strip when live AIS targets are available.
- Existing V8.5 features retained: DR BOAT map in Command Center, route/track libraries, draggable waypoints, marine marks, fleet layer, local AIS parsing, satellite/hybrid/marine layers, GNSS UDP 10110.

SAFETY / DEVELOPMENT STATUS
This remains a research/prototype navigation display and is not a type-approved ECDIS, INS, radar, AIS display, autopilot or collision-avoidance system. AI NAV and AUTOPILOT in V9.2 are interface/simulation foundations only. No physical steering output is enabled by this release.

V9.2.0 HOTFIX
- Full-screen exit hardened: EXIT FULL button, application-wide Esc and F11, plus MainWindow fallback.

V9.2 TRAINING SIMULATOR UPDATE
- Simulator title now follows APP_VERSION.
- Compact HDG/SOG/ROT telemetry strip.
- Mina Zayed fixed training reference map with SATELLITE / HYBRID / MARINE modes (online reference tiles; not official ENC).
- More realistic top-view vessel/tug training symbols retained and refined from V9.
- Tug proceed-to-secure approach slowed to a more plausible training animation.
- Whole-simulation time acceleration x1..x5.
- Ship engine-order ladder: STOP, Dead Slow, Minimum, Half, Full Ahead/Astern with gradual inertia.
- Editable live bollard-pull assessment: displacement, wind, current, safety factor, BP per tug; immediate sufficiency warning.
- Voice Orders UI and command parser foundation; mouse controls remain available. Real microphone speech-to-text requires microphone/STT integration.
- Full-screen V9.0.1 escape hotfix retained.

V9.2.0 TRAINING SIMULATOR UPDATE
- Clean training launcher: port, target vessel, tug count, Start Maneuver.
- Mina Zayed chart camera now pans/zooms with all simulator geometry in one transform.
- Lightweight animated sea texture.
- Quay collision layer retained; vessel cannot visually pass through configured quay boundaries.
- Compact vertical HDG/SOG/ROT panel at upper left.
- SIM SPEED is one compact cycle button x1..x5.
- Tug clock command changed from long slider to compact notched dial.
- Exact project securing terms retained: CENTER LEAD BOW, CENTER LEAD AFT, PORT/STARBOARD BOW, PORT/STARBOARD QUARTER.
- Tug proceed-to-secure movement slowed for more realistic training approach.
- Pivot-point visual reference shifts with ahead/astern command.
- Wind area and underwater area are editable in the pre-maneuver calculator.
- NOTE: Official berth-number geometry is not fabricated. AD Ports confirms 21 berths at Zayed Port; exact berth polygons/numbers require authoritative chart/port data before they are used in the simulator.


V9.3.0 TRAINING SIMULATOR SCALE / TUG-LEAD UPDATE
- Vessel and tug drawings now use real LOA/beam reference dimensions converted to the Mina Zayed chart scale instead of fixed large pixel sprites.
- Towline attachment points are on the vessel hull border; the old external yellow securing dots are removed.
- Fixed lead clock sectors are enforced: CENTER LEAD BOW 7,8,9,10,11,12,1,2,3,4,5; CENTER LEAD AFT 3..9; STARBOARD BOW 12..5; STARBOARD QUARTER 11,12,1..6; PORT BOW 12,11..6; PORT QUARTER 11..6.
- Invalid clock commands snap to a permitted hour and cannot be applied to tug motion.
- Compact right control rail with duplicate simulator/version/target-vessel explanatory text removed.
- Subtle vessel/tug wake traces and live sea texture retained for Raspberry Pi 3 performance.
- Start geometry moved to the channel centre reference with the vessel heading inbound.
- Existing zoom/pan, x1..x5 simulation time, bollard-pull calculator, pivot point, voice-order foundation and gradual vessel/tug motion retained.
- Quay collision remains a training geometry approximation in this build. Exact official Mina Zayed berth polygons/numbers are NOT fabricated and require an authoritative berth/ENC geometry source before being labelled as exact.


V9.4.0 CLEAN SIMULATOR RENDERER
- Rebuilt training scene presentation around the live map rather than legacy debug graphics.
- Initial vessel reference moved into the water/channel training area; exact Z15 coordinate remains pending authoritative chart geometry.
- Base training tiles use z15 and LOA/beam-to-pixel conversion follows that geographic scale.
- Removed visible legacy red/green/yellow marker field, cyan channel debug line, temporary quay debug rectangles and pivot debug dot.
- Towlines terminate directly on the target hull border; no external securing-point dots are drawn.
- Tug stand-off increased so tug hulls remain outside the target hull during proceed-to-secure.
- Six lead clock sectors remain fixed; the clock dial now exposes only the permitted hours for the selected lead.
- Compact right rail and ship control; duplicate tug-count controls removed from the simulator view.
- Subtle wake/sea effects retained for Raspberry Pi 3.
- Collision geometry remains a training approximation until authoritative Mina Zayed berth/quay geometry is available.

V10.0 TRAINING VECTOR UPDATE
- Pilot & Tug Master Training Simulator now uses a simulator-only native vector base renderer; AI Positioning System mapping remains unchanged.
- Training start reference: LAT 24.5472670 / LON 54.3818479, initial heading 157.0 degrees, FULL AHEAD order on Start Maneuver.
- Tug waiting formation is staged astern before PROCEED TO SECURE; 1-4 tugs are arranged across the channel reference formation according to selected count.
- Prop-wash/wake graphics are disabled pending a better effect.
- Bollard Pull calculator wind/current operator inputs are knots; calculations convert knots to m/s internally before the drag equations.
- Command Center opens on HYBRID and no vessel is selected automatically.
- Main application opens maximized.
- MEASURE and EBL/VRM are toggle tools. ROUTE drawing exits on final double-click; right-click route includes immediate DELETE ROUTE; double-click an existing route opens properties.
- IMPORTANT: the V10 vector training shoreline is a clean simulator geometry framework. Exact official berth faces, channel limits, Z25/Z26/Z27/Z28 buoy coordinates and collision polygons are NOT claimed as surveyed/official until authoritative coordinates/chart geometry are loaded. No official geometry has been fabricated.

V10.2.0 · DR POSITION CALCULATOR
- Added dedicated ◎ DR POS CALC button beside AUTO in DR BOAT AI POSITIONING SYSTEM.
- Live dashboard uses own-ship UTM from the same GNSS state as the Positioning System.
- Four editable fixed UTM targets A/B/C/D can be rebuilt 500 m around the current GNSS vessel position.
- Target coordinates, ranges, true bearings, pair angles and full target-distance matrix recalculate live.
- Live geometry mode displays the GNSS vessel position as the reference solution.
- Manual Angle Solver accepts horizontal angles A-B and D-C and numerically solves their two-locus intersection near the current vessel position.
- TRUE HEADING reads HDT/KVH/IMU adapter data and updates independently at heading-message rate.
- SPEED THROUGH WATER is displayed in m/s. NMEA VHW is parsed when present; a public apply_speed_through_water(m/s) hook is available for the physical speed log. It deliberately shows WAITING rather than substituting GNSS SOG when no water-speed source is connected.
- UTM zone follows the live vessel/GNSS position (Abu Dhabi normally Zone 40N); no hard-coded Zone 36N.

V11.0 — DR POSITION CALCULATOR DYNAMIC GRID RESEARCH UPDATE
- Calculated vessel position now has UTM plus calculated Latitude/Longitude and a dedicated pan/zoom mini-map.
- Dynamic local reference grids: default 500 m target radius, next grid auto-created at configurable 80% threshold in direction of travel.
- Historical grids are retained and drawn for post-run analysis; calculated DR track and GNSS comparison track are retained.
- GNSS can be excluded from the calculation while still logged as an independent comparison reference.
- Speed source selector: NMEA STW / Speed Log, OBD-II USB vehicle speed, or manual test speed.
- ELM327-compatible OBD-II USB polling uses standard PID 01 0D vehicle speed when available; default Linux port /dev/ttyUSB0.
- Session log saves grids, calculated track, GNSS reference track and timestamps to data/dr_sessions.
- IMPORTANT ENGINEERING LIMITATION: generated grids are virtual computational reference frames. Creating a new grid does NOT add an independent physical position observation and therefore does not, by itself, remove IMU/speed-sensor dead-reckoning drift. GNSS or another external observation remains required to bound absolute-position error.


V11.1: Fixed DR Position Calculator centre-map layout on Raspberry Pi displays. The live UTM grid map now remains visible between compact side panels, retains all historical grids, shows active grid, calculated track and optional GNSS reference, with mouse-wheel zoom and drag pan.
