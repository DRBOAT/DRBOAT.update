
import os, sys, json, math, time, shutil, hashlib, zipfile, tempfile, subprocess, urllib.request
from pathlib import Path
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QPixmap, QPainter, QPen, QColor, QFont, QWindow
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QGridLayout, QStackedWidget, QFrame, QMessageBox, QSplitter, QDialog, QListWidget,
    QListWidgetItem, QTextEdit, QLineEdit, QComboBox
)

APP_VERSION = "3.1.0"
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
MISSIONS_DIR = DATA_DIR / "missions"
FLEET_FILE = DATA_DIR / "fleet" / "fleet.json"
FLEET_GPX = DATA_DIR / "fleet" / "fleet_markers.gpx"
MISSIONS_DIR.mkdir(parents=True, exist_ok=True)
UPDATE_MANIFEST = "https://raw.githubusercontent.com/DRBOAT/DRBOAT.update/main/version.json"

def load_fleet():
    try:
        return json.loads(FLEET_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []

def version_tuple(v):
    vals=[]
    for p in str(v).split("."):
        digits="".join(ch for ch in p if ch.isdigit())
        vals.append(int(digits or 0))
    return tuple((vals+[0,0,0])[:3])

def mem_available_mb():
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1])//1024
    except Exception:
        pass
    return None

def cpu_temp_c():
    try:
        return int(Path("/sys/class/thermal/thermal_zone0/temp").read_text().strip())/1000.0
    except Exception:
        return None

def provisional_score(summary):
    rpm_var = summary.get("rpm_variation", 0.0)
    fuel_rate = summary.get("avg_total_fuel_lph", 0.0)
    thr_var = summary.get("thruster_variation", 0.0)
    smooth = max(0.0, 100.0 - min(70.0, rpm_var/15.0) - min(30.0, thr_var/6.0))
    fuel_component = max(0.0, 100.0 - min(100.0, fuel_rate/6.0))
    return round(0.65*smooth + 0.35*fuel_component, 1)

class DoubleClickLabel(QLabel):
    doubleClicked = pyqtSignal()
    def mouseDoubleClickEvent(self, event):
        self.doubleClicked.emit()
        super().mouseDoubleClickEvent(event)

class ThrusterGauge(QWidget):
    def __init__(self, title, mode="ASD", parent=None):
        super().__init__(parent)
        self.title=title; self.mode=mode; self.angle=0; self.rpm=0
        self.setMinimumSize(108,116); self.setMaximumHeight(125)
    def set_values(self, angle, rpm):
        self.angle=float(angle)%360; self.rpm=int(rpm); self.update()
    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w,h=self.width(),self.height()
        p.setPen(QColor("#dcebf2"))
        f=QFont(); f.setPointSize(8); f.setBold(True); p.setFont(f)
        p.drawText(0,0,w,16,Qt.AlignCenter,self.title)
        if self.mode=="ASD":
            cx,cy=w/2,58; radius=min(w,90)/2-7
            p.setPen(QPen(QColor("#4a8197"),2))
            p.drawEllipse(int(cx-radius),int(cy-radius),int(radius*2),int(radius*2))
            rad=math.radians(self.angle-90)
            ex=cx+math.cos(rad)*(radius-8); ey=cy+math.sin(rad)*(radius-8)
            p.setPen(QPen(QColor("#dcebf2"),5,Qt.SolidLine,Qt.RoundCap))
            p.drawLine(int(cx),int(cy),int(ex),int(ey))
            p.setPen(QColor("#9fc3d2")); f.setPointSize(7); f.setBold(False); p.setFont(f)
            p.drawText(0,93,w,13,Qt.AlignCenter,f"{int(self.angle)}°")
        else:
            p.setPen(QPen(QColor("#4a8197"),2))
            p.drawRoundedRect(15,32,w-30,36,8,8)
            center=w//2
            p.setPen(QPen(QColor("#dcebf2"),4))
            p.drawLine(center,37,center,63)
            direction = "AHEAD" if self.rpm>80 else "STOP"
            p.setPen(QColor("#9fc3d2")); f.setPointSize(7); p.setFont(f)
            p.drawText(0,74,w,15,Qt.AlignCenter,direction)
        p.setPen(QColor("#ffffff")); f.setPointSize(9); f.setBold(True); p.setFont(f)
        p.drawText(0,105,w,14,Qt.AlignCenter,f"{self.rpm} RPM")

class BoatStatusWidget(QFrame):
    logRequested=pyqtSignal(str)
    stopLogRequested=pyqtSignal(str)
    def __init__(self, boat_id, name, vessel_type="ASD", parent=None):
        super().__init__(parent)
        self.boat_id=boat_id; self.name=name; self.vessel_type=vessel_type; self.recording=False
        self.setObjectName("panel")
        layout=QVBoxLayout(self); layout.setContentsMargins(7,6,7,6); layout.setSpacing(4)
        title=QLabel(name); title.setObjectName("sectionTitle"); layout.addWidget(title)
        metrics=QHBoxLayout(); metrics.setSpacing(4)
        self.heading=QLabel("HDG\n0°"); self.battery=QLabel("BAT\n--%"); self.link=QLabel("LINK\n--%"); self.fuel=QLabel("FUEL\n-- L/h")
        for x in (self.heading,self.battery,self.link,self.fuel):
            x.setAlignment(Qt.AlignCenter); x.setObjectName("metric"); metrics.addWidget(x)
        layout.addLayout(metrics)
        thr=QHBoxLayout(); thr.setSpacing(1)
        self.port=ThrusterGauge("PORT", vessel_type); self.stbd=ThrusterGauge("STBD", vessel_type)
        thr.addWidget(self.port); thr.addWidget(self.stbd); layout.addLayout(thr)
        self.log_button=QPushButton(f"LOG MANEUVER · {name}")
        self.log_button.clicked.connect(self.toggle_log); layout.addWidget(self.log_button)
    def toggle_log(self):
        (self.stopLogRequested if self.recording else self.logRequested).emit(self.boat_id)
    def set_recording(self,on):
        self.recording=on
        self.log_button.setText(("STOP LOG · " if on else "LOG MANEUVER · ")+self.name)
        self.log_button.setObjectName("recordButton" if on else "")
        self.log_button.style().unpolish(self.log_button); self.log_button.style().polish(self.log_button)
    def set_values(self,b):
        self.heading.setText(f"HDG\n{int(b['heading'])}°")
        self.battery.setText(f"BAT\n{b['battery']}%")
        self.link.setText(f"LINK\n{b['link']}%")
        total = b.get("engine1_fuel_lph",0)+b.get("engine2_fuel_lph",0)+b.get("gen1_fuel_lph",0)+b.get("gen2_fuel_lph",0)
        self.fuel.setText(f"FUEL\n{total:.1f} L/h")
        self.port.set_values(b["port_angle"],b["port_rpm"]); self.stbd.set_values(b["stbd_angle"],b["stbd_rpm"])

class CameraPanel(DoubleClickLabel):
    def __init__(self, boat_name,parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter); self.setObjectName("camera")
        self.setText(f"{boat_name} · LIVE CAMERA\nDOUBLE CLICK")
        self.setMinimumHeight(128); self.setMaximumHeight(175)

class OpenCPNEmbedWidget(QFrame):
    def __init__(self,parent=None):
        super().__init__(parent); self.setObjectName("mapPanel")
        self.main_layout=QVBoxLayout(self); self.main_layout.setContentsMargins(6,5,6,5); self.main_layout.setSpacing(3)
        head=QHBoxLayout()
        t=QLabel("OPENCPN · LIVE MARINE CHART"); t.setObjectName("sectionTitle"); head.addWidget(t); head.addStretch()
        self.status=QLabel("NOT EMBEDDED"); self.status.setObjectName("smallStatus"); head.addWidget(self.status); self.main_layout.addLayout(head)
        self.placeholder=QLabel("OpenCPN will be embedded inside this panel.\nIts OpenCPN toolbars remain inside the embedded chart window.")
        self.placeholder.setAlignment(Qt.AlignCenter); self.placeholder.setObjectName("mapPlaceholder"); self.main_layout.addWidget(self.placeholder,1)
        row=QHBoxLayout()
        self.button=QPushButton("EMBED OPENCPN"); self.button.clicked.connect(self.start_embed); row.addWidget(self.button)
        self.markers=QPushButton("LOAD TEST VESSEL MARKERS"); self.markers.clicked.connect(self.load_markers); row.addWidget(self.markers)
        self.main_layout.addLayout(row)
        self.foreign_window=None; self.container=None; self.process=None; self.window_id=None; self.try_count=0
        self.timer=QTimer(self); self.timer.timeout.connect(self.try_embed)
    def find_windows(self):
        try:
            out=subprocess.check_output(["xdotool","search","--onlyvisible","--name","OpenCPN"],stderr=subprocess.DEVNULL,text=True)
            return [x.strip() for x in out.splitlines() if x.strip().isdigit()]
        except Exception:
            return []
    def load_markers(self):
        if not FLEET_GPX.exists():
            QMessageBox.warning(self,"Fleet markers","fleet_markers.gpx is missing."); return
        if not shutil.which("opencpn"):
            QMessageBox.warning(self,"OpenCPN","OpenCPN is not installed."); return
        try:
            ids=self.find_windows()
            if ids:
                subprocess.Popen(["opencpn","--remote","--open",str(FLEET_GPX)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["opencpn",str(FLEET_GPX)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            self.start_embed()
            QMessageBox.information(self,"Fleet markers","SEMAIH, AL FANCI and JAWAD 1 were sent to OpenCPN.")
        except Exception as e:
            QMessageBox.warning(self,"Fleet markers",str(e))
    def start_embed(self):
        if self.container is not None: return
        if not shutil.which("opencpn"):
            QMessageBox.warning(self,"OpenCPN","OpenCPN is not installed."); return
        if not shutil.which("xdotool"):
            QMessageBox.warning(self,"OpenCPN","xdotool is missing. Run installer again."); return
        free=mem_available_mb()
        if free is not None and free<260:
            if QMessageBox.question(self,"Low memory",f"Only {free} MB RAM is available. OpenCPN can be heavy on Pi 3. Continue?",QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:
                return
        self.status.setText("STARTING...")
        ids=self.find_windows()
        if not ids:
            self.process=subprocess.Popen(["opencpn"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.try_count=0; self.timer.start(700)
    def try_embed(self):
        self.try_count+=1; ids=self.find_windows()
        if ids:
            self.timer.stop()
            try:
                self.window_id=int(ids[-1]); self.foreign_window=QWindow.fromWinId(self.window_id)
                self.container=QWidget.createWindowContainer(self.foreign_window,self); self.container.setMinimumSize(400,265)
                self.main_layout.insertWidget(1,self.container,1); self.placeholder.hide(); self.button.hide(); self.status.setText("EMBEDDED"); return
            except Exception as e:
                QMessageBox.warning(self,"OpenCPN",f"Could not embed:\n{e}"); return
        if self.try_count>25:
            self.timer.stop(); self.status.setText("NOT FOUND")
    def snapshot(self):
        if not self.window_id: return QPixmap()
        try:
            return QApplication.primaryScreen().grabWindow(self.window_id)
        except Exception:
            return QPixmap()

class FocusDialog(QDialog):
    def __init__(self,main_window,boat_index):
        super().__init__(main_window); self.main_window=main_window; self.boat_index=boat_index
        boat=main_window.boats[boat_index]
        self.setWindowTitle(boat["name"]+" · CAMERA FOCUS"); self.showMaximized()
        root=QVBoxLayout(self); top=QHBoxLayout()
        back=QPushButton("BACK TO COMMAND CENTER"); back.clicked.connect(self.close); top.addWidget(back); top.addStretch(); root.addLayout(top)
        split=QSplitter(Qt.Horizontal)
        cam=CameraPanel(boat["name"]); cam.setMaximumHeight(999); cam.setText(boat["name"]+"\nLIVE CAMERA · FULL VIEW"); split.addWidget(cam)
        right=QWidget(); rv=QVBoxLayout(right)
        self.map_snapshot=QLabel("OPENCPN LIVE MINI VIEW"); self.map_snapshot.setAlignment(Qt.AlignCenter); self.map_snapshot.setObjectName("mapPlaceholder"); self.map_snapshot.setMinimumHeight(220)
        rv.addWidget(self.map_snapshot,1)
        self.status_widget=BoatStatusWidget(boat["id"],boat["name"],boat.get("type","ASD"))
        self.status_widget.logRequested.connect(main_window.start_log); self.status_widget.stopLogRequested.connect(main_window.stop_log); rv.addWidget(self.status_widget)
        split.addWidget(right); split.setSizes([850,500]); root.addWidget(split,1)
        self.timer=QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(800); self.refresh()
    def refresh(self):
        boat=self.main_window.boats[self.boat_index]
        self.status_widget.set_values(boat); self.status_widget.set_recording(boat["id"] in self.main_window.recording)
        pm=self.main_window.map_widget.snapshot()
        if not pm.isNull():
            self.map_snapshot.setPixmap(pm.scaled(self.map_snapshot.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation))
        else:
            self.map_snapshot.setText("OPENCPN LIVE MINI VIEW\nMap remains embedded in Command Center to prevent the desktop-toolbar bug.")

class VesselDialog(QDialog):
    def __init__(self,main_window,vessel):
        super().__init__(main_window); self.vessel=vessel
        self.setWindowTitle(vessel["name"]); self.resize(980,680)
        root=QVBoxLayout(self); t=QLabel(vessel["name"]); t.setObjectName("pageTitle"); root.addWidget(t)
        summary=QFrame(); summary.setObjectName("panel"); g=QGridLayout(summary)
        vals=[("TYPE",vessel["type"]),("LAT",str(vessel.get("lat","N/A"))),("LON",str(vessel.get("lon","N/A"))),
              ("ENGINE 1 FUEL","Gateway input · L/h"),("ENGINE 2 FUEL","Gateway input · L/h"),("GEN 1 FUEL","Gateway input · L/h"),("GEN 2 FUEL","Gateway input · L/h")]
        for i,(a,b) in enumerate(vals):
            g.addWidget(QLabel(a),i//3*2,i%3); q=QLabel(b); q.setObjectName("metric"); g.addWidget(q,i//3*2+1,i%3)
        root.addWidget(summary)
        ctrl=QFrame(); ctrl.setObjectName("panel"); cl=QHBoxLayout(ctrl)
        if vessel["type"]=="ASD":
            cl.addWidget(QLabel("ASD 360° CONTROL MODEL")); cl.addWidget(ThrusterGauge("PORT","ASD")); cl.addWidget(ThrusterGauge("STBD","ASD"))
        else:
            cl.addWidget(QLabel("CONVENTIONAL CONTROL MODEL"))
            for s in ("ASTERN","STOP","AHEAD","RPM −","RPM +"): cl.addWidget(QPushButton(s))
        root.addWidget(ctrl)
        if vessel.get("firefighting"):
            ff=QFrame(); ff.setObjectName("panel"); fl=QGridLayout(ff)
            title=QLabel("JAWAD 1 · FiFi / FIRE FIGHTING"); title.setObjectName("sectionTitle"); fl.addWidget(title,0,0,1,4)
            fl.addWidget(QPushButton("FiFi AUTO"),1,0); fl.addWidget(QPushButton("FiFi MANUAL"),1,1); fl.addWidget(QPushButton("FIRE PUMP"),1,2); fl.addWidget(QPushButton("MONITOR CENTER"),1,3)
            fl.addWidget(QLabel("Monitor direction: hardware input pending"),2,0,1,2); fl.addWidget(QLabel("Pressure / flow: hardware input pending"),2,2,1,2); root.addWidget(ff)
        note=QLabel("Real propulsion and FiFi outputs remain disabled in this build. This page is UI/data-integration preparation only."); note.setObjectName("note"); root.addWidget(note); root.addStretch()

class FleetPage(QWidget):
    def __init__(self,main_window,parent=None):
        super().__init__(parent); self.main_window=main_window
        root=QHBoxLayout(self); left=QVBoxLayout(); t=QLabel("FLEET LIST"); t.setObjectName("pageTitle"); left.addWidget(t)
        self.list=QListWidget(); left.addWidget(self.list,1)
        for v in main_window.fleet:
            item=QListWidgetItem(f"{v['name']}   [{v['type']}]"); item.setData(Qt.UserRole,v["id"]); self.list.addItem(item)
        self.list.itemDoubleClicked.connect(self.open_vessel)
        lw=QWidget(); lw.setLayout(left); root.addWidget(lw,1); self.detail=QTextEdit(); self.detail.setReadOnly(True); root.addWidget(self.detail,2)
        self.list.currentItemChanged.connect(self.show_vessel)
        if self.list.count(): self.list.setCurrentRow(0)
    def get(self,item):
        if not item:return None
        vid=item.data(Qt.UserRole); return next((v for v in self.main_window.fleet if v["id"]==vid),None)
    def show_vessel(self,item,*_):
        v=self.get(item)
        if not v:return
        text=[v["name"],f"Propulsion: {v['type']}",f"Location: {v.get('location','Not configured')}",f"Latitude: {v.get('lat','Not configured')}",f"Longitude: {v.get('lon','Not configured')}",
              "","Standard vessel data model:","Camera · Position · Heading · Port/Stbd RPM · Thruster/propulsion state",
              "Engine 1 fuel L/h · Engine 2 fuel L/h · Generator 1 fuel L/h · Generator 2 fuel L/h",
              "Maneuver fuel total · Maneuver history · Provisional performance score."]
        if v.get("firefighting"):
            text += ["","JAWAD 1 SPECIAL MODULE:","FiFi AUTO / MANUAL · Fire pump · Monitor direction · Pressure / flow (hardware integration pending)."]
        self.detail.setPlainText("\n".join(map(str,text)))
    def open_vessel(self,item):
        v=self.get(item)
        if v: VesselDialog(self.main_window,v).exec_()

class LibraryPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        root=QHBoxLayout(self); left=QVBoxLayout(); t=QLabel("AI TRAINING & MANEUVER LIBRARY"); t.setObjectName("pageTitle"); left.addWidget(t)
        self.list=QListWidget(); self.list.itemDoubleClicked.connect(self.open_item); left.addWidget(self.list)
        b=QPushButton("REFRESH LIBRARY"); b.clicked.connect(self.reload); left.addWidget(b)
        lw=QWidget(); lw.setLayout(left); root.addWidget(lw,1); self.detail=QTextEdit(); self.detail.setReadOnly(True); root.addWidget(self.detail,2); self.reload()
    def reload(self):
        self.list.clear()
        for f in sorted(MISSIONS_DIR.glob("*.jsonl"),key=lambda x:x.stat().st_mtime,reverse=True): self.list.addItem(QListWidgetItem(f.stem))
    def open_item(self,item):
        f=MISSIONS_DIR/(item.text()+".jsonl"); samples=[]
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                if line.strip(): samples.append(json.loads(line))
        except Exception as e:
            self.detail.setPlainText(str(e)); return
        if not samples:
            self.detail.setPlainText("No samples."); return
        last=samples[-1]; total_liters=last.get("fuel_total_l",0.0); rpms=[]; thrs=[]; rates=[]
        for s in samples:
            b=s.get("boat",{}); rpms.extend([b.get("port_rpm",0),b.get("stbd_rpm",0)]); thrs.extend([b.get("port_angle",0),b.get("stbd_angle",0)])
            rates.append(sum(b.get(k,0) for k in ("engine1_fuel_lph","engine2_fuel_lph","gen1_fuel_lph","gen2_fuel_lph")))
        def variation(xs):
            return 0.0 if len(xs)<2 else sum(abs(xs[i]-xs[i-1]) for i in range(1,len(xs)))/(len(xs)-1)
        summary={"rpm_variation":variation(rpms),"thruster_variation":variation(thrs),"avg_total_fuel_lph":sum(rates)/max(1,len(rates))}
        score=provisional_score(summary); duration=max(0.0,last.get("elapsed_s",0.0))
        out=[f"MANEUVER: {item.text()}",f"Duration: {duration/60:.1f} min",f"Total fuel consumed: {total_liters:.2f} L",
             f"Average total fuel rate: {summary['avg_total_fuel_lph']:.1f} L/h",f"Provisional training performance score: {score:.1f}%",
             "","Score status: PROVISIONAL / NOT A SAFETY CERTIFICATION.","Safety criteria will be added when real safety inputs and the approved scoring rubric are configured.","","Last telemetry samples:"]
        for s in samples[-25:]:
            b=s.get("boat",{}); rate=sum(b.get(k,0) for k in ("engine1_fuel_lph","engine2_fuel_lph","gen1_fuel_lph","gen2_fuel_lph"))
            out.append(f"{s.get('time','')} | HDG {int(b.get('heading',0))}° | PORT {b.get('port_rpm',0)} RPM | STBD {b.get('stbd_rpm',0)} RPM | Fuel {rate:.1f} L/h")
        self.detail.setPlainText("\n".join(out))

class TrainingPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); root=QVBoxLayout(self); t=QLabel("PILOT & TUG MASTER TRAINING"); t.setObjectName("pageTitle"); root.addWidget(t)
        grid=QGridLayout()
        for i,(a,b) in enumerate([("PILOT TRAINING","Cast off · berthing · tug allocation · voice orders · maneuver assessment."),
                                  ("TUG MASTER TRAINING","Azimuth handling · approach · push/pull · heading · emergency response."),
                                  ("RC TUG LAB","3D-printed training tugs · Manual/Assisted/AI testing.")]):
            q=QFrame(); q.setObjectName("panel"); l=QVBoxLayout(q); z=QLabel(a); z.setObjectName("sectionTitle"); l.addWidget(z); u=QLabel(b); u.setWordWrap(True); l.addWidget(u); l.addStretch(); grid.addWidget(q,0,i)
        root.addLayout(grid); root.addStretch()

class PropulsionPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); root=QVBoxLayout(self); t=QLabel("PROPULSION MANAGER"); t.setObjectName("pageTitle"); root.addWidget(t)
        n=QLabel("Fleet profiles automatically choose ASD 360° or Conventional Ahead / Stop / Astern presentation."); n.setObjectName("note"); root.addWidget(n); root.addStretch()

class SystemPage(QWidget):
    def __init__(self,main_window,parent=None):
        super().__init__(parent); self.main_window=main_window; self.manifest=None
        root=QVBoxLayout(self); t=QLabel("SYSTEM / UPDATES"); t.setObjectName("pageTitle"); root.addWidget(t)
        info=QFrame(); info.setObjectName("panel"); il=QVBoxLayout(info); q=QLabel(f"Installed: V{APP_VERSION} · Raspberry Pi 3"); q.setObjectName("sectionTitle"); il.addWidget(q)
        row=QHBoxLayout()
        health=QPushButton("SYSTEM HEALTH"); health.clicked.connect(self.check_health); upd=QPushButton("CHECK FOR UPDATES"); upd.clicked.connect(self.check_updates)
        self.install=QPushButton("DOWNLOAD INSTALL UPDATE"); self.install.clicked.connect(self.install_update); self.install.setEnabled(False)
        reset=QPushButton("RESET SIM E-STOP"); reset.clicked.connect(main_window.reset_estop)
        for b in (health,upd,self.install,reset): row.addWidget(b)
        il.addLayout(row); self.output=QTextEdit(); self.output.setReadOnly(True); il.addWidget(self.output); root.addWidget(info); root.addStretch()
    def check_health(self):
        disk=shutil.disk_usage(str(Path.home()))
        self.output.setPlainText(f"DR.BOAT V{APP_VERSION}\nCPU temperature: {cpu_temp_c() if cpu_temp_c()!=None else 'N/A'} °C\nAvailable RAM: {mem_available_mb() if mem_available_mb()!=None else 'N/A'} MB\nFree disk: {disk.free//(1024**3)} GB\nOpenCPN: {'INSTALLED' if shutil.which('opencpn') else 'NOT INSTALLED'}\nFleet profiles: {len(self.main_window.fleet)}\nStatic OpenCPN test markers: SEMAIH / AL FANCI / JAWAD 1")
    def check_updates(self):
        self.output.setPlainText("Checking GitHub update server over HTTPS..."); QApplication.processEvents()
        try:
            req=urllib.request.Request(UPDATE_MANIFEST,headers={"User-Agent":"DRBOAT-V3.1"})
            with urllib.request.urlopen(req,timeout=12) as r: m=json.loads(r.read().decode("utf-8"))
            self.manifest=m; latest=m.get("version","0.0.0"); notes=m.get("notes","")
            if isinstance(notes,list): notes="\n".join("• "+str(x) for x in notes)
            txt=f"Current version: {APP_VERSION}\nLatest version: {latest}\nServer: CONNECTED (HTTPS)\n\nRelease notes:\n{notes}"
            if version_tuple(latest)>version_tuple(APP_VERSION):
                txt+="\n\nUPDATE AVAILABLE."; self.install.setEnabled(True)
            else:
                txt+="\n\nYou are up to date."; self.install.setEnabled(False)
            self.output.setPlainText(txt)
        except Exception as e:
            self.install.setEnabled(False); self.output.setPlainText(f"Update check failed:\n{e}")
    def install_update(self):
        if not self.manifest:return
        url=self.manifest.get("package_url"); want=self.manifest.get("sha256","").lower()
        if not url:return
        if QMessageBox.question(self,"Install update","Download, verify, back up and install update?",QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        try:
            tmp=Path(tempfile.mkdtemp(prefix="drboat-update-")); zp=tmp/"update.zip"
            req=urllib.request.Request(url,headers={"User-Agent":"DRBOAT-V3.1"})
            with urllib.request.urlopen(req,timeout=60) as r,zp.open("wb") as f:
                while True:
                    c=r.read(131072)
                    if not c: break
                    f.write(c)
            got=hashlib.sha256(zp.read_bytes()).hexdigest()
            if want and got!=want: raise RuntimeError("SHA256 mismatch")
            ex=tmp/"extract"; ex.mkdir()
            with zipfile.ZipFile(zp) as z: z.extractall(ex)
            dirs=[p for p in ex.iterdir() if p.is_dir()]
            if not dirs: raise RuntimeError("No application folder in update package")
            src=dirs[0]; app=APP_DIR; backup=APP_DIR.parent/(APP_DIR.name+".backup"); launcher=Path.home()/".local/bin/drboat"
            h=tmp/"apply_update.sh"
            script = "#!/bin/bash\nset -e\nsleep 2\n"
            script += f'rm -rf "{backup}"\n'
            script += f'mv "{app}" "{backup}"\n'
            script += f'mkdir -p "{app}"\n'
            script += f'cp -a "{src}/." "{app}/"\n'
            script += f'if [ -d "{backup}/data/missions" ]; then mkdir -p "{app}/data"; rm -rf "{app}/data/missions"; cp -a "{backup}/data/missions" "{app}/data/missions"; fi\n'
            script += f'"{launcher}" >/dev/null 2>&1 &\n'
            h.write_text(script)
            os.chmod(h,0o755); subprocess.Popen(["bash",str(h)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); QApplication.instance().quit()
        except Exception as e:
            QMessageBox.critical(self,"Update failed",str(e))

class CommandCenter(QWidget):
    def __init__(self,main_window,parent=None):
        super().__init__(parent); self.main_window=main_window
        root=QVBoxLayout(self); root.setContentsMargins(6,4,6,4); root.setSpacing(4)
        split=QSplitter(Qt.Horizontal)
        self.map_widget=OpenCPNEmbedWidget(); split.addWidget(self.map_widget)
        cams=QWidget(); cv=QVBoxLayout(cams); cv.setContentsMargins(0,0,0,0); cv.setSpacing(4)
        self.cam1=CameraPanel("DR BOAT 1"); self.cam2=CameraPanel("DR BOAT 2")
        self.cam1.doubleClicked.connect(lambda:main_window.open_focus(0)); self.cam2.doubleClicked.connect(lambda:main_window.open_focus(1))
        cv.addWidget(self.cam1); cv.addWidget(self.cam2); split.addWidget(cams); split.setSizes([920,360]); root.addWidget(split,3)
        fleet=QHBoxLayout(); fleet.setSpacing(4)
        self.b1=BoatStatusWidget("DB1","DR BOAT 1","ASD"); self.b2=BoatStatusWidget("DB2","DR BOAT 2","ASD")
        for w in (self.b1,self.b2):
            w.logRequested.connect(main_window.start_log); w.stopLogRequested.connect(main_window.stop_log); fleet.addWidget(w)
        root.addLayout(fleet,2)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("DR.BOAT V3.1"); self.showMaximized()
        self.fleet=load_fleet(); self.recording={}; self.log_meta={}
        self.boats=[
            {"id":"DB1","name":"DR BOAT 1","type":"ASD","heading":42.0,"battery":92,"link":98,"port_angle":25,"stbd_angle":335,"port_rpm":820,"stbd_rpm":790,"engine1_fuel_lph":55.0,"engine2_fuel_lph":52.0,"gen1_fuel_lph":8.5,"gen2_fuel_lph":0.0},
            {"id":"DB2","name":"DR BOAT 2","type":"ASD","heading":318.0,"battery":88,"link":96,"port_angle":310,"stbd_angle":50,"port_rpm":640,"stbd_rpm":650,"engine1_fuel_lph":39.0,"engine2_fuel_lph":40.0,"gen1_fuel_lph":7.5,"gen2_fuel_lph":0.0},
        ]
        central=QWidget(); root=QVBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        head=QFrame(); head.setObjectName("header"); hl=QHBoxLayout(head)
        logo=QLabel(); lp=APP_DIR/"static"/"drboat_logo.png"
        if lp.exists(): logo.setPixmap(QPixmap(str(lp)).scaled(78,78,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        hl.addWidget(logo); tt=QVBoxLayout(); a=QLabel("DR.BOAT"); a.setObjectName("brandTitle"); b=QLabel("INTELLIGENT MARINE CONTROL · TRAINING · AI · V3.1"); b.setObjectName("brandSub"); tt.addWidget(a); tt.addWidget(b); hl.addLayout(tt); hl.addStretch()
        self.ready=QLabel("READY"); self.ready.setObjectName("ready"); hl.addWidget(self.ready); es=QPushButton("EMERGENCY STOP"); es.setObjectName("estop"); es.clicked.connect(self.estop); hl.addWidget(es); root.addWidget(head)
        nav=QFrame(); nav.setObjectName("nav"); nl=QHBoxLayout(nav); nl.setContentsMargins(5,4,5,4)
        self.pages=QStackedWidget()
        for text,idx in [("COMMAND CENTER",0),("FLEET LIST",1),("AI TRAINING & MANEUVER LIBRARY",2),("PILOT & TUG MASTER TRAINING",3),("PROPULSION MANAGER",4),("SYSTEM / UPDATES",5)]:
            q=QPushButton(text); q.clicked.connect(lambda _,i=idx:self.pages.setCurrentIndex(i)); nl.addWidget(q)
        root.addWidget(nav)
        self.command=CommandCenter(self); self.map_widget=self.command.map_widget; self.fleet_page=FleetPage(self); self.library=LibraryPage(); self.training=TrainingPage(); self.propulsion=PropulsionPage(); self.system=SystemPage(self)
        for p in (self.command,self.fleet_page,self.library,self.training,self.propulsion,self.system): self.pages.addWidget(p)
        root.addWidget(self.pages,1); self.setCentralWidget(central); self.apply_style()
        self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(1000); self.last_tick=time.time(); self.tick()
    def apply_style(self):
        self.setStyleSheet("QMainWindow,QWidget{background:#06141e;color:#dcebf2;font-family:Arial;}QFrame#header{background:#092333;border-bottom:1px solid #315e72;}QFrame#nav{background:#071c28;border-bottom:1px solid #244b5c;}QLabel#brandTitle{font-size:27px;font-weight:bold;letter-spacing:3px;}QLabel#brandSub{color:#91b4c3;font-size:10px;}QLabel#ready{border:1px solid #2e7fa2;border-radius:5px;padding:8px 15px;font-weight:bold;}QPushButton{background:#123648;color:#e2eff4;border:1px solid #3d7186;border-radius:5px;padding:7px 10px;}QPushButton:hover{background:#17455b;}QPushButton#estop,QPushButton#recordButton{background:#8b1d26;border-color:#d04450;font-weight:bold;}QFrame#panel,QFrame#mapPanel{background:#0b2635;border:1px solid #2f6074;border-radius:7px;}QLabel#camera{background:#081923;border:1px solid #3e7186;color:#9abac8;font-size:13px;}QLabel#metric{background:#071923;border:1px solid #173646;padding:4px;font-weight:bold;font-size:10px;}QLabel#sectionTitle{font-size:13px;font-weight:bold;color:#eaf5fa;}QLabel#pageTitle{font-size:22px;font-weight:bold;padding:7px;}QLabel#smallStatus{color:#86aab9;font-size:9px;}QLabel#mapPlaceholder{background:#071923;border:1px solid #21475a;color:#86aab9;font-size:13px;}QLabel#note{color:#8eb1c0;padding:9px;}QLineEdit,QTextEdit,QListWidget,QComboBox{background:#071923;border:1px solid #315e72;color:#e3eef3;padding:6px;}")
    def tick(self):
        now=time.time(); dt=max(0.1,min(3.0,now-self.last_tick)); self.last_tick=now
        for i,b in enumerate(self.boats):
            b["heading"]=(b["heading"]+0.13+i*0.02)%360
            b["engine1_fuel_lph"]=max(0.0,b["port_rpm"]*0.065+1.5); b["engine2_fuel_lph"]=max(0.0,b["stbd_rpm"]*0.065+1.5)
        self.command.b1.set_values(self.boats[0]); self.command.b2.set_values(self.boats[1]); self.command.b1.set_recording("DB1" in self.recording); self.command.b2.set_recording("DB2" in self.recording); self.append_logs(dt)
    def append_logs(self,dt):
        now=datetime.now().isoformat(timespec="milliseconds")
        for boat_id,name in list(self.recording.items()):
            b=next((x for x in self.boats if x["id"]==boat_id),None)
            if not b: continue
            meta=self.log_meta.setdefault(boat_id,{"start":time.time(),"fuel_total_l":0.0}); total_lph=sum(b.get(k,0.0) for k in ("engine1_fuel_lph","engine2_fuel_lph","gen1_fuel_lph","gen2_fuel_lph"))
            meta["fuel_total_l"] += total_lph*dt/3600.0
            payload={"time":now,"elapsed_s":time.time()-meta["start"],"fuel_total_l":meta["fuel_total_l"],"boat":dict(b)}
            with (MISSIONS_DIR/(name+".jsonl")).open("a",encoding="utf-8") as f: f.write(json.dumps(payload,ensure_ascii=False)+"\n")
    def start_log(self,boat_id):
        d=QDialog(self); d.setWindowTitle("Log Maneuver"); l=QVBoxLayout(d); l.addWidget(QLabel("Maneuver name")); e=QLineEdit("Cast_Off"); l.addWidget(e); r=QHBoxLayout(); ok=QPushButton("START LOG"); ca=QPushButton("CANCEL"); r.addWidget(ok); r.addWidget(ca); l.addLayout(r); res={"ok":False}; ok.clicked.connect(lambda:(res.update(ok=True),d.accept())); ca.clicked.connect(d.reject); d.exec_()
        if not res["ok"]: return
        safe="".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in e.text().strip()) or "Maneuver"
        name=f"{safe}_{boat_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"; self.recording[boat_id]=name; self.log_meta[boat_id]={"start":time.time(),"fuel_total_l":0.0}; self.library.reload()
    def stop_log(self,boat_id):
        self.recording.pop(boat_id,None); self.log_meta.pop(boat_id,None); self.library.reload()
    def open_focus(self,i): FocusDialog(self,i).exec_()
    def estop(self):
        self.ready.setText("SIM E-STOP")
        for b in self.boats: b["port_rpm"]=0; b["stbd_rpm"]=0
    def reset_estop(self): self.ready.setText("READY")

def main():
    app=QApplication(sys.argv); w=MainWindow(); w.show(); sys.exit(app.exec_())
if __name__=="__main__": main()
