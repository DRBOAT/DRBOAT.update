#!/bin/bash
set -euo pipefail

VERSION="8.5.0"
SRC_ORIG="$(cd "$(dirname "$0")" && pwd)"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
cp -a "$SRC_ORIG/." "$STAGE/"
SRC="$STAGE"
APPDIR="$HOME/.local/share/drboat"
BINDIR="$HOME/.local/bin"
DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
[ -z "$DESKTOP_DIR" ] && DESKTOP_DIR="$HOME/Desktop"
LAUNCHER="$BINDIR/drboat"
DESKTOP_FILE="$DESKTOP_DIR/Doctor Boat Control Marine Intelligence V${VERSION}.desktop"

echo "Installing DR.BOAT V${VERSION} for Raspberry Pi 3..."

if [ -f /etc/apt/sources.list.d/openplotterNodejs.list ] && grep -q "node_18" /etc/apt/sources.list.d/openplotterNodejs.list; then
  sudo mv /etc/apt/sources.list.d/openplotterNodejs.list /etc/apt/sources.list.d/openplotterNodejs.list.disabled || true
fi
if [ -f /etc/apt/sources.list.d/nodesource.list ] && grep -q "node_18" /etc/apt/sources.list.d/nodesource.list; then
  sudo rm -f /etc/apt/sources.list.d/nodesource.list
fi

sudo apt-get update
sudo apt-get install -y python3 python3-pyqt5 xdotool gdal-bin python3-gdal

mkdir -p "$BINDIR" "$DESKTOP_DIR"
BACKUP="$HOME/.local/share/drboat-pre-v8.5-backup"
rm -rf "$BACKUP"
if [ -d "$APPDIR" ]; then cp -a "$APPDIR" "$BACKUP"; fi

TMPDATA=""
if [ -d "$APPDIR/data" ]; then
  TMPDATA="$(mktemp -d)"; mkdir -p "$TMPDATA/data"
  for d in missions route_history track_history chart_cache tile_cache; do
    if [ -d "$APPDIR/data/$d" ]; then mkdir -p "$TMPDATA/data/$d"; cp -a "$APPDIR/data/$d/." "$TMPDATA/data/$d/" || true; fi
  done
  for f in positioning_settings.json fleet.json vessels.json marine_marks.json; do
    if [ -f "$APPDIR/data/$f" ]; then cp -a "$APPDIR/data/$f" "$TMPDATA/data/$f" || true; fi
  done
fi

rm -rf "$APPDIR"; mkdir -p "$APPDIR"; cp -a "$SRC/." "$APPDIR/"
if [ -n "$TMPDATA" ] && [ -d "$TMPDATA/data" ]; then mkdir -p "$APPDIR/data"; cp -a "$TMPDATA/data/." "$APPDIR/data/" || true; rm -rf "$TMPDATA"; fi

cat > "$LAUNCHER" <<EOF
#!/bin/bash
cd "$APPDIR"
exec python3 "$APPDIR/main.py"
EOF
chmod +x "$LAUNCHER"

# Keep ONE Doctor Boat desktop launcher only.
rm -f "$DESKTOP_DIR/DoctorBot.desktop" "$DESKTOP_DIR/DrBoat.desktop" "$DESKTOP_DIR/DR-BOAT-V2.desktop" "$DESKTOP_DIR/DR-BOAT.desktop"
find "$DESKTOP_DIR" -maxdepth 1 -type f -name 'Doctor Boat Control Marine Intelligence V*.desktop' ! -name "$(basename "$DESKTOP_FILE")" -delete 2>/dev/null || true

cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Doctor Boat Control Marine Intelligence V${VERSION}
Comment=DR.BOAT AI Marine Control V${VERSION}
Exec=$LAUNCHER
Icon=$APPDIR/static/drboat_logo.png
Terminal=false
Categories=Utility;
StartupNotify=true
EOF
chmod +x "$DESKTOP_FILE"
gio set "$DESKTOP_FILE" metadata::trusted true >/dev/null 2>&1 || true

echo
echo "DONE."
echo "DR.BOAT V${VERSION} installation complete."
echo "Previous application backup: $BACKUP"
echo "Chart directory, chart cache, routes, tracks, marine marks and mission data were preserved."
echo "Only one Doctor Boat desktop launcher is kept."
