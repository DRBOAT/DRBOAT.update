
import os, sys, json, math, time, shutil, hashlib, zipfile, tempfile, subprocess, urllib.request
from pathlib import Path
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QUrl, QProcess, QSize, QPointF, QRectF
from PyQt5.QtGui import QPixmap, QPainter, QPen, QColor, QFont, QWindow
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QGridLayout, QStackedWidget, QFrame, QMessageBox, QSplitter, QDialog, QListWidget,
    QListWidgetItem, QTextEdit, QLineEdit, QComboBox, QProgressBar, QScrollArea, QSlider
)

APP_VERSION = "5.1.0"
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
MISSIONS_DIR = DATA_DIR / "missions"
MISSIONS_DIR.mkdir(parents=True, exist_ok=True)
UPDATE_MANIFEST = "https://raw.githubusercontent.com/DRBOAT/DRBOAT.update/main/version.json"

def version_tuple(v):
    out = []
    for p in str(v).split("."):
        m = "".join(ch for ch in p if ch.isdigit())
        out.append(int(m or 0))
    return tuple((out + [0,0,0])[:3])

def mem_available_mb():
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) // 1024
    except Exception:
        pass
    return None

def cpu_temp_c():
    try:
        return int(Path("/sys/class/thermal/thermal_zone0/temp").read_text().strip()) / 1000.0
    except Exception:
        return None


class ManeuverCanvas(QWidget):
    # Each point contains: label, vessel attachment (x,y), tug station (x,y).
    # The yellow marker represents the tug's assigned station; the tow line terminates on the vessel attachment.
    SECURE_POINTS = [
        ("CENTER LEAD BOW",      0.000, -0.090,  0.000, -0.165),
        ("CENTER LEAD AFT",      0.000,  0.090,  0.000,  0.165),
        ("STARBOARD BOW",        0.032, -0.060,  0.100, -0.090),
        ("STARBOARD QUARTER",    0.032,  0.060,  0.100,  0.090),
        ("PORT BOW",            -0.032, -0.060, -0.100, -0.090),
        ("PORT QUARTER",        -0.032,  0.060, -0.100,  0.090),
    ]
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setMinimumSize(520,420)
        self.setMouseTracking(True)
        self.running=False; self.secured=False
        self.ship_x=.50; self.ship_y=.24; self.ship_heading=180.; self.ship_speed=.018; self.rudder=0.
        self.zoom=1.; self.pan_x=0.; self.pan_y=0.; self._drag=None
        self.view_mode='MARINE CHART'; self.ship_type='CONTAINER SHIP'
        defaults=[0,1,2,5]
        self.tugs=[]
        for i in range(4):
            self.tugs.append({'name':f'TUG {i+1}','x':.23+i*.18,'y':.10,'angle':0,'power':0,'secured':False,'point':defaults[i]})
        self.timer=QTimer(self); self.timer.timeout.connect(self.step); self.timer.start(50)

    def reset_sim(self):
        self.running=False; self.secured=False; self.ship_x=.50; self.ship_y=.24; self.ship_heading=180.; self.ship_speed=.018; self.rudder=0.
        self.zoom=1.; self.pan_x=0.; self.pan_y=0.
        defaults=[0,1,2,5]
        for i,t in enumerate(self.tugs): t.update(x=.23+i*.18,y=.10,angle=0,power=0,secured=False,point=defaults[i])
        self.update()
    def start(self): self.running=True
    def secure(self): self.secured=True
    def _rot_point(self, ox, oy):
        a=math.radians(self.ship_heading)
        return (self.ship_x+ox*math.cos(a)-oy*math.sin(a), self.ship_y+ox*math.sin(a)+oy*math.cos(a))
    def point_xy(self, idx):
        _,_,_,sx,sy = self.SECURE_POINTS[idx]
        return self._rot_point(sx,sy)
    def attach_xy(self, idx):
        _,ax,ay,_,_ = self.SECURE_POINTS[idx]
        return self._rot_point(ax,ay)
    def step(self):
        if not self.running: return
        dt=.05
        self.ship_heading=(self.ship_heading+self.rudder*.010*dt)%360
        r=math.radians(self.ship_heading-90)
        self.ship_x+=math.cos(r)*self.ship_speed*dt; self.ship_y+=math.sin(r)*self.ship_speed*dt
        if self.secured:
            for t in self.tugs:
                tx,ty=self.point_xy(t['point'])
                t['x']+=(tx-t['x'])*.045; t['y']+=(ty-t['y'])*.045
                dist=((tx-t['x'])**2+(ty-t['y'])**2)**.5
                t['secured']=dist < .012
                if t['secured']:
                    force=t['power']/15000.; fa=math.radians(t['angle']-90)
                    self.ship_x+=math.cos(fa)*force*dt; self.ship_y+=math.sin(fa)*force*dt
                    _,ax,ay,_,_=self.SECURE_POINTS[t['point']]
                    moment=(ax*math.sin(fa)-ay*math.cos(fa))*t['power']*.00045
                    self.ship_heading=(self.ship_heading+moment*dt)%360
        self.ship_x=max(.08,min(.92,self.ship_x)); self.ship_y=max(.06,min(.92,self.ship_y)); self.update()

    def wheelEvent(self,e):
        delta=e.angleDelta().y()
        self.zoom=max(.60,min(3.00,self.zoom*(1.12 if delta>0 else 1/1.12)))
        self.update(); e.accept()
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton: self._drag=e.pos(); self.setCursor(Qt.ClosedHandCursor); e.accept()
    def mouseMoveEvent(self,e):
        if self._drag is not None:
            d=e.pos()-self._drag; self._drag=e.pos(); self.pan_x+=d.x(); self.pan_y+=d.y(); self.update(); e.accept()
    def mouseReleaseEvent(self,e):
        if e.button()==Qt.LeftButton: self._drag=None; self.unsetCursor(); e.accept()
    def mouseDoubleClickEvent(self,e):
        self.zoom=1.; self.pan_x=0.; self.pan_y=0.; self.update(); e.accept()

    def _draw_target(self,p,w,h):
        x,y,hdg=self.ship_x,self.ship_y,self.ship_heading
        typ=self.ship_type
        p.save(); p.translate(w*x,h*y); p.rotate(hdg)
        pen=QPen(QColor('#eaf7fb'),1.4); p.setPen(pen)
        from PyQt5.QtGui import QPolygonF
        if typ=='JACK-UP BARGE':
            L,B=145,62; p.setBrush(QColor('#536575')); p.drawRect(QRectF(-B/2,-L/2,B,L))
            p.setBrush(QColor('#d7dfe4'))
            for xx in (-B*.42,B*.42):
                for yy in (-L*.40,L*.40): p.drawEllipse(QPointF(xx,yy),5,5)
            p.setBrush(QColor('#aebcc5')); p.drawRect(QRectF(-B*.28,-L*.18,B*.56,L*.28))
        elif typ=='TUG & BARGE':
            L,B=150,64; p.setBrush(QColor('#596b78')); p.drawRect(QRectF(-B/2,-L/2,B,L))
            # bridle from two barge corners to a common tow point, then tow wire to tug
            p.setPen(QPen(QColor('#ffd765'),2));
            p.drawLine(QPointF(-B*.35,-L/2),QPointF(0,-L*.72)); p.drawLine(QPointF(B*.35,-L/2),QPointF(0,-L*.72)); p.drawLine(QPointF(0,-L*.72),QPointF(0,-L*1.12))
            p.setBrush(QColor('#d5aa36')); p.setPen(QPen(QColor('#f5f8fa'),1.2)); p.drawRoundedRect(QRectF(-15,-L*1.32,30,38),5,5)
        else:
            if typ=='TANKER': L,B,color=165,46,'#6a6772'
            elif typ=='BULK CARRIER': L,B,color=160,48,'#635f55'
            elif typ=='GENERAL CARGO': L,B,color=150,44,'#486472'
            else: L,B,color=170,44,'#31576b'
            p.setBrush(QColor(color))
            bow=.31 if typ!='TANKER' else .25
            poly=[QPointF(0,-L/2),QPointF(B/2,-L*bow),QPointF(B/2,L/2),QPointF(-B/2,L/2),QPointF(-B/2,-L*bow)]
            p.drawPolygon(QPolygonF(poly))
            if typ=='CONTAINER SHIP':
                for yy in (-L*.20,0,L*.20):
                    p.setBrush(QColor('#aabfcb')); p.drawRect(QRectF(-B*.34,yy-10,B*.68,18))
            elif typ=='TANKER':
                p.setBrush(QColor('#8797a1')); p.drawEllipse(QRectF(-B*.28,-L*.10,B*.56,28))
            else:
                p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(-B*.32,-L*.02,B*.64,L*.22))
        p.setPen(QColor('#ffffff')); p.drawText(QRectF(-95,92,190,22),Qt.AlignCenter,typ); p.restore()

    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height()
        sea=QColor('#082d46') if self.view_mode=='MARINE CHART' else QColor('#173c43')
        land=QColor('#d1c59a') if self.view_mode=='MARINE CHART' else QColor('#67695d')
        quay=QColor('#52646a') if self.view_mode=='MARINE CHART' else QColor('#39494c')
        p.fillRect(self.rect(),sea)
        p.save(); p.translate(w/2+self.pan_x,h/2+self.pan_y); p.scale(self.zoom,self.zoom); p.translate(-w/2,-h/2)
        # Stylised Mina Zayed basin: outer breakwaters, long commercial quay and approach channel.
        p.setPen(Qt.NoPen); p.setBrush(land)
        p.drawRect(0,int(h*.74),int(w*.34),int(h*.26)); p.drawRect(int(w*.78),int(h*.25),int(w*.22),int(h*.75)); p.drawRect(int(w*.63),0,int(w*.37),int(h*.12))
        p.setBrush(quay); p.drawRect(int(w*.775),int(h*.25),int(w*.028),int(h*.57)); p.drawRect(int(w*.63),int(h*.10),int(w*.34),int(h*.025)); p.drawRect(0,int(h*.72),int(w*.34),int(h*.028))
        p.setPen(QPen(QColor('#9eb8bf'),6)); p.drawLine(int(w*.34),int(h*.70),int(w*.45),int(h*.61)); p.drawLine(int(w*.78),int(h*.24),int(w*.67),int(h*.18))
        p.setPen(QPen(QColor('#86d8e9'),1,Qt.DashLine)); p.drawLine(int(w*.49),0,int(w*.49),int(h*.70)); p.drawText(int(w*.515),24,'MINA ZAYED · INNER HARBOUR TRAINING MAP')
        p.setPen(QColor('#e7f4f7')); p.drawText(int(w*.81),int(h*.30),'COMMERCIAL QUAY / BERTHS'); p.drawText(int(w*.04),int(h*.78),'PORT BASIN / SERVICE AREA')
        # channel buoys
        for yy in (.14,.25,.36,.47,.58,.69):
            for xx,c in ((.435,'#e64f55'),(.545,'#45d17b')):
                p.setBrush(QColor(c)); p.setPen(Qt.NoPen); p.drawEllipse(QPointF(w*xx,h*yy),4.5,4.5)
        self._draw_target(p,w,h)
        # station markers and readable labels; small line shows station-to-vessel attachment geometry.
        for idx,(name,_,_,_,_) in enumerate(self.SECURE_POINTS):
            sx,sy=self.point_xy(idx); ax,ay=self.attach_xy(idx)
            p.setPen(QPen(QColor('#728e98'),1,Qt.DashLine)); p.drawLine(int(w*sx),int(h*sy),int(w*ax),int(h*ay))
            p.setBrush(QColor('#ffca54')); p.setPen(QPen(QColor('#fff2b3'),1)); p.drawEllipse(QPointF(w*sx,h*sy),5,5)
            p.setPen(QColor('#d6edf2'))
            dx=8 if sx>=self.ship_x else -150; dy=-8 if sy<=self.ship_y else 16
            p.drawText(QRectF(w*sx+dx,h*sy+dy,145,20),Qt.AlignLeft,name)
        def tug(t):
            p.save(); p.translate(w*t['x'],h*t['y']); p.rotate(t['angle']); p.setBrush(QColor('#d5aa36')); p.setPen(QPen(QColor('#eaf7fb'),1.2)); p.drawRoundedRect(QRectF(-12,-25,24,50),5,5); p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(-7,-4,14,12)); p.setPen(QColor('#ffffff')); p.drawText(QRectF(-45,30,90,18),Qt.AlignCenter,t['name']); p.restore()
        for t in self.tugs:
            tug(t)
            if self.secured:
                ax,ay=self.attach_xy(t['point'])
                p.setPen(QPen(QColor('#ffd765'),2)); p.drawLine(int(w*t['x']),int(h*t['y']),int(w*ax),int(h*ay))
        p.restore()
        p.setPen(QColor('#dcebf2')); p.drawText(12,22,f'BIRD EYE · {self.view_mode} · ZOOM {self.zoom:.1f}x · WHEEL=ZOOM · DRAG=PAN · DOUBLE CLICK=RESET VIEW')


class SimulatorDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle('DR.BOAT V5.1 · PILOT & TUG MASTER TRAINING SIMULATOR')
        self.resize(1120,720); self.setMinimumSize(760,520)
        root=QHBoxLayout(self); root.setContentsMargins(6,6,6,6)
        self.canvas=ManeuverCanvas(); root.addWidget(self.canvas,1)
        side_scroll=QScrollArea(); side_scroll.setWidgetResizable(True); side_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); side_scroll.setMinimumWidth(290); side_scroll.setMaximumWidth(370)
        side=QFrame(); side.setObjectName('panel'); v=QVBoxLayout(side)
        title=QLabel('V5.1 TRAINING SIMULATOR'); title.setObjectName('pageTitle'); v.addWidget(title)
        desc=QLabel('Resizable training scene · wheel zoom · drag-to-pan · four ASD tugs · six tug stations with tow lines to vessel securing points.'); desc.setWordWrap(True); v.addWidget(desc)
        self.vessel=QComboBox(); self.vessel.addItems(['CONTAINER SHIP','BULK CARRIER','TANKER','GENERAL CARGO','JACK-UP BARGE','TUG & BARGE']); self.vessel.currentTextChanged.connect(lambda x:(setattr(self.canvas,'ship_type',x),self.canvas.update())); v.addWidget(QLabel('TARGET VESSEL / UNIT')); v.addWidget(self.vessel)
        self.mode=QComboBox(); self.mode.addItems(['MARINE CHART','SATELLITE']); self.mode.currentTextChanged.connect(lambda x:(setattr(self.canvas,'view_mode',x),self.canvas.update())); v.addWidget(QLabel('MAP VIEW')); v.addWidget(self.mode)
        r=QHBoxLayout(); st=QPushButton('START MANEUVER'); st.clicked.connect(self.canvas.start); sc=QPushButton('PROCEED TO SECURE'); sc.clicked.connect(self.canvas.secure); r.addWidget(st); r.addWidget(sc); v.addLayout(r)
        v.addWidget(QLabel('SHIP CONTROL · ASTERN / STOP / DEAD SLOW / AHEAD'))
        row=QHBoxLayout()
        for text,val in [('ASTERN',-.015),('STOP',0),('D.SLOW',.009),('AHEAD',.018)]:
            b=QPushButton(text); b.clicked.connect(lambda _,q=val:setattr(self.canvas,'ship_speed',q)); row.addWidget(b)
        v.addLayout(row)
        v.addWidget(QLabel('RUDDER · PORT 35° — MIDSHIP — STBD 35°'))
        rud=QSlider(Qt.Horizontal); rud.setRange(-35,35); rud.setTickInterval(5); rud.setTickPosition(QSlider.TicksBelow); rud.valueChanged.connect(lambda x:setattr(self.canvas,'rudder',x)); v.addWidget(rud)
        v.addWidget(QLabel('SELECT TUG')); self.sel=QComboBox(); self.sel.addItems(['TUG 1','TUG 2','TUG 3','TUG 4']); self.sel.currentIndexChanged.connect(self.sync_point); v.addWidget(self.sel)
        v.addWidget(QLabel('TUG STATION / SECURING POSITION')); self.point=QComboBox(); self.point.addItems([x[0] for x in ManeuverCanvas.SECURE_POINTS]); self.point.currentIndexChanged.connect(self.set_point); v.addWidget(self.point)
        v.addWidget(QLabel('TUG CLOCK ANGLE'))
        ang=QSlider(Qt.Horizontal); ang.setRange(0,11); ang.valueChanged.connect(self.set_angle); v.addWidget(ang); self.anglab=QLabel("12 O'CLOCK · 000°"); v.addWidget(self.anglab)
        v.addWidget(QLabel('TUG POWER · LEAN ON / SLOW / HALF / FULL'))
        power=QSlider(Qt.Horizontal); power.setRange(0,100); power.setTickInterval(25); power.setTickPosition(QSlider.TicksBelow); power.valueChanged.connect(self.set_power); v.addWidget(power); self.powlab=QLabel('STOP · 0%'); v.addWidget(self.powlab)
        reset=QPushButton('RESET SCENARIO'); reset.clicked.connect(self.canvas.reset_sim); v.addWidget(reset); v.addStretch()
        side_scroll.setWidget(side); root.addWidget(side_scroll)
        self.sync_point()
    def sync_point(self):
        i=self.sel.currentIndex(); self.point.blockSignals(True); self.point.setCurrentIndex(self.canvas.tugs[i]['point']); self.point.blockSignals(False)
    def set_point(self,x): self.canvas.tugs[self.sel.currentIndex()]['point']=x; self.canvas.update()
    def set_angle(self,x):
        clock=12 if x==0 else x; deg=(x*30)%360; self.canvas.tugs[self.sel.currentIndex()]['angle']=deg; self.anglab.setText(f"{clock} O'CLOCK · {deg:03d}°")
    def set_power(self,x):
        self.canvas.tugs[self.sel.currentIndex()]['power']=x; label='STOP' if x==0 else 'LEAN ON' if x<=25 else 'SLOW' if x<=50 else 'HALF' if x<=75 else 'FULL'; self.powlab.setText(f'{label} · {x}%')


class DoubleClickLabel(QLabel):
    doubleClicked = pyqtSignal()
    def mouseDoubleClickEvent(self, event):
        self.doubleClicked.emit()
        super().mouseDoubleClickEvent(event)

class ThrusterGauge(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.angle = 0
        self.rpm = 0
        self.setMinimumSize(130, 145)

    def set_values(self, angle, rpm):
        self.angle = float(angle) % 360
        self.rpm = int(rpm)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w/2, 66
        radius = min(w, 110)/2 - 8

        p.setPen(QPen(QColor("#4a8197"), 2))
        p.drawEllipse(int(cx-radius), int(cy-radius), int(radius*2), int(radius*2))

        p.setPen(QColor("#dcebf2"))
        f = QFont()
        f.setPointSize(9)
        f.setBold(True)
        p.setFont(f)
        p.drawText(0, 3, w, 18, Qt.AlignCenter, self.title)

        rad = math.radians(self.angle - 90)
        ex = cx + math.cos(rad) * (radius - 10)
        ey = cy + math.sin(rad) * (radius - 10)
        p.setPen(QPen(QColor("#dcebf2"), 6, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(int(cx), int(cy), int(ex), int(ey))
        p.setBrush(QColor("#dcebf2"))
        p.drawEllipse(int(cx-6), int(cy-6), 12, 12)

        p.setPen(QColor("#9fc3d2"))
        f.setPointSize(8)
        f.setBold(False)
        p.setFont(f)
        p.drawText(0, 118, w, 15, Qt.AlignCenter, f"{int(self.angle)}°")
        p.setPen(QColor("#ffffff"))
        f.setPointSize(10)
        f.setBold(True)
        p.setFont(f)
        p.drawText(0, 132, w, 15, Qt.AlignCenter, f"{self.rpm} RPM")

class BoatStatusWidget(QFrame):
    logRequested = pyqtSignal(str)
    stopLogRequested = pyqtSignal(str)

    def __init__(self, boat_id, name, parent=None):
        super().__init__(parent)
        self.boat_id = boat_id
        self.name = name
        self.recording = False
        self.setObjectName("panel")

        layout = QVBoxLayout(self)
        title = QLabel(name)
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        metrics = QHBoxLayout()
        self.heading = QLabel("HEADING\n0°")
        self.battery = QLabel("BATTERY\n--%")
        self.link = QLabel("LINK\n--%")
        for x in (self.heading, self.battery, self.link):
            x.setAlignment(Qt.AlignCenter)
            x.setObjectName("metric")
            metrics.addWidget(x)
        layout.addLayout(metrics)

        thr = QHBoxLayout()
        self.port = ThrusterGauge("PORT AZIMUTH")
        self.stbd = ThrusterGauge("STBD AZIMUTH")
        thr.addWidget(self.port)
        thr.addWidget(self.stbd)
        layout.addLayout(thr)

        self.log_button = QPushButton(f"LOG MANEUVER · {name}")
        self.log_button.clicked.connect(self.toggle_log)
        layout.addWidget(self.log_button)

    def toggle_log(self):
        if not self.recording:
            self.logRequested.emit(self.boat_id)
        else:
            self.stopLogRequested.emit(self.boat_id)

    def set_recording(self, on):
        self.recording = on
        if on:
            self.log_button.setText(f"STOP LOG · {self.name}")
            self.log_button.setObjectName("recordButton")
        else:
            self.log_button.setText(f"LOG MANEUVER · {self.name}")
            self.log_button.setObjectName("")
        self.log_button.style().unpolish(self.log_button)
        self.log_button.style().polish(self.log_button)

    def set_values(self, boat):
        self.heading.setText(f"HEADING\n{int(boat['heading'])}°")
        self.battery.setText(f"BATTERY\n{boat['battery']}%")
        self.link.setText(f"LINK\n{boat['link']}%")
        self.port.set_values(boat["port_angle"], boat["port_rpm"])
        self.stbd.set_values(boat["stbd_angle"], boat["stbd_rpm"])

class CameraPanel(DoubleClickLabel):
    def __init__(self, boat_name, parent=None):
        super().__init__(parent)
        self.boat_name = boat_name
        self.setAlignment(Qt.AlignCenter)
        self.setObjectName("camera")
        self.setText(f"{boat_name} · LIVE CAMERA\nDOUBLE CLICK")
        self.setMinimumHeight(180)

class OpenCPNEmbedWidget(QFrame):
    embedded = pyqtSignal(bool)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("mapPanel")
        self.main_layout = QVBoxLayout(self)
        head = QHBoxLayout()
        title = QLabel("OPENCPN · LIVE MARINE CHART")
        title.setObjectName("sectionTitle")
        head.addWidget(title)
        head.addStretch()
        self.status = QLabel("NOT EMBEDDED")
        self.status.setObjectName("smallStatus")
        head.addWidget(self.status)
        self.main_layout.addLayout(head)

        self.placeholder = QLabel(
            "OpenCPN will appear inside this DR.BOAT panel.\n"
            "Press EMBED OPENCPN once after DR.BOAT starts."
        )
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.placeholder.setObjectName("mapPlaceholder")
        self.main_layout.addWidget(self.placeholder, 1)

        self.button = QPushButton("EMBED OPENCPN")
        self.button.clicked.connect(self.start_embed)
        self.main_layout.addWidget(self.button)

        self.foreign_window = None
        self.container = None
        self.process = None
        self.try_count = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.try_embed)

    def start_embed(self):
        if self.container is not None:
            return
        if not shutil.which("opencpn"):
            QMessageBox.warning(self, "OpenCPN", "OpenCPN is not installed on this Raspberry Pi.")
            return
        if not shutil.which("xdotool"):
            QMessageBox.warning(self, "OpenCPN", "xdotool is not installed. Run the V3 installer again.")
            return
        free = mem_available_mb()
        if free is not None and free < 260:
            r = QMessageBox.question(
                self, "Low memory",
                f"Only {free} MB RAM is available. OpenCPN may be heavy on Raspberry Pi 3.\nOpen it anyway?",
                QMessageBox.Yes | QMessageBox.No
            )
            if r != QMessageBox.Yes:
                return
        self.status.setText("STARTING...")
        try:
            # Reuse an existing OpenCPN window when possible.
            ids = self.find_windows()
            if not ids:
                self.process = subprocess.Popen(
                    ["opencpn"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            self.try_count = 0
            self.timer.start(700)
        except Exception as e:
            QMessageBox.critical(self, "OpenCPN", str(e))

    def find_windows(self):
        try:
            out = subprocess.check_output(
                ["xdotool", "search", "--onlyvisible", "--name", "OpenCPN"],
                stderr=subprocess.DEVNULL,
                text=True
            )
            return [x.strip() for x in out.splitlines() if x.strip().isdigit()]
        except Exception:
            return []

    def try_embed(self):
        self.try_count += 1
        ids = self.find_windows()
        if ids:
            self.timer.stop()
            try:
                wid = int(ids[-1])
                self.foreign_window = QWindow.fromWinId(wid)
                self.container = QWidget.createWindowContainer(self.foreign_window, self)
                self.container.setMinimumSize(420, 320)
                self.main_layout.insertWidget(1, self.container, 1)
                self.placeholder.hide()
                self.button.hide()
                self.status.setText("EMBEDDED")
                self.embedded.emit(True)
                return
            except Exception as e:
                self.status.setText("EMBED FAILED")
                QMessageBox.warning(self, "OpenCPN", f"Could not embed OpenCPN window:\n{e}")
                return
        if self.try_count > 25:
            self.timer.stop()
            self.status.setText("NOT FOUND")
            QMessageBox.warning(self, "OpenCPN", "OpenCPN started, but its X11 window could not be embedded.")

    def move_container_to(self, target_layout):
        if self.container is None:
            return False
        self.container.setParent(None)
        target_layout.addWidget(self.container, 1)
        return True

    def restore_container(self):
        if self.container is None:
            return
        self.container.setParent(None)
        self.main_layout.insertWidget(1, self.container, 1)

class FocusDialog(QDialog):
    def __init__(self, main_window, boat_index):
        super().__init__(main_window)

        from PyQt5.QtWidgets import (
            QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
            QGridLayout, QGroupBox, QSlider, QDial, QFrame
        )
        from PyQt5.QtCore import Qt

        self.main_window = main_window
        self.boat_index = boat_index
        boat = main_window.boats[boat_index]
        boat_name = boat["name"]

        self.setWindowTitle(
            "DOCTOR BOAT CONTROL MARINE INTELLIGENCE · " + boat_name
        )
        self.resize(1100,650)
        self.setMinimumSize(720,480)

        self.setStyleSheet("""
            QDialog {
                background:#07131f;
                color:#e8f4ff;
            }
            QGroupBox {
                border:1px solid #284c66;
                border-radius:10px;
                margin-top:14px;
                padding:10px;
                font-weight:700;
                color:#7fd9ff;
                background:#0b1c2b;
            }
            QGroupBox::title {
                subcontrol-origin:margin;
                left:12px;
                padding:0 6px;
            }
            QLabel {
                color:#dbeeff;
            }
            QPushButton {
                min-height:32px;
                border-radius:7px;
                border:1px solid #35617e;
                padding:4px 10px;
                background:#123047;
                color:white;
                font-weight:700;
            }
            QPushButton:hover {
                background:#194461;
            }
            QPushButton:pressed {
                background:#07131f;
            }
            QSlider::groove:horizontal {
                height:8px;
                background:#17384f;
                border-radius:4px;
            }
            QSlider::handle:horizontal {
                width:18px;
                margin:-6px 0;
                background:#58cfff;
                border-radius:9px;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 10)
        root.setSpacing(8)

        # ===== TOP BAR =====
        top = QHBoxLayout()

        title = QLabel("DOCTOR BOAT CONTROL · MARINE INTELLIGENCE")
        title.setStyleSheet(
            "font-size:20px;font-weight:900;color:#7fd9ff;"
        )
        top.addWidget(title)

        vessel = QLabel("VESSEL: " + boat_name.upper())
        vessel.setStyleSheet(
            "font-size:15px;font-weight:800;color:white;"
        )
        top.addWidget(vessel)

        top.addStretch()

        self.connection_btn = QPushButton("● CONNECTIONS")
        self.connection_btn.clicked.connect(self.show_connections)
        top.addWidget(self.connection_btn)

        close = QPushButton("BACK TO COMMAND CENTER")
        close.clicked.connect(self.close)
        top.addWidget(close)

        root.addLayout(top)

        # ===== MAIN GRID =====
        grid = QGridLayout()
        grid.setSpacing(8)

        # ---------- OPENCPN MAP ----------
        map_frame = QGroupBox("OPENCPN · LIVE NAVIGATION")
        self.map_host = QVBoxLayout(map_frame)
        self.map_host.setContentsMargins(5, 12, 5, 5)

        map_title = QLabel(
            "LIVE CHART · GNSS POSITION · HEADING · TRACK"
        )
        map_title.setAlignment(Qt.AlignCenter)
        map_title.setStyleSheet(
            "font-size:11px;color:#80dfff;"
        )
        self.map_host.addWidget(map_title)

        grid.addWidget(map_frame, 0, 0, 1, 2)

        # ---------- CAMERA ----------
        camera = QGroupBox("LIVE CAMERA · JAWAD 1")
        camera_l = QVBoxLayout(camera)

        cam_screen = QLabel(
            "LIVE VIDEO\n\nCAMERA FEED READY"
        )
        cam_screen.setAlignment(Qt.AlignCenter)
        cam_screen.setMinimumHeight(190)
        cam_screen.setStyleSheet("""
            background:#02070c;
            border:1px solid #31536a;
            border-radius:8px;
            font-size:18px;
            font-weight:800;
            color:#7894a5;
        """)
        camera_l.addWidget(cam_screen)

        grid.addWidget(camera, 0, 2, 1, 2)

        # ---------- LIDAR / PLAN VIEW ----------
        lidar = QGroupBox("360° LIDAR · PLAN VIEW · LINE STATUS")
        lidar_l = QVBoxLayout(lidar)

        lidar_screen = QLabel(
            "                 000°\n"
            "          · · · · | · · · ·\n"
            "      270° ─── [ JAWAD 1 ] ─── 090°\n"
            "          · · · · | · · · ·\n"
            "                 180°\n\n"
            "       ◉ 360° LIDAR SCAN ACTIVE\n"
            "       ├── FORWARD LINE\n"
            "       └── AFT LINE"
        )
        lidar_screen.setAlignment(Qt.AlignCenter)
        lidar_screen.setMinimumHeight(210)
        lidar_screen.setStyleSheet("""
            background:#020b10;
            border:1px solid #1d6076;
            border-radius:8px;
            color:#58d8ff;
            font-family:monospace;
            font-size:13px;
        """)
        lidar_l.addWidget(lidar_screen)

        line_grid = QGridLayout()

        let_fwd = QPushButton("LET GO FORWARD LINE")
        secure_fwd = QPushButton("SECURE FORWARD LINE")
        let_aft = QPushButton("LET GO AFT LINE")
        secure_aft = QPushButton("SECURE AFT LINE")

        let_fwd.clicked.connect(
            lambda: self.line_action("FORWARD", "RELEASED")
        )
        secure_fwd.clicked.connect(
            lambda: self.line_action("FORWARD", "SECURED")
        )
        let_aft.clicked.connect(
            lambda: self.line_action("AFT", "RELEASED")
        )
        secure_aft.clicked.connect(
            lambda: self.line_action("AFT", "SECURED")
        )

        line_grid.addWidget(let_fwd, 0, 0)
        line_grid.addWidget(secure_fwd, 0, 1)
        line_grid.addWidget(let_aft, 1, 0)
        line_grid.addWidget(secure_aft, 1, 1)

        self.line_status = QLabel(
            "FORWARD: SECURED     |     AFT: SECURED"
        )
        self.line_status.setAlignment(Qt.AlignCenter)

        lidar_l.addLayout(line_grid)
        lidar_l.addWidget(self.line_status)

        grid.addWidget(lidar, 1, 0)

        # ---------- FIREFIGHTING ----------
        firefighting = QGroupBox("FIREFIGHTING CONTROL")
        fire_l = QVBoxLayout(firefighting)

        pump_row = QHBoxLayout()
        pump_on = QPushButton("FIFI PUMP ON")
        pump_off = QPushButton("FIFI PUMP OFF")

        self.pump_status = QLabel("PUMP: OFF")
        self.pump_status.setAlignment(Qt.AlignCenter)

        pump_on.clicked.connect(
            lambda: self.pump_status.setText("PUMP: ON")
        )
        pump_off.clicked.connect(
            lambda: self.pump_status.setText("PUMP: OFF")
        )

        pump_row.addWidget(pump_on)
        pump_row.addWidget(pump_off)
        fire_l.addLayout(pump_row)
        fire_l.addWidget(self.pump_status)

        fire_label = QLabel("FIRE MONITOR AZIMUTH · 360°")
        fire_label.setAlignment(Qt.AlignCenter)
        fire_l.addWidget(fire_label)

        self.fire_dial = QDial()
        self.fire_dial.setRange(0, 359)
        self.fire_dial.setWrapping(True)
        self.fire_dial.setNotchesVisible(True)

        self.fire_angle = QLabel("MONITOR: 000°")
        self.fire_angle.setAlignment(Qt.AlignCenter)

        self.fire_dial.valueChanged.connect(
            lambda v: self.fire_angle.setText(
                "MONITOR: %03d°" % v
            )
        )

        fire_l.addWidget(self.fire_dial)
        fire_l.addWidget(self.fire_angle)

        grid.addWidget(firefighting, 1, 1)

        # ---------- RUDDER ----------
        steering = QGroupBox("HYDRAULIC STEERING · RUDDER")
        steer_l = QVBoxLayout(steering)

        self.rudder_value = QLabel("MIDSHIP · 0°")
        self.rudder_value.setAlignment(Qt.AlignCenter)
        self.rudder_value.setStyleSheet(
            "font-size:19px;font-weight:900;color:#7fd9ff;"
        )

        self.rudder = QSlider(Qt.Horizontal)
        self.rudder.setRange(-30, 30)
        self.rudder.setValue(0)
        self.rudder.setTickInterval(5)
        self.rudder.setTickPosition(QSlider.TicksBelow)
        self.rudder.valueChanged.connect(self.update_rudder)

        rudder_labels = QHBoxLayout()
        rudder_labels.addWidget(QLabel("PORT 30°"))
        rudder_labels.addStretch()
        rudder_labels.addWidget(QLabel("MIDSHIP"))
        rudder_labels.addStretch()
        rudder_labels.addWidget(QLabel("30° STARBOARD"))

        steer_l.addWidget(self.rudder_value)
        steer_l.addWidget(self.rudder)
        steer_l.addLayout(rudder_labels)

        grid.addWidget(steering, 1, 2)

        # ---------- TWIN ENGINE LEVERS ----------
        propulsion = QGroupBox("TWIN DIGITAL ENGINE CONTROL · PORT / STARBOARD")
        prop_l = QHBoxLayout(propulsion)
        self.engine_levers=[]; self.engine_states=[]
        for eng in ("PORT ENGINE", "STARBOARD ENGINE"):
            col=QVBoxLayout(); lab=QLabel(eng); lab.setAlignment(Qt.AlignCenter); lab.setStyleSheet("font-weight:900;color:#7fd9ff;"); col.addWidget(lab)
            col.addWidget(QLabel("AHEAD +100%"))
            lever=QSlider(Qt.Vertical); lever.setRange(-100,100); lever.setValue(0); lever.setTickInterval(10); lever.setTickPosition(QSlider.TicksBothSides)
            state=QLabel("NEUTRAL · 0%"); state.setAlignment(Qt.AlignCenter); state.setStyleSheet("font-size:13px;font-weight:900;color:#7fd9ff;")
            lever.valueChanged.connect(lambda v, st=state: self.update_engine_state_label(st,v))
            col.addWidget(lever,1); col.addWidget(QLabel("ASTERN -100%")); col.addWidget(state)
            self.engine_levers.append(lever); self.engine_states.append(state); prop_l.addLayout(col)
        grid.addWidget(propulsion, 1, 3)

        # ---------- MACHINERY / DATA ----------
        data = QGroupBox("VESSEL DATA · MACHINERY")
        data_l = QGridLayout(data)

        rows = [
            ("LATITUDE", "—"),
            ("LONGITUDE", "—"),
            ("HEADING · KVH", "—"),
            ("GNSS", "CONNECTED"),
            ("ENGINE 1 RPM", "0"),
            ("ENGINE 1 HOURS", "0.0 h"),
            ("ENGINE 1 CONSUMPTION", "0.0 L/h"),
            ("ENGINE 2 RPM", "0"),
            ("ENGINE 2 HOURS", "0.0 h"),
            ("ENGINE 2 CONSUMPTION", "0.0 L/h"),
        ]

        for r, (name, value) in enumerate(rows):
            a = QLabel(name)
            b = QLabel(value)
            b.setStyleSheet(
                "font-weight:800;color:#75e6a5;"
            )
            data_l.addWidget(a, r, 0)
            data_l.addWidget(b, r, 1)

        grid.addWidget(data, 2, 0, 1, 2)

        # ---------- EXISTING STATUS ----------
        self.status_widget = BoatStatusWidget(
            boat["id"],
            boat["name"]
        )
        self.status_widget.logRequested.connect(
            main_window.start_log
        )
        self.status_widget.stopLogRequested.connect(
            main_window.stop_log
        )
        self.status_widget.set_values(boat)
        self.status_widget.set_recording(
            boat["id"] in main_window.recording
        )

        status_box = QGroupBox("LIVE TELEMETRY · SYSTEM")
        status_l = QVBoxLayout(status_box)
        status_l.addWidget(self.status_widget)

        grid.addWidget(status_box, 2, 2, 1, 2)

        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)
        grid.setColumnStretch(2, 2)
        grid.setColumnStretch(3, 1)

        grid.setRowStretch(0, 3)
        grid.setRowStretch(1, 4)
        grid.setRowStretch(2, 2)

        root.addLayout(grid, 1)

        # Move the existing embedded OpenCPN window into this page.
        self.moved_map = main_window.map_widget.move_container_to(
            self.map_host
        )

    def update_rudder(self, value):
        if value < 0:
            self.rudder_value.setText(
                "PORT · %d°" % abs(value)
            )
        elif value > 0:
            self.rudder_value.setText(
                "STARBOARD · %d°" % value
            )
        else:
            self.rudder_value.setText("MIDSHIP · 0°")

    def update_engine_state_label(self, label, value):
        if -4 <= value <= 4: label.setText("NEUTRAL · 0%"); return
        label.setText(("AHEAD" if value>0 else "ASTERN") + " · %d%%" % abs(value))

    def update_engine_lever(self, value):
        if hasattr(self, "engine_states") and self.engine_states:
            self.update_engine_state_label(self.engine_states[0], value)

    def line_action(self, line_name, state):
        current = self.line_status.text()

        if line_name == "FORWARD":
            aft = (
                "RELEASED"
                if "AFT: RELEASED" in current
                else "SECURED"
            )
            current = (
                "FORWARD: %s     |     AFT: %s"
                % (state, aft)
            )
        else:
            forward = (
                "RELEASED"
                if "FORWARD: RELEASED" in current
                else "SECURED"
            )
            current = (
                "FORWARD: %s     |     AFT: %s"
                % (forward, state)
            )

        self.line_status.setText(current)

    def show_connections(self):
        from PyQt5.QtWidgets import QMessageBox

        QMessageBox.information(
            self,
            "Connections · System Status",
            "● KVH HEADING            CONNECTED\n"
            "● GNSS                   CONNECTED\n"
            "● ENGINE CONTROL         STANDBY\n"
            "● HYDRAULIC STEERING     STANDBY\n"
            "● FIFI MONITOR CONTROL   STANDBY\n"
            "● FIFI PUMP CONTROL      STANDBY\n"
            "● LINE RELEASE 1         STANDBY\n"
            "● LINE RELEASE 2         STANDBY\n"
            "● LIDAR 360°             STANDBY\n"
            "● CAMERA                  STANDBY\n"
            "● 4G / 5G MODEM          STANDBY\n"
            "● SIGNAL K               CONNECTED\n"
            "● OPENCPN                CONNECTED"
        )

    def closeEvent(self, event):
        if self.moved_map:
            self.main_window.map_widget.restore_container()
        super().closeEvent(event)


class CommandCenter(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        root = QVBoxLayout(self)
        split = QSplitter(Qt.Horizontal)

        self.map_widget = OpenCPNEmbedWidget()
        split.addWidget(self.map_widget)

        cameras = QWidget()
        cv = QVBoxLayout(cameras)
        self.cam1 = CameraPanel("DR BOAT 1")
        self.cam2 = CameraPanel("DR BOAT 2")
        self.cam1.doubleClicked.connect(lambda: main_window.open_focus(0))
        self.cam2.doubleClicked.connect(lambda: main_window.open_focus(1))
        cv.addWidget(self.cam1)
        cv.addWidget(self.cam2)
        split.addWidget(cameras)
        split.setSizes([900, 420])
        root.addWidget(split, 3)

        fleet = QHBoxLayout()
        self.b1 = BoatStatusWidget("DB1", "DR BOAT 1")
        self.b2 = BoatStatusWidget("DB2", "DR BOAT 2")
        for w in (self.b1, self.b2):
            w.logRequested.connect(main_window.start_log)
            w.stopLogRequested.connect(main_window.stop_log)
            fleet.addWidget(w)
        root.addLayout(fleet, 2)


        ai = QFrame()
        ai.setObjectName("panel")
        al = QHBoxLayout(ai)
        al.addWidget(QLabel("AI CONSOLE"))
        self.voice = QLineEdit()
        self.voice.setPlaceholderText("Voice / mission command")
        al.addWidget(self.voice, 1)
        send = QPushButton("SEND / SIMULATE VOICE")
        send.clicked.connect(main_window.set_voice)
        al.addWidget(send)
        root.addWidget(ai)

class LibraryPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QHBoxLayout(self)
        left = QVBoxLayout()
        title = QLabel("AI TRAINING & MANEUVER LIBRARY")
        title.setObjectName("pageTitle")
        left.addWidget(title)
        self.list = QListWidget()
        self.list.itemDoubleClicked.connect(self.open_item)
        left.addWidget(self.list)
        refresh = QPushButton("REFRESH LIBRARY")
        refresh.clicked.connect(self.reload)
        left.addWidget(refresh)
        lw = QWidget(); lw.setLayout(left)
        root.addWidget(lw, 1)
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        root.addWidget(self.detail, 2)
        self.reload()

    def reload(self):
        self.list.clear()
        for f in sorted(MISSIONS_DIR.glob("*.jsonl"), key=lambda x: x.stat().st_mtime, reverse=True):
            self.list.addItem(QListWidgetItem(f.stem))

    def open_item(self, item):
        f = MISSIONS_DIR / (item.text()+".jsonl")
        rows = []
        try:
            lines = f.read_text(encoding="utf-8").splitlines()
            for line in lines[-120:]:
                if not line.strip(): continue
                r = json.loads(line)
                b = r.get("boat", {})
                rows.append(
                    f"{r.get('time','')} | {b.get('name','')} | "
                    f"HDG {int(b.get('heading',0))}° | "
                    f"PORT {b.get('port_angle',0)}° / {b.get('port_rpm',0)} RPM | "
                    f"STBD {b.get('stbd_angle',0)}° / {b.get('stbd_rpm',0)} RPM"
                )
            self.detail.setPlainText("\n".join(rows) or "No samples.")
        except Exception as e:
            self.detail.setPlainText(str(e))

class TrainingPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root=QVBoxLayout(self)
        hero=QFrame(); hero.setObjectName('panel'); h=QHBoxLayout(hero); txt=QVBoxLayout()
        z=QLabel('PILOT & TUG MASTER TRAINING · V5.1'); z.setObjectName('pageTitle'); txt.addWidget(z)
        d=QLabel('Professional maneuver training with Mina Zayed chart-style scene, slow target-vessel motion, four ASD tugs and six selectable securing points.'); d.setWordWrap(True); txt.addWidget(d); h.addLayout(txt,1)
        launch=QPushButton('OPEN TRAINING SIMULATOR'); launch.setMinimumHeight(60); launch.clicked.connect(self.open_sim); h.addWidget(launch); root.addWidget(hero)
        grid=QGridLayout()
        for i,(t,d) in enumerate([
            ('PILOT TRAINING','Approach · berth planning · ship speed/rudder · tug allocation.'),
            ('TUG MASTER TRAINING','Clock-angle orders · push/pull power · secure-line approach.'),
            ('6 SECURING POINTS','Center Lead Bow/Aft · Starboard Bow/Quarter · Port Bow/Quarter.'),
            ('TARGET UNITS','Container · Bulk · Tanker · General Cargo · Jack-up Barge · Tug & Barge.')]):
            box=QFrame(); box.setObjectName('panel'); l=QVBoxLayout(box); a=QLabel(t); a.setObjectName('sectionTitle'); b=QLabel(d); b.setWordWrap(True); l.addWidget(a); l.addWidget(b); l.addStretch(); grid.addWidget(box,i//2,i%2)
        root.addLayout(grid); root.addStretch()
    def open_sim(self): SimulatorDialog(self).exec_()

class PropulsionPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        title = QLabel("PROPULSION MANAGER")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        grid = QGridLayout()
        for i,(t,d) in enumerate([
            ("TWIN AZIMUTH", "360° Port + Starboard ASD"),
            ("TWIN SCREW", "Port + Starboard engine / rudder"),
            ("SINGLE SCREW", "Engine + conventional rudder"),
        ]):
            box=QFrame(); box.setObjectName("panel")
            l=QVBoxLayout(box)
            q=QLabel(t); q.setObjectName("sectionTitle")
            l.addWidget(q); l.addWidget(QLabel(d)); l.addStretch()
            grid.addWidget(box,0,i)
        root.addLayout(grid)
        mode = QFrame(); mode.setObjectName("panel")
        ml=QHBoxLayout(mode)
        ml.addWidget(QLabel("CONTROL MODE"))
        self.combo=QComboBox()
        self.combo.addItems(["MANUAL", "ASSISTED", "AUTONOMOUS"])
        ml.addWidget(self.combo)
        ml.addStretch()
        root.addWidget(mode)
        root.addStretch()

class SystemPage(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.manifest = None
        root = QVBoxLayout(self)
        title = QLabel("SYSTEM / UPDATES")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        info = QFrame(); info.setObjectName("panel")
        il=QVBoxLayout(info)
        self.version = QLabel(f"Installed: V{APP_VERSION} · Raspberry Pi 3")
        self.version.setObjectName("sectionTitle")
        il.addWidget(self.version)
        btns=QHBoxLayout()
        health=QPushButton("SYSTEM HEALTH"); health.clicked.connect(self.check_health)
        upd=QPushButton("CHECK FOR UPDATES"); upd.clicked.connect(self.check_updates)
        self.install=QPushButton("DOWNLOAD & INSTALL UPDATE"); self.install.setEnabled(False); self.install.clicked.connect(self.install_update)
        for b in (health,upd,self.install): btns.addWidget(b)
        il.addLayout(btns)
        self.output=QTextEdit(); self.output.setReadOnly(True); self.output.setMinimumHeight(220)
        il.addWidget(self.output)
        root.addWidget(info)
        root.addStretch()

    def check_health(self):
        disk = shutil.disk_usage(str(Path.home()))
        self.output.setPlainText(
            f"DR.BOAT V{APP_VERSION}\n"
            f"CPU temperature: {cpu_temp_c() if cpu_temp_c() is not None else 'N/A'} °C\n"
            f"Available RAM: {mem_available_mb() if mem_available_mb() is not None else 'N/A'} MB\n"
            f"Free disk: {disk.free//(1024**3)} GB\n"
            f"OpenCPN: {'INSTALLED' if shutil.which('opencpn') else 'NOT INSTALLED'}\n"
            f"xdotool: {'INSTALLED' if shutil.which('xdotool') else 'NOT INSTALLED'}\n"
            f"Update manifest: {UPDATE_MANIFEST}"
        )

    def check_updates(self):
        self.output.setPlainText("Checking GitHub update server over HTTPS...")
        QApplication.processEvents()
        try:
            req = urllib.request.Request(UPDATE_MANIFEST, headers={"User-Agent":"DRBOAT-V3"})
            with urllib.request.urlopen(req, timeout=12) as r:
                manifest = json.loads(r.read().decode("utf-8"))
            self.manifest = manifest
            latest = manifest.get("version","0.0.0")
            notes = manifest.get("notes","")
            if isinstance(notes, list): notes = "\n".join("• "+str(x) for x in notes)
            text = (
                f"Current version: {APP_VERSION}\n"
                f"Latest version: {latest}\n"
                f"Server: CONNECTED (HTTPS)\n\n"
                f"Release notes:\n{notes}"
            )
            if version_tuple(latest) > version_tuple(APP_VERSION):
                text += "\n\nUPDATE AVAILABLE."
                self.install.setEnabled(True)
            else:
                text += "\n\nYou are up to date."
                self.install.setEnabled(False)
            self.output.setPlainText(text)
        except Exception as e:
            self.install.setEnabled(False)
            self.output.setPlainText(
                "Update server is not ready yet.\n\n"
                "V3 is already configured to read:\n"
                f"{UPDATE_MANIFEST}\n\n"
                f"Error: {e}\n\n"
                "Upload version.json to your GitHub repository to activate future online updates."
            )

    def install_update(self):
        if not self.manifest:
            return
        url = self.manifest.get("package_url")
        want_sha = self.manifest.get("sha256","").lower()
        if not url:
            QMessageBox.warning(self, "Update", "package_url is missing from version.json")
            return
        if QMessageBox.question(
            self, "Install update",
            "DR.BOAT will download the update, verify it, back up the current version, then restart.\nContinue?",
            QMessageBox.Yes | QMessageBox.No
        ) != QMessageBox.Yes:
            return
        try:
            tmpdir = Path(tempfile.mkdtemp(prefix="drboat-update-"))
            zpath = tmpdir / "update.zip"
            self.output.setPlainText("Downloading update...")
            QApplication.processEvents()
            req = urllib.request.Request(url, headers={"User-Agent":"DRBOAT-V3"})
            with urllib.request.urlopen(req, timeout=60) as r, zpath.open("wb") as f:
                while True:
                    chunk = r.read(1024*128)
                    if not chunk: break
                    f.write(chunk)
            got_sha = hashlib.sha256(zpath.read_bytes()).hexdigest()
            if want_sha and got_sha != want_sha:
                raise RuntimeError(f"SHA256 mismatch.\nExpected: {want_sha}\nReceived: {got_sha}")
            extract = tmpdir / "extract"
            extract.mkdir()
            with zipfile.ZipFile(zpath) as z:
                z.extractall(extract)
            dirs = [p for p in extract.iterdir() if p.is_dir()]
            if not dirs:
                raise RuntimeError("Update package has no application directory.")
            src = dirs[0]
            helper = tmpdir / "apply_update.sh"
            appdir = APP_DIR
            backup = APP_DIR.parent / (APP_DIR.name + ".backup")
            launcher = Path.home()/".local/bin/drboat"
            helper.write_text(f"""#!/bin/bash
set -e
sleep 2
rm -rf "{backup}"
mv "{appdir}" "{backup}"
mkdir -p "{appdir}"
cp -a "{src}/." "{appdir}/"
if [ -d "{backup}/data" ]; then
  rm -rf "{appdir}/data"
  cp -a "{backup}/data" "{appdir}/data"
fi
"{launcher}" >/dev/null 2>&1 &
""")
            os.chmod(helper,0o755)
            subprocess.Popen(["bash", str(helper)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            QApplication.instance().quit()
        except Exception as e:
            QMessageBox.critical(self, "Update failed", str(e))


class FleetCard(QFrame):
    doubleClicked = pyqtSignal(str)
    def __init__(self, vessel, parent=None):
        super().__init__(parent); self.vessel=vessel; self.setObjectName('fleetCard'); self.setMinimumHeight(94)
        l=QVBoxLayout(self); n=QLabel(vessel['name']); n.setStyleSheet('font-size:16px;font-weight:900;color:#eaf8ff;'); l.addWidget(n)
        role=QLabel(vessel.get('type','VESSEL')+' · '+vessel.get('location','FLEET UNIT')); role.setStyleSheet('color:#8fc7dc;'); l.addWidget(role)
        st=QLabel('ONLINE' if vessel.get('active_map') or vessel.get('id')=='JAWAD_1' else 'STANDBY'); st.setStyleSheet('color:#46e39c;font-weight:bold;' if st.text()=='ONLINE' else 'color:#f2c35b;font-weight:bold;'); l.addWidget(st)
        hint=QLabel('DOUBLE CLICK TO OPEN' if vessel.get('id')=='JAWAD_1' else 'DOUBLE CLICK FOR VESSEL DETAILS'); hint.setStyleSheet('font-size:10px;color:#6fa0b3;'); l.addWidget(hint)
    def mouseDoubleClickEvent(self,e): self.doubleClicked.emit(self.vessel['id']); super().mouseDoubleClickEvent(e)

class FleetPage(QWidget):
    VESSELS = [
        {'id':'SEMAIH','name':'M/T SEMAIH','type':'ASD','location':'Mina Zayed','active_map':True},
        {'id':'AL_FANCI','name':'M/T AL FANCI','type':'ASD','location':'Mina Zayed','active_map':True},
        {'id':'SILA','name':'M/T SILA','type':'ASD'},
        {'id':'AL_AIN','name':'M/T AL AIN','type':'ASD'},
        {'id':'DURAH','name':'M/T DURAH','type':'ASD'},
        {'id':'BUTTINA_1','name':'EM/T BUTTINA 1','type':'ASD'},
        {'id':'BUTTINA_2','name':'EM/T BUTTINA 2','type':'ASD'},
        {'id':'KIZAD','name':'M/T KIZAD','type':'ASD'},
        {'id':'DAS','name':'M/T DAS','type':'ASD'},
        {'id':'MARIA','name':'M/T MARIA','type':'ASD'},
        {'id':'MQTA','name':'M/T MQTA','type':'CONVENTIONAL'},
        {'id':'SAFFER_1','name':'P/B SAFFER 1','type':'CONVENTIONAL'},
        {'id':'SAFFER_2','name':'P/B SAFFER 2','type':'CONVENTIONAL'},
        {'id':'SAFFER_3','name':'P/B SAFFER 3','type':'CONVENTIONAL'},
        {'id':'JAWAD_1','name':'Fire Fighting & Security Boat JAWAD 1','type':'CONVENTIONAL','location':'Yas Marina','active_map':True,'firefighting':True},
    ]
    def __init__(self, main_window, parent=None):
        super().__init__(parent); self.main_window=main_window
        root=QVBoxLayout(self); title=QLabel('FLEET LIST · 15 VESSELS'); title.setObjectName('pageTitle'); root.addWidget(title)
        note=QLabel('JAWAD 1 is managed inside Fleet List only. Double-click JAWAD 1 to open its dedicated remote-control screen.'); note.setObjectName('note'); root.addWidget(note)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); body=QWidget(); grid=QGridLayout(body); grid.setSpacing(8)
        for i,v in enumerate(self.VESSELS):
            c=FleetCard(v); c.doubleClicked.connect(self.open_vessel); grid.addWidget(c,i//3,i%3)
        scroll.setWidget(body); root.addWidget(scroll,1)
    def open_vessel(self, vid):
        v=next(x for x in self.VESSELS if x['id']==vid)
        if vid=='JAWAD_1':
            idx=next((i for i,b in enumerate(self.main_window.boats) if b.get('id')=='JAWAD_1'),None)
            if idx is not None: self.main_window.open_focus(idx)
            return
        QMessageBox.information(self, v['name'], f"{v['name']}\nPROPULSION: {v.get('type','—')}\nSTATUS: FLEET PROFILE READY\n\nLive hardware integration will use the vessel-specific profile.")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DOCTOR BOAT CONTROL · MARINE INTELLIGENCE V5.1")
        self.resize(1100,650)
        self.setMinimumSize(720,480)
        self.recording = {}
        self.system_state = "READY"
        self.voice_text = "Awaiting command"
        self.boats = [
            {"id":"DB1","name":"DR BOAT 1","heading":42.0,"battery":92,"link":98,"port_angle":25,"stbd_angle":335,"port_rpm":820,"stbd_rpm":790},
            {"id":"DB2","name":"DR BOAT 2","heading":318.0,"battery":88,"link":96,"port_angle":310,"stbd_angle":50,"port_rpm":640,"stbd_rpm":650},
            {"id":"JAWAD_1","name":"JAWAD 1","heading":0.0,"battery":100,"link":100,"port_angle":0,"stbd_angle":0,"port_rpm":0,"stbd_rpm":0},
        ]

        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(0,0,0,0)

        header = QFrame(); header.setObjectName("header")
        hl=QHBoxLayout(header)
        logo_path=APP_DIR/"static"/"drboat_logo.png"
        logo=QLabel()
        if logo_path.exists():
            pm=QPixmap(str(logo_path)).scaled(92,92,Qt.KeepAspectRatio,Qt.SmoothTransformation)
            logo.setPixmap(pm)
        hl.addWidget(logo)
        tt=QVBoxLayout()
        a=QLabel("DR.BOAT"); a.setObjectName("brandTitle")
        b=QLabel("DOCTOR BOAT CONTROL · MARINE INTELLIGENCE · V5.1"); b.setObjectName("brandSub")
        tt.addWidget(a); tt.addWidget(b)
        hl.addLayout(tt); hl.addStretch()
        ai_badge=QLabel("AI MARINE OPERATIONS · V5.1"); ai_badge.setObjectName("aiBadge"); hl.addWidget(ai_badge)

        root.addWidget(header)

        nav=QFrame(); nav.setObjectName("nav")
        nl=QHBoxLayout(nav)
        names = [
            ("COMMAND CENTER",0),
            ("FLEET CONTROL",1),
            ("AI TRAINING & MANEUVER LIBRARY",2),
            ("PILOT & TUG MASTER TRAINING",3),
            ("SYSTEM / UPDATES",4),
        ]
        for text,idx in names:
            q=QPushButton(text)
            q.clicked.connect(lambda _,i=idx:self.pages.setCurrentIndex(i))
            nl.addWidget(q)
        root.addWidget(nav)

        self.pages=QStackedWidget()
        self.command=CommandCenter(self)
        self.map_widget=self.command.map_widget
        self.fleet=FleetPage(self)
        self.library=LibraryPage()
        self.training=TrainingPage()
        self.system=SystemPage(self)
        for x in (self.command,self.fleet,self.library,self.training,self.system):
            scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setWidget(x)
            self.pages.addWidget(scroll)
        root.addWidget(self.pages,1)
        self.setCentralWidget(central)

        self.apply_style()
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1500)
        self.tick()

    def apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background:#06141e; color:#dcebf2; font-family:Arial; }
        QFrame#header { background:#092333; border-bottom:1px solid #315e72; }
        QFrame#nav { background:#071c28; border-bottom:1px solid #244b5c; }
        QLabel#brandTitle { font-size:30px; font-weight:bold; letter-spacing:3px; }
        QLabel#brandSub { color:#91b4c3; font-size:11px; }
        QLabel#aiBadge { border:1px solid #397b98; border-radius:12px; padding:8px 14px; color:#9ee7ff; font-weight:bold; letter-spacing:1px; background:#0a293a; }
        QPushButton { background:#123648; color:#e2eff4; border:1px solid #3d7186; border-radius:9px; padding:8px 11px; font-weight:600; }
        QPushButton:hover { background:#17455b; }
        QPushButton#recordButton { background:#8b1d26; border-color:#d04450; font-weight:bold; }
        QFrame#panel, QFrame#mapPanel { background:#0b2635; border:1px solid #2f6074; border-radius:12px; }
        QFrame#fleetCard { background:#0d2939; border:1px solid #2e6b86; border-radius:9px; }
        QLabel#camera { background:#081923; border:1px solid #3e7186; color:#9abac8; font-size:14px; }
        QLabel#metric { background:#071923; border:1px solid #173646; padding:7px; font-weight:bold; }
        QLabel#sectionTitle { font-size:15px; font-weight:bold; color:#eaf5fa; }
        QLabel#pageTitle { font-size:21px; font-weight:bold; padding:6px; letter-spacing:1px; }
        QLabel#smallStatus { color:#86aab9; font-size:10px; }
        QLabel#mapPlaceholder { background:#071923; border:1px solid #21475a; color:#86aab9; font-size:15px; }
        QLabel#note { color:#8eb1c0; padding:12px; }
        QLineEdit, QTextEdit, QListWidget, QComboBox { background:#071923; border:1px solid #315e72; color:#e3eef3; padding:7px; }
        """)

    def tick(self):
        for i,b in enumerate(self.boats):
            b["heading"]=(b["heading"]+0.18+(i*0.03))%360
            # Small stable simulation movement until real telemetry is wired.
            b["port_rpm"]=max(0, b["port_rpm"] + (1 if int(time.time())%4==0 else -1 if int(time.time())%5==0 else 0))
            b["stbd_rpm"]=max(0, b["stbd_rpm"] + (1 if int(time.time())%5==0 else -1 if int(time.time())%6==0 else 0))
        self.command.b1.set_values(self.boats[0])
        self.command.b2.set_values(self.boats[1])
        self.command.b1.set_recording("DB1" in self.recording)
        self.command.b2.set_recording("DB2" in self.recording)
        self.append_logs()

    def append_logs(self):
        now=datetime.now().isoformat(timespec="milliseconds")
        for boat_id, name in list(self.recording.items()):
            b=next((x for x in self.boats if x["id"]==boat_id),None)
            if not b: continue
            with (MISSIONS_DIR/(name+".jsonl")).open("a",encoding="utf-8") as f:
                f.write(json.dumps({"time":now,"boat":dict(b)},ensure_ascii=False)+"\n")

    def start_log(self, boat_id):
        name, ok = self.get_mission_name()
        if not ok: return
        safe="".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name) or "Maneuver"
        mission=f"{safe}_{boat_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.recording[boat_id]=mission
        self.library.reload()

    def get_mission_name(self):
        # Keep V3 dependency-light: use a small custom dialog instead of QInputDialog.
        d=QDialog(self); d.setWindowTitle("Log Maneuver")
        l=QVBoxLayout(d)
        l.addWidget(QLabel("Maneuver name"))
        e=QLineEdit("Cast_Off"); l.addWidget(e)
        row=QHBoxLayout()
        okb=QPushButton("START LOG"); cb=QPushButton("CANCEL")
        row.addWidget(okb); row.addWidget(cb); l.addLayout(row)
        result={"ok":False}
        okb.clicked.connect(lambda:(result.update(ok=True),d.accept()))
        cb.clicked.connect(d.reject)
        d.exec_()
        return e.text().strip(), result["ok"]

    def stop_log(self, boat_id):
        self.recording.pop(boat_id,None)
        self.library.reload()

    def set_voice(self):
        self.voice_text=self.command.voice.text().strip() or "Awaiting command"
        QMessageBox.information(self,"AI Console",f"Simulation command received:\n{self.voice_text}")

    def estop(self):
        self.system_state="SIM E-STOP"
        for b in self.boats:
            b["port_rpm"]=0; b["stbd_rpm"]=0

    def reset_estop(self):
        self.system_state="READY"

    def open_focus(self, boat_index):
        d=FocusDialog(self,boat_index)
        d.exec_()


def refresh_desktop_shortcut():
    """Keep the desktop launcher name/path aligned with the running release."""
    try:
        desk=Path.home()/"Desktop"
        desk.mkdir(exist_ok=True)
        target=desk/f"Doctor Boat Control Marine Intelligence V{APP_VERSION}.desktop"
        content=("[Desktop Entry]\n"
                 "Version=1.0\nType=Application\n"
                 f"Name=Doctor Boat Control Marine Intelligence V{APP_VERSION}\n"
                 f"Comment=DR.BOAT AI Marine Control V{APP_VERSION}\n"
                 f"Exec=env DISPLAY=:0 XAUTHORITY={Path.home()}/.Xauthority python3 \\\"{APP_DIR/'main.py'}\\\"\n"
                 f"Icon={APP_DIR/'static/drboat_logo.png'}\n"
                 "Terminal=false\nCategories=Utility;\nStartupNotify=true\n")
        # remove obsolete Doctor Boat version launchers, leave unrelated DR-BOAT launcher untouched
        for old in desk.glob("Doctor Boat Control Marine Intelligence V*.desktop"):
            if old != target:
                try: old.unlink()
                except Exception: pass
        target.write_text(content,encoding='utf-8'); os.chmod(target,0o755)
    except Exception:
        pass

def main():
    refresh_desktop_shortcut()
    app=QApplication(sys.argv)
    w=MainWindow()
    w.show()
    sys.exit(app.exec_())

if __name__=="__main__":
    main()
