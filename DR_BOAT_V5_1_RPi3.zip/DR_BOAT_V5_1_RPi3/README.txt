DR.BOAT V5.1 — Raspberry Pi 3 / OpenPlotter

V5.1 update highlights
- Removed READY and EMERGENCY STOP from the global header.
- Removed Propulsion Manager from the main navigation.
- Main pages are wrapped in responsive scroll areas for smaller Raspberry Pi displays.
- Main, JAWAD/focus and training windows are resizable instead of forced full-screen.
- Training simulator: mouse-wheel zoom, left-drag pan and double-click view reset.
- Cleaner six-position tug-station geometry with Center Lead Bow/Aft moved farther from the vessel.
- Yellow markers now represent tug stations; tow lines terminate on vessel securing points.
- Improved label spacing around the training vessel.
- Added simple distinct target drawings: Container, Bulk Carrier, Tanker, General Cargo, Jack-up Barge.
- Added TUG & BARGE target with rectangular barge, Y-bridle and towing tug.
- New simple Mina Zayed-inspired inner-harbour training map with quays, breakwaters, approach channel and buoy line.
- Slower maneuver motion for training.
- More modern AI marine-monitoring visual treatment.
- Desktop shortcut self-refreshes to the running V5.1 name/path/icon.
- Existing Fleet List, JAWAD controls, OpenCPN, camera, telemetry, FiFi, LiDAR, line release and update framework retained.

Note: The Mina Zayed scene is a simplified training representation, not an official nautical chart and not for navigation.
