
import os, sys, json, math, time, shutil, hashlib, zipfile, tempfile, subprocess, urllib.request, re
from pathlib import Path
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QUrl, QProcess, QSize, QPointF, QRectF
from PyQt5.QtGui import QPixmap, QPainter, QPen, QColor, QFont, QWindow
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QGridLayout, QStackedWidget, QFrame, QMessageBox, QSplitter, QDialog, QListWidget,
    QListWidgetItem, QTextEdit, QLineEdit, QComboBox, QProgressBar, QScrollArea, QSlider,
    QGroupBox, QDial, QAbstractItemView, QFileDialog
)

APP_VERSION = "8.3.0"
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
MISSIONS_DIR = DATA_DIR / "missions"
MISSIONS_DIR.mkdir(parents=True, exist_ok=True)
UPDATE_MANIFEST = "https://raw.githubusercontent.com/DRBOAT/DRBOAT.update/main/version.json"

def version_tuple(v):
    out = []
    for p in str(v).split("."):
        m = "".join(ch for ch in p if ch.isdigit())
        out.append(int(m or 0))
    return tuple((out + [0,0,0])[:3])

def mem_available_mb():
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) // 1024
    except Exception:
        pass
    return None

def cpu_temp_c():
    try:
        return int(Path("/sys/class/thermal/thermal_zone0/temp").read_text().strip()) / 1000.0
    except Exception:
        return None


class ManeuverCanvas(QWidget):
    """Interactive tug-maneuver trainer with simple force/moment physics.

    V5.4 rules:
    - 1..4 active tugs, each assignable to any station.
    - Every tug can PULL, STOP/FOLLOW, or PUSH.
    - Center-lead bow/aft stations remain attached to the vessel and follow its motion.
    - Clock orders are relative to the vessel heading (12 = dead ahead).
    - Quays are solid training boundaries; the vessel cannot pass through them.
    - HDG / SOG / ROT are derived live from the simulated motion.
    """
    SECURE_POINTS = [
        ("CENTER LEAD BOW",       0.000, -0.102, 'TOW'),
        ("CENTER LEAD AFT",       0.000,  0.102, 'TOW'),
        ("STARBOARD BOW",         0.038, -0.060, 'SIDE'),
        ("STARBOARD QUARTER",     0.038,  0.060, 'SIDE'),
        ("PORT BOW",             -0.038, -0.060, 'SIDE'),
        ("PORT QUARTER",         -0.038,  0.060, 'SIDE'),
    ]
    # x, y, width, height in normalized map coordinates.
    SOLID_QUAYS = [
        (.785, .18, .030, .66),
        (.605, .105, .365, .030),
        (.000, .745, .355, .032),
        (.115, .545, .165, .026),
    ]
    PULL_LEVELS = {
        'TIGHT LINE': .10,
        'SLOW TIGHT LINE': .32,
        'HALF TIGHT LINE': .62,
        'FULL TIGHT LINE': 1.00,
    }
    PUSH_LEVELS = {
        'LEAN ON': .08,
        'MINI PUSH': .20,
        'SLOW PUSH': .38,
        'HALF POWER PUSH': .65,
        'FULL POWER PUSH': 1.00,
    }

    def __init__(self,parent=None):
        super().__init__(parent)
        self.setMinimumSize(720,560); self.setMouseTracking(True)
        self.running=False; self.secured=False
        self.ship_x=.50; self.ship_y=.39; self.ship_heading=180.; self.ship_speed_cmd=0.; self.rudder=0.
        self.vx=0.; self.vy=0.; self.omega=0.
        self.zoom=1.; self.pan_x=0.; self.pan_y=0.; self._drag=None
        self.view_mode='MARINE CHART'; self.ship_type='CONTAINER SHIP'; self.active_tug_count=4
        defaults=[0,1,2,5]
        self.tugs=[]
        for i in range(4):
            self.tugs.append({
                'name':f'TUG {i+1}','x':.20+i*.17,'y':.13,'angle':0.,'visual_angle':180.,
                'secured':False,'point':defaults[i],'action':'STOP / FOLLOW','level':'TIGHT LINE'
            })
        self.timer=QTimer(self); self.timer.timeout.connect(self.step); self.timer.start(50)
        self._build_ship_overlay()

    def _build_ship_overlay(self):
        self.ship_overlay=QFrame(self)
        self.ship_overlay.setObjectName('panel')
        self.ship_overlay.setStyleSheet('QFrame{background:rgba(4,25,36,215);border:1px solid #41616b;border-radius:7px;} QPushButton{min-height:24px;padding:2px 7px;font-size:9px;} QLabel{font-size:9px;}')
        lay=QVBoxLayout(self.ship_overlay); lay.setContentsMargins(6,4,6,4); lay.setSpacing(2)
        head=QLabel('SHIP CONTROL'); head.setAlignment(Qt.AlignCenter); lay.addWidget(head)
        row=QHBoxLayout(); row.setSpacing(3)
        for text,val in [('ASTERN',-0.00105),('STOP',0.0),('D.SLOW',0.00063),('FULL AHEAD',0.00210)]:
            b=QPushButton(text); b.setMinimumWidth(52); b.clicked.connect(lambda _,q=val:setattr(self,'ship_speed_cmd',q)); row.addWidget(b)
        lay.addLayout(row)
        rudrow=QHBoxLayout(); rudrow.setSpacing(4)
        lab=QLabel('RUDDER'); rudrow.addWidget(lab)
        self.overlay_rudder=QSlider(Qt.Horizontal); self.overlay_rudder.setRange(-35,35); self.overlay_rudder.setFixedWidth(150); self.overlay_rudder.valueChanged.connect(lambda x:setattr(self,'rudder',x)); rudrow.addWidget(self.overlay_rudder)
        self.overlay_rudder_label=QLabel('0°'); self.overlay_rudder_label.setFixedWidth(30); self.overlay_rudder.valueChanged.connect(lambda x:self.overlay_rudder_label.setText(f'{x:+d}°')); rudrow.addWidget(self.overlay_rudder_label)
        lay.addLayout(rudrow)
        self.ship_overlay.adjustSize(); self.ship_overlay.raise_()

    def resizeEvent(self,e):
        super().resizeEvent(e)
        if hasattr(self,'ship_overlay'):
            self.ship_overlay.adjustSize()
            m=12
            self.ship_overlay.move(max(m,self.width()-self.ship_overlay.width()-m), max(72,self.height()-self.ship_overlay.height()-m))

    def reset_sim(self):
        self.running=False; self.secured=False
        self.ship_x=.50; self.ship_y=.39; self.ship_heading=180.; self.ship_speed_cmd=0.; self.rudder=0.
        self.vx=self.vy=self.omega=0.; self.zoom=1.; self.pan_x=self.pan_y=0.
        if hasattr(self,'overlay_rudder'): self.overlay_rudder.setValue(0)
        defaults=[0,1,2,5]
        for i,t in enumerate(self.tugs):
            t.update(x=.20+i*.17,y=.13,angle=0.,visual_angle=180.,secured=False,point=defaults[i],action='STOP / FOLLOW',level='TIGHT LINE')
        self.update()

    def start(self): self.running=True
    def secure(self): self.secured=True

    def _rot_point(self, ox, oy):
        a=math.radians(self.ship_heading)
        return (self.ship_x+ox*math.cos(a)-oy*math.sin(a), self.ship_y+ox*math.sin(a)+oy*math.cos(a))

    @staticmethod
    def _clock_vec(deg):
        r=math.radians(deg); return math.sin(r), -math.cos(r)

    def _relative_clock_vec(self,deg):
        return self._clock_vec((self.ship_heading+deg)%360)

    def attach_xy(self, idx):
        _,ax,ay,_=self.SECURE_POINTS[idx]; return self._rot_point(ax,ay)

    def tug_station_xy(self, idx, clock_deg):
        name,ax,ay,kind=self.SECURE_POINTS[idx]
        axw,ayw=self._rot_point(ax,ay)
        if kind=='TOW':
            dx,dy=self._relative_clock_vec(clock_deg)
            return axw+dx*.135, ayw+dy*.135
        # Side stations: use a fixed stand-off normal so a tug never enters the hull.
        side = 1 if ax > 0 else -1
        bowq = -1 if ay < 0 else 1
        local_x=.067*side; local_y=.064*bowq
        return self._rot_point(local_x,local_y)

    @staticmethod
    def _ang_lerp(a,b,k):
        d=(b-a+180)%360-180; return (a+d*k)%360

    def _apply_force(self, fx, fy, ax, ay, magnitude):
        self.vx += fx*magnitude
        self.vy += fy*magnitude
        rx=ax-self.ship_x; ry=ay-self.ship_y
        self.omega += (rx*fy-ry*fx)*magnitude*1450.

    def _tug_level_factor(self,t):
        if t['action']=='PULL': return self.PULL_LEVELS.get(t['level'],0.)
        if t['action']=='PUSH': return self.PUSH_LEVELS.get(t['level'],0.)
        return 0.

    def _resolve_quay_collision(self,oldx,oldy):
        # Approximate the ship footprint by a conservative circle. This intentionally
        # prevents visual penetration and is stable on Raspberry Pi hardware.
        radius=.050
        hit=False
        for qx,qy,qw,qh in self.SOLID_QUAYS:
            ex0,ey0=qx-radius,qy-radius; ex1,ey1=qx+qw+radius,qy+qh+radius
            if ex0 <= self.ship_x <= ex1 and ey0 <= self.ship_y <= ey1:
                hit=True
                # Restore the axis that crossed the boundary first.
                if not (ex0 <= oldx <= ex1):
                    self.ship_x = ex0 if oldx < ex0 else ex1
                    self.vx = 0.
                elif not (ey0 <= oldy <= ey1):
                    self.ship_y = ey0 if oldy < ey0 else ey1
                    self.vy = 0.
                else:
                    # Already touching: keep outside by nearest edge.
                    d=[(abs(self.ship_x-ex0),'x',ex0),(abs(self.ship_x-ex1),'x',ex1),(abs(self.ship_y-ey0),'y',ey0),(abs(self.ship_y-ey1),'y',ey1)]
                    _,axis,val=min(d,key=lambda z:z[0])
                    if axis=='x': self.ship_x=val; self.vx=0.
                    else: self.ship_y=val; self.vy=0.
                self.omega *= .55
        return hit

    def navigation_data(self):
        # Scale normalized map velocity to a deliberately slow training SOG.
        sog=math.hypot(self.vx,self.vy)*6200.0
        rot=self.omega*60.0
        return self.ship_heading%360, sog, rot

    def step(self):
        if not self.running: return
        dt=.05
        # Slow own-ship propulsion. Command values represent desired training velocity.
        dx,dy=self._relative_clock_vec(0)
        target_vx=dx*self.ship_speed_cmd; target_vy=dy*self.ship_speed_cmd
        self.vx += (target_vx-self.vx)*.020
        self.vy += (target_vy-self.vy)*.020
        self.omega += self.rudder*self.ship_speed_cmd*.0040*dt

        if self.secured:
            for i,t in enumerate(self.tugs):
                if i>=self.active_tug_count: continue
                idx=t['point']; ax,ay=self.attach_xy(idx)
                tx,ty=self.tug_station_xy(idx,t['angle'])
                kind=self.SECURE_POINTS[idx][3]

                if kind=='TOW':
                    # Orbit around the actual bow/aft fairlead, always moving with the ship.
                    cur=math.degrees(math.atan2(t['x']-ax, -(t['y']-ay)))%360
                    target_world=(self.ship_heading+t['angle'])%360
                    cur=self._ang_lerp(cur,target_world,.16)
                    vx,vy=self._clock_vec(cur)
                    orbit_x,orbit_y=ax+vx*.135,ay+vy*.135
                    t['x']+=(orbit_x-t['x'])*.30; t['y']+=(orbit_y-t['y'])*.30
                    t['visual_angle']=(cur+180)%360
                    t['secured']=math.hypot(t['x']-orbit_x,t['y']-orbit_y)<.009
                else:
                    # Approach a side stand-off and stop at the hull boundary.
                    t['x']+=(tx-t['x'])*.24; t['y']+=(ty-t['y'])*.24
                    t['secured']=math.hypot(t['x']-tx,t['y']-ty)<.009
                    t['visual_angle']=math.degrees(math.atan2(ax-t['x'], -(ay-t['y'])))%360

                if not t['secured']: continue
                action=t['action']; factor=self._tug_level_factor(t)
                if action=='STOP / FOLLOW':
                    # Hold relative geometry only; no force on target vessel.
                    continue
                ox,oy=self._relative_clock_vec(t['angle'])
                if action=='PULL':
                    fx,fy=ox,oy
                    self._apply_force(fx,fy,ax,ay,factor*.000060)
                elif action=='PUSH':
                    # Push from tug toward the vessel, opposite to its outward clock bearing.
                    fx,fy=-ox,-oy
                    self._apply_force(fx,fy,ax,ay,factor*.000055)

        self.vx*=.994; self.vy*=.994; self.omega*=.982
        oldx,oldy=self.ship_x,self.ship_y
        self.ship_x += self.vx*dt; self.ship_y += self.vy*dt
        self.ship_heading=(self.ship_heading+self.omega*dt)%360
        self._resolve_quay_collision(oldx,oldy)
        self.ship_x=max(.065,min(.935,self.ship_x)); self.ship_y=max(.065,min(.925,self.ship_y))
        self.update()

    def wheelEvent(self,e):
        self.zoom=max(.55,min(4.50,self.zoom*(1.13 if e.angleDelta().y()>0 else 1/1.13))); self.update(); e.accept()
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton: self._drag=e.pos(); self.setCursor(Qt.ClosedHandCursor); e.accept()
    def mouseMoveEvent(self,e):
        if self._drag is not None:
            d=e.pos()-self._drag; self._drag=e.pos(); self.pan_x+=d.x(); self.pan_y+=d.y(); self.update(); e.accept()
    def mouseReleaseEvent(self,e):
        if e.button()==Qt.LeftButton: self._drag=None; self.unsetCursor(); e.accept()
    def mouseDoubleClickEvent(self,e):
        self.zoom=1.; self.pan_x=self.pan_y=0.; self.update(); e.accept()

    def _draw_target(self,p,w,h):
        x,y,hdg=self.ship_x,self.ship_y,self.ship_heading; typ=self.ship_type
        p.save(); p.translate(w*x,h*y); p.rotate(hdg); p.setPen(QPen(QColor('#eaf7fb'),1.4))
        from PyQt5.QtGui import QPolygonF
        if typ=='JACK-UP BARGE':
            L,B=145,62; p.setBrush(QColor('#536575')); p.drawRect(QRectF(-B/2,-L/2,B,L)); p.setBrush(QColor('#d7dfe4'))
            for xx in (-B*.42,B*.42):
                for yy in (-L*.40,L*.40): p.drawEllipse(QPointF(xx,yy),5,5)
            p.setBrush(QColor('#aebcc5')); p.drawRect(QRectF(-B*.28,-L*.18,B*.56,L*.28))
        elif typ=='TUG & BARGE':
            L,B=150,64; p.setBrush(QColor('#596b78')); p.drawRect(QRectF(-B/2,-L/2,B,L)); p.setPen(QPen(QColor('#ffd765'),2))
            p.drawLine(QPointF(-B*.35,-L/2),QPointF(0,-L*.72)); p.drawLine(QPointF(B*.35,-L/2),QPointF(0,-L*.72)); p.drawLine(QPointF(0,-L*.72),QPointF(0,-L*1.12))
            p.setBrush(QColor('#d5aa36')); p.setPen(QPen(QColor('#f5f8fa'),1.2)); p.drawRoundedRect(QRectF(-15,-L*1.32,30,38),5,5)
        else:
            if typ=='TANKER': L,B,color=165,46,'#6a6772'
            elif typ=='BULK CARRIER': L,B,color=160,48,'#635f55'
            elif typ=='GENERAL CARGO': L,B,color=150,44,'#486472'
            else: L,B,color=170,44,'#31576b'
            p.setBrush(QColor(color)); bow=.31 if typ!='TANKER' else .25
            p.drawPolygon(QPolygonF([QPointF(0,-L/2),QPointF(B/2,-L*bow),QPointF(B/2,L/2),QPointF(-B/2,L/2),QPointF(-B/2,-L*bow)]))
            if typ=='CONTAINER SHIP':
                for yy in (-L*.20,0,L*.20): p.setBrush(QColor('#aabfcb')); p.drawRect(QRectF(-B*.34,yy-10,B*.68,18))
            elif typ=='TANKER': p.setBrush(QColor('#8797a1')); p.drawEllipse(QRectF(-B*.28,-L*.10,B*.56,28))
            else: p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(-B*.32,-L*.02,B*.64,L*.22))
        p.setPen(QColor('#ffffff')); p.drawText(QRectF(-95,92,190,22),Qt.AlignCenter,typ); p.restore()

    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height()
        sea=QColor('#082d46') if self.view_mode=='MARINE CHART' else QColor('#173c43'); land=QColor('#d1c59a'); quay=QColor('#56686d')
        p.fillRect(self.rect(),sea); p.save(); p.translate(w/2+self.pan_x,h/2+self.pan_y); p.scale(self.zoom,self.zoom); p.translate(-w/2,-h/2)
        # Larger simplified Mina Zayed training basin (not for navigation).
        p.setPen(Qt.NoPen); p.setBrush(land)
        p.drawRect(0,int(h*.77),int(w*.38),int(h*.23)); p.drawRect(int(w*.815),int(h*.14),int(w*.185),int(h*.86)); p.drawRect(int(w*.58),0,int(w*.42),int(h*.13)); p.drawRect(0,int(h*.53),int(w*.28),int(h*.05))
        p.setBrush(quay)
        for qx,qy,qw,qh in self.SOLID_QUAYS: p.drawRect(QRectF(w*qx,h*qy,w*qw,h*qh))
        p.setPen(QPen(QColor('#9eb8bf'),7)); p.drawLine(int(w*.38),int(h*.75),int(w*.47),int(h*.65)); p.drawLine(int(w*.81),int(h*.17),int(w*.69),int(h*.12))
        p.setPen(QPen(QColor('#86d8e9'),1,Qt.DashLine)); p.drawLine(int(w*.50),0,int(w*.50),int(h*.74))
        for yy in (.14,.25,.36,.47,.58,.69,.78):
            for xx,c in ((.445,'#e64f55'),(.555,'#45d17b')):
                p.setBrush(QColor(c)); p.setPen(Qt.NoPen); p.drawEllipse(QPointF(w*xx,h*yy),4.5,4.5)
        self._draw_target(p,w,h)

        # Small unobtrusive station dots only; long station labels intentionally removed.
        for idx in range(len(self.SECURE_POINTS)):
            ax,ay=self.attach_xy(idx); p.setBrush(QColor('#ffca54')); p.setPen(QPen(QColor('#fff2b3'),1)); p.drawEllipse(QPointF(w*ax,h*ay),4,4)

        for i,t in enumerate(self.tugs):
            if i>=self.active_tug_count: continue
            p.save(); p.translate(w*t['x'],h*t['y']); p.rotate(t.get('visual_angle',t['angle'])); p.setBrush(QColor('#d5aa36')); p.setPen(QPen(QColor('#eaf7fb'),1.2)); p.drawRoundedRect(QRectF(-12,-25,24,50),5,5); p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(-7,-4,14,12)); p.setPen(QColor('#ffffff')); p.drawText(QRectF(-40,30,80,18),Qt.AlignCenter,t['name']); p.restore()
            if self.secured:
                ax,ay=self.attach_xy(t['point']); p.setPen(QPen(QColor('#ffd765'),2)); p.drawLine(int(w*t['x']),int(h*t['y']),int(w*ax),int(h*ay))
        p.restore()

        hdg,sog,rot=self.navigation_data()
        p.setPen(QColor('#dcebf2')); p.setBrush(QColor(4,25,36,215)); p.drawRoundedRect(QRectF(10,8,330,54),8,8)
        p.setPen(QColor('#ffffff')); p.setFont(QFont('Sans',10,QFont.Bold)); p.drawText(22,30,f'HDG {hdg:06.1f}°   SOG {sog:04.2f} kn   ROT {rot:+05.2f}°/min')
        p.setFont(QFont('Sans',8)); p.setPen(QColor('#a8c9d4')); p.drawText(22,50,f'{self.view_mode} · ZOOM {self.zoom:.1f}x · WHEEL ZOOM · DRAG PAN · DOUBLE CLICK RESET')


class SimulatorDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle('DR.BOAT V5.4 · PILOT & TUG MASTER TRAINING SIMULATOR')
        self.resize(1280,800); self.setMinimumSize(820,560)
        root=QHBoxLayout(self); root.setContentsMargins(6,6,6,6)
        self.canvas=ManeuverCanvas(); root.addWidget(self.canvas,1)
        side_scroll=QScrollArea(); side_scroll.setWidgetResizable(True); side_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); side_scroll.setMinimumWidth(300); side_scroll.setMaximumWidth(390)
        side=QFrame(); side.setObjectName('panel'); v=QVBoxLayout(side)
        title=QLabel('V5.4 MANEUVER TRAINING'); title.setObjectName('pageTitle'); v.addWidget(title)
        desc=QLabel('Mouse control now. Architecture remains ready for future voice-command mapping. Tug actions affect vessel translation and rotation.'); desc.setWordWrap(True); v.addWidget(desc)

        self.vessel=QComboBox(); self.vessel.addItems(['CONTAINER SHIP','BULK CARRIER','TANKER','GENERAL CARGO','JACK-UP BARGE','TUG & BARGE']); self.vessel.currentTextChanged.connect(lambda x:(setattr(self.canvas,'ship_type',x),self.canvas.update())); v.addWidget(QLabel('TARGET VESSEL / UNIT')); v.addWidget(self.vessel)
        self.mode=QComboBox(); self.mode.addItems(['MARINE CHART','SATELLITE']); self.mode.currentTextChanged.connect(lambda x:(setattr(self.canvas,'view_mode',x),self.canvas.update())); v.addWidget(QLabel('MAP VIEW')); v.addWidget(self.mode)

        v.addWidget(QLabel('NUMBER OF TUGS IN THIS MANEUVER'))
        self.tug_count=QComboBox(); self.tug_count.addItems(['1 TUG','2 TUGS','3 TUGS','4 TUGS']); self.tug_count.setCurrentIndex(3); self.tug_count.currentIndexChanged.connect(self.set_tug_count); v.addWidget(self.tug_count)

        r=QHBoxLayout(); st=QPushButton('START MANEUVER'); st.clicked.connect(self.show_pre_maneuver_assessment); sc=QPushButton('PROCEED TO SECURE'); sc.clicked.connect(self.canvas.secure); r.addWidget(st); r.addWidget(sc); v.addLayout(r)

        v.addWidget(QLabel('SELECT ACTIVE TUG'))
        self.sel=QComboBox(); self.sel.addItems(['TUG 1','TUG 2','TUG 3','TUG 4']); self.sel.currentIndexChanged.connect(self.sync_tug); v.addWidget(self.sel)
        v.addWidget(QLabel('ASSIGN TUG TO STATION'))
        self.point=QComboBox(); self.point.addItems([x[0] for x in ManeuverCanvas.SECURE_POINTS]); self.point.currentIndexChanged.connect(self.set_point); v.addWidget(self.point)

        v.addWidget(QLabel('TUG CLOCK POSITION · RELATIVE TO SHIP'))
        self.ang=QSlider(Qt.Horizontal); self.ang.setRange(0,11); self.ang.valueChanged.connect(self.set_angle); v.addWidget(self.ang)
        self.anglab=QLabel("12 O'CLOCK · 000°"); v.addWidget(self.anglab)

        v.addWidget(QLabel('TUG ACTION'))
        self.action=QComboBox(); self.action.addItems(['STOP / FOLLOW','PULL','PUSH']); self.action.currentTextChanged.connect(self.set_action); v.addWidget(self.action)
        v.addWidget(QLabel('POWER / LINE ORDER'))
        self.level=QComboBox(); self.level.currentTextChanged.connect(self.set_level); v.addWidget(self.level)
        self.state=QLabel('STOP / FOLLOW · NO FORCE'); self.state.setWordWrap(True); v.addWidget(self.state)

        reset=QPushButton('RESET SCENARIO'); reset.clicked.connect(self.canvas.reset_sim); v.addWidget(reset)
        note=QLabel('Training physics are simplified and are not a certified ship-handling model. Quays are treated as solid boundaries to prevent visual penetration.'); note.setWordWrap(True); note.setObjectName('muted'); v.addWidget(note); v.addStretch()
        side_scroll.setWidget(side); root.addWidget(side_scroll)
        self.sync_tug()

    VESSEL_REFERENCE = {
        'CONTAINER SHIP': {'L':220.,'B':32.2,'T':11.0,'H':28.0,'wind_shape':.85,'water_shape':.85,'cd_air':1.10,'cd_water':1.00},
        'BULK CARRIER': {'L':190.,'B':32.0,'T':11.2,'H':17.0,'wind_shape':.82,'water_shape':.88,'cd_air':1.05,'cd_water':1.00},
        'TANKER': {'L':185.,'B':32.2,'T':11.5,'H':14.0,'wind_shape':.78,'water_shape':.90,'cd_air':.90,'cd_water':1.00},
        'GENERAL CARGO': {'L':175.,'B':28.0,'T':10.0,'H':19.0,'wind_shape':.82,'water_shape':.86,'cd_air':1.05,'cd_water':1.00},
        'JACK-UP BARGE': {'L':150.,'B':50.0,'T':6.0,'H':35.0,'wind_shape':.88,'water_shape':.92,'cd_air':1.20,'cd_water':1.05},
        'TUG & BARGE': {'L':150.,'B':45.0,'T':6.5,'H':12.0,'wind_shape':.90,'water_shape':.92,'cd_air':1.10,'cd_water':1.05},
    }

    def _bollard_pull_assessment(self):
        typ=self.vessel.currentText(); d=self.VESSEL_REFERENCE[typ]
        displacement=50000.0
        wind_gust=15.0       # m/s training reference
        current=0.50         # m/s training reference
        rho_air=1.225; rho_sea=1025.0; g=9.80665
        aw=d['L']*d['H']*d['wind_shape']
        ac=d['L']*d['T']*d['water_shape']
        fwind=.5*rho_air*d['cd_air']*aw*wind_gust**2/1000.0
        fcurrent=.5*rho_sea*d['cd_water']*ac*current**2/1000.0
        base=fwind+fcurrent
        safety=1.20
        required_kn=base*safety
        required_t=required_kn/g
        tug_bp=50.0
        ntugs=self.canvas.active_tug_count
        available=ntugs*tug_bp
        margin=available-required_t
        return typ,d,displacement,wind_gust,current,aw,ac,fwind,fcurrent,safety,required_kn,required_t,tug_bp,ntugs,available,margin

    def show_pre_maneuver_assessment(self):
        typ,d,disp,wind,current,aw,ac,fw,fc,sf,rkn,rt,tbp,nt,avail,margin=self._bollard_pull_assessment()
        dlg=QDialog(self); dlg.setWindowTitle('PRE-MANEUVER · TECHNICAL BOLLARD PULL ASSESSMENT'); dlg.resize(620,610)
        lay=QVBoxLayout(dlg)
        h=QLabel('PRE-MANEUVER TECHNICAL ASSESSMENT'); h.setObjectName('pageTitle'); lay.addWidget(h)
        sub=QLabel('Reference decision-support panel only · simulator tug physics remain fixed at 50 t BP per tug in V5.4.'); sub.setWordWrap(True); lay.addWidget(sub)
        grid=QGridLayout(); grid.setHorizontalSpacing(18); grid.setVerticalSpacing(6)
        rows=[
            ('Target vessel',typ),('Displacement',f'{disp:,.0f} t'),('Reference L × B × T',f"{d['L']:.0f} × {d['B']:.1f} × {d['T']:.1f} m"),
            ('Above-water height',f"{d['H']:.1f} m"),('Broadside windage area',f'{aw:,.0f} m²'),('Underwater lateral area',f'{ac:,.0f} m²'),
            ('Wind gust used',f'{wind:.1f} m/s'),('Current used',f'{current:.2f} m/s'),('Wind force',f'{fw:,.1f} kN'),('Current force',f'{fc:,.1f} kN'),
            ('Safety margin',f'{sf:.2f} ×'),('Required tug force',f'{rkn:,.1f} kN  ≈  {rt:,.1f} t BP'),('Tugs selected',f'{nt} × {tbp:.0f} t BP'),
            ('Available bollard pull',f'{avail:.0f} t BP'),('Available minus required',f'{margin:+.1f} t BP')]
        for r,(a,b) in enumerate(rows):
            la=QLabel(a); la.setObjectName('muted'); lb=QLabel(b); lb.setStyleSheet('font-weight:700;'); grid.addWidget(la,r,0); grid.addWidget(lb,r,1)
        lay.addLayout(grid)
        status=QLabel('ASSESSMENT: '+('AVAILABLE BP EXCEEDS REFERENCE REQUIREMENT' if margin>=0 else 'REFERENCE REQUIREMENT EXCEEDS AVAILABLE BP'))
        status.setWordWrap(True); status.setStyleSheet('font-weight:800;font-size:13px;padding:8px;border:1px solid #52717a;border-radius:6px;'); lay.addWidget(status)
        note=QLabel('Method: wind and current drag are estimated with F = ½ ρ Cᴅ A V² and a 20% operating margin. This is a training/reference estimate, not a port-approved towage plan. Actual tug requirement also depends on wind/current direction, water depth, under-keel clearance, ship loading/trim, tug type, towline geometry, berth geometry and local port procedures.'); note.setWordWrap(True); lay.addWidget(note)
        row=QHBoxLayout(); close=QPushButton('CLOSE / REVIEW'); go=QPushButton('START MANEUVER'); row.addWidget(close); row.addWidget(go); lay.addLayout(row)
        close.clicked.connect(dlg.reject)
        def proceed():
            self.canvas.start(); dlg.accept()
        go.clicked.connect(proceed)
        dlg.exec_()

    def set_tug_count(self,i):
        self.canvas.active_tug_count=i+1
        if self.sel.currentIndex()>i: self.sel.setCurrentIndex(i)
        self.canvas.update()

    def sync_tug(self):
        i=self.sel.currentIndex(); t=self.canvas.tugs[i]
        self.point.blockSignals(True); self.point.setCurrentIndex(t['point']); self.point.blockSignals(False)
        self.action.blockSignals(True); self.action.setCurrentText(t['action']); self.action.blockSignals(False)
        # Convert saved relative angle to 0..11 clock slider.
        self.ang.blockSignals(True); self.ang.setValue(int(round((t['angle']%360)/30))%12); self.ang.blockSignals(False)
        self._refresh_levels(t['action'],t.get('level'))
        x=self.ang.value(); clock=12 if x==0 else x; self.anglab.setText(f"{clock} O'CLOCK · {(x*30)%360:03d}°")
        self._refresh_state()

    def set_point(self,x):
        self.canvas.tugs[self.sel.currentIndex()]['point']=x; self.canvas.update()

    def set_angle(self,x):
        clock=12 if x==0 else x; deg=(x*30)%360
        self.canvas.tugs[self.sel.currentIndex()]['angle']=deg
        self.anglab.setText(f"{clock} O'CLOCK · {deg:03d}°"); self.canvas.update(); self._refresh_state()

    def _refresh_levels(self,action,preferred=None):
        self.level.blockSignals(True); self.level.clear()
        if action=='PULL': items=list(ManeuverCanvas.PULL_LEVELS.keys())
        elif action=='PUSH': items=list(ManeuverCanvas.PUSH_LEVELS.keys())
        else: items=['NO FORCE']
        self.level.addItems(items)
        if preferred in items: self.level.setCurrentText(preferred)
        self.level.blockSignals(False)
        if action!='STOP / FOLLOW': self.canvas.tugs[self.sel.currentIndex()]['level']=self.level.currentText()

    def set_action(self,a):
        t=self.canvas.tugs[self.sel.currentIndex()]; t['action']=a
        self._refresh_levels(a,t.get('level')); self._refresh_state(); self.canvas.update()

    def set_level(self,x):
        if not x: return
        self.canvas.tugs[self.sel.currentIndex()]['level']=x; self._refresh_state()

    def _refresh_state(self):
        t=self.canvas.tugs[self.sel.currentIndex()]
        if t['action']=='STOP / FOLLOW': text='STOP / FOLLOW · tug keeps relative position and applies no force'
        else: text=f"{t['action']} · {t.get('level','')} · {self.anglab.text()}"
        self.state.setText(text)

class DoubleClickLabel(QLabel):
    doubleClicked = pyqtSignal()
    def mouseDoubleClickEvent(self, event):
        self.doubleClicked.emit()
        super().mouseDoubleClickEvent(event)

class ThrusterGauge(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.angle = 0
        self.rpm = 0
        self.setMinimumSize(130, 145)

    def set_values(self, angle, rpm):
        self.angle = float(angle) % 360
        self.rpm = int(rpm)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w/2, 66
        radius = min(w, 110)/2 - 8

        p.setPen(QPen(QColor("#4a8197"), 2))
        p.drawEllipse(int(cx-radius), int(cy-radius), int(radius*2), int(radius*2))

        p.setPen(QColor("#dcebf2"))
        f = QFont()
        f.setPointSize(9)
        f.setBold(True)
        p.setFont(f)
        p.drawText(0, 3, w, 18, Qt.AlignCenter, self.title)

        rad = math.radians(self.angle - 90)
        ex = cx + math.cos(rad) * (radius - 10)
        ey = cy + math.sin(rad) * (radius - 10)
        p.setPen(QPen(QColor("#dcebf2"), 6, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(int(cx), int(cy), int(ex), int(ey))
        p.setBrush(QColor("#dcebf2"))
        p.drawEllipse(int(cx-6), int(cy-6), 12, 12)

        p.setPen(QColor("#9fc3d2"))
        f.setPointSize(8)
        f.setBold(False)
        p.setFont(f)
        p.drawText(0, 118, w, 15, Qt.AlignCenter, f"{int(self.angle)}°")
        p.setPen(QColor("#ffffff"))
        f.setPointSize(10)
        f.setBold(True)
        p.setFont(f)
        p.drawText(0, 132, w, 15, Qt.AlignCenter, f"{self.rpm} RPM")

class BoatStatusWidget(QFrame):
    logRequested = pyqtSignal(str)
    stopLogRequested = pyqtSignal(str)

    def __init__(self, boat_id, name, parent=None):
        super().__init__(parent)
        self.boat_id = boat_id
        self.name = name
        self.recording = False
        self.setObjectName("panel")

        layout = QVBoxLayout(self)
        title = QLabel(name)
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        metrics = QHBoxLayout()
        self.heading = QLabel("HEADING\n0°")
        self.battery = QLabel("BATTERY\n--%")
        self.link = QLabel("LINK\n--%")
        for x in (self.heading, self.battery, self.link):
            x.setAlignment(Qt.AlignCenter)
            x.setObjectName("metric")
            metrics.addWidget(x)
        layout.addLayout(metrics)

        thr = QHBoxLayout()
        self.port = ThrusterGauge("PORT AZIMUTH")
        self.stbd = ThrusterGauge("STBD AZIMUTH")
        thr.addWidget(self.port)
        thr.addWidget(self.stbd)
        layout.addLayout(thr)

        self.log_button = QPushButton(f"LOG MANEUVER · {name}")
        self.log_button.clicked.connect(self.toggle_log)
        layout.addWidget(self.log_button)

    def toggle_log(self):
        if not self.recording:
            self.logRequested.emit(self.boat_id)
        else:
            self.stopLogRequested.emit(self.boat_id)

    def set_recording(self, on):
        self.recording = on
        if on:
            self.log_button.setText(f"STOP LOG · {self.name}")
            self.log_button.setObjectName("recordButton")
        else:
            self.log_button.setText(f"LOG MANEUVER · {self.name}")
            self.log_button.setObjectName("")
        self.log_button.style().unpolish(self.log_button)
        self.log_button.style().polish(self.log_button)

    def set_values(self, boat):
        self.heading.setText(f"HEADING\n{int(boat['heading'])}°")
        self.battery.setText(f"BATTERY\n{boat['battery']}%")
        self.link.setText(f"LINK\n{boat['link']}%")
        self.port.set_values(boat["port_angle"], boat["port_rpm"])
        self.stbd.set_values(boat["stbd_angle"], boat["stbd_rpm"])

class CameraPanel(DoubleClickLabel):
    def __init__(self, boat_name, parent=None):
        super().__init__(parent)
        self.boat_name = boat_name
        self.setAlignment(Qt.AlignCenter)
        self.setObjectName("camera")
        self.setText(f"{boat_name} · LIVE CAMERA\nDOUBLE CLICK")
        self.setMinimumHeight(180)

class OpenCPNEmbedWidget(QFrame):
    embedded = pyqtSignal(bool)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("mapPanel")
        self.main_layout = QVBoxLayout(self)
        head = QHBoxLayout()
        title = QLabel("OPENCPN · LIVE MARINE CHART")
        title.setObjectName("sectionTitle")
        head.addWidget(title)
        head.addStretch()
        self.status = QLabel("NOT EMBEDDED")
        self.status.setObjectName("smallStatus")
        head.addWidget(self.status)
        self.main_layout.addLayout(head)

        self.placeholder = QLabel(
            "OpenCPN will appear inside this DR.BOAT panel.\n"
            "Press EMBED OPENCPN once after DR.BOAT starts."
        )
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.placeholder.setObjectName("mapPlaceholder")
        self.main_layout.addWidget(self.placeholder, 1)

        self.button = QPushButton("EMBED OPENCPN")
        self.button.clicked.connect(self.start_embed)
        self.main_layout.addWidget(self.button)

        self.foreign_window = None
        self.container = None
        self.process = None
        self.try_count = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.try_embed)

    def start_embed(self):
        if self.container is not None:
            return
        if not shutil.which("opencpn"):
            QMessageBox.warning(self, "OpenCPN", "OpenCPN is not installed on this Raspberry Pi.")
            return
        if not shutil.which("xdotool"):
            QMessageBox.warning(self, "OpenCPN", "xdotool is not installed. Run the V3 installer again.")
            return
        free = mem_available_mb()
        if free is not None and free < 260:
            r = QMessageBox.question(
                self, "Low memory",
                f"Only {free} MB RAM is available. OpenCPN may be heavy on Raspberry Pi 3.\nOpen it anyway?",
                QMessageBox.Yes | QMessageBox.No
            )
            if r != QMessageBox.Yes:
                return
        self.status.setText("STARTING...")
        try:
            # Reuse an existing OpenCPN window when possible.
            ids = self.find_windows()
            if not ids:
                self.process = subprocess.Popen(
                    ["opencpn"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            self.try_count = 0
            self.timer.start(700)
        except Exception as e:
            QMessageBox.critical(self, "OpenCPN", str(e))

    def find_windows(self):
        try:
            out = subprocess.check_output(
                ["xdotool", "search", "--onlyvisible", "--name", "OpenCPN"],
                stderr=subprocess.DEVNULL,
                text=True
            )
            return [x.strip() for x in out.splitlines() if x.strip().isdigit()]
        except Exception:
            return []

    def try_embed(self):
        self.try_count += 1
        ids = self.find_windows()
        if ids:
            self.timer.stop()
            try:
                wid = int(ids[-1])
                self.foreign_window = QWindow.fromWinId(wid)
                self.container = QWidget.createWindowContainer(self.foreign_window, self)
                self.container.setMinimumSize(420, 320)
                self.main_layout.insertWidget(1, self.container, 1)
                self.placeholder.hide()
                self.button.hide()
                self.status.setText("EMBEDDED")
                self.embedded.emit(True)
                return
            except Exception as e:
                self.status.setText("EMBED FAILED")
                QMessageBox.warning(self, "OpenCPN", f"Could not embed OpenCPN window:\n{e}")
                return
        if self.try_count > 25:
            self.timer.stop()
            self.status.setText("NOT FOUND")
            QMessageBox.warning(self, "OpenCPN", "OpenCPN started, but its X11 window could not be embedded.")

    def move_container_to(self, target_layout):
        if self.container is None:
            return False
        self.container.setParent(None)
        target_layout.addWidget(self.container, 1)
        return True

    def restore_container(self):
        if self.container is None:
            return
        self.container.setParent(None)
        self.main_layout.insertWidget(1, self.container, 1)

class LidarPlanView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.scan=0.; self.setMinimumHeight(230)
        self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(60)
    def tick(self): self.scan=(self.scan+4)%360; self.update()
    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height(); p.fillRect(self.rect(),QColor('#020b10'))
        # quay on starboard side
        p.setPen(Qt.NoPen); p.setBrush(QColor('#596a70')); p.drawRect(int(w*.78),0,int(w*.22),h)
        p.setPen(QPen(QColor('#9db5bd'),3)); p.drawLine(int(w*.78),0,int(w*.78),h)
        cx,cy=w*.48,h*.52; R=min(w,h)*.38
        for f in (.25,.5,.75,1.): p.setPen(QPen(QColor('#174958'),1)); p.setBrush(Qt.NoBrush); p.drawEllipse(QPointF(cx,cy),R*f,R*f)
        # top-view conventional boat
        from PyQt5.QtGui import QPolygonF
        p.setBrush(QColor('#d4aa3e')); p.setPen(QPen(QColor('#eaf7fb'),1.2)); p.drawPolygon(QPolygonF([QPointF(cx,cy-R*.48),QPointF(cx+18,cy-R*.28),QPointF(cx+18,cy+R*.35),QPointF(cx-18,cy+R*.35),QPointF(cx-18,cy-R*.28)]))
        p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(cx-10,cy-8,20,24))
        # rotating lidar beam
        a=math.radians(self.scan-90); ex=cx+math.cos(a)*R; ey=cy+math.sin(a)*R; p.setPen(QPen(QColor('#55e9ff'),2)); p.drawLine(QPointF(cx,cy),QPointF(ex,ey))
        p.setPen(QColor('#63e7ff')); p.drawText(10,20,'360° LIDAR LIVE PLAN VIEW'); p.drawText(10,h-12,'JAWAD 1 · QUAY DETECTION · SIMULATED SCAN')

class FocusDialog(QDialog):
    def __init__(self, main_window, boat_index):
        super().__init__(main_window)

        from PyQt5.QtWidgets import (
            QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
            QGridLayout, QGroupBox, QSlider, QDial, QFrame
        )
        from PyQt5.QtCore import Qt

        self.main_window = main_window
        self.boat_index = boat_index
        boat = main_window.boats[boat_index]
        boat_name = boat["name"]

        self.setWindowTitle(
            "DOCTOR BOAT CONTROL MARINE INTELLIGENCE · " + boat_name
        )
        self.resize(1100,650)
        self.setMinimumSize(720,480)

        self.setStyleSheet("""
            QDialog {
                background:#07131f;
                color:#e8f4ff;
            }
            QGroupBox {
                border:1px solid #284c66;
                border-radius:10px;
                margin-top:14px;
                padding:10px;
                font-weight:700;
                color:#7fd9ff;
                background:#0b1c2b;
            }
            QGroupBox::title {
                subcontrol-origin:margin;
                left:12px;
                padding:0 6px;
            }
            QLabel {
                color:#dbeeff;
            }
            QPushButton {
                min-height:32px;
                border-radius:7px;
                border:1px solid #35617e;
                padding:4px 10px;
                background:#123047;
                color:white;
                font-weight:700;
            }
            QPushButton:hover {
                background:#194461;
            }
            QPushButton:pressed {
                background:#07131f;
            }
            QSlider::groove:horizontal {
                height:8px;
                background:#17384f;
                border-radius:4px;
            }
            QSlider::handle:horizontal {
                width:18px;
                margin:-6px 0;
                background:#58cfff;
                border-radius:9px;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 10)
        root.setSpacing(8)

        # ===== TOP BAR =====
        top = QHBoxLayout()

        title = QLabel("DOCTOR BOAT CONTROL · MARINE INTELLIGENCE")
        title.setStyleSheet(
            "font-size:20px;font-weight:900;color:#7fd9ff;"
        )
        top.addWidget(title)

        vessel = QLabel("VESSEL: " + boat_name.upper())
        vessel.setStyleSheet(
            "font-size:15px;font-weight:800;color:white;"
        )
        top.addWidget(vessel)

        top.addStretch()

        self.connection_btn = QPushButton("● CONNECTIONS")
        self.connection_btn.clicked.connect(self.show_connections)
        top.addWidget(self.connection_btn)

        close = QPushButton("BACK TO COMMAND CENTER")
        close.clicked.connect(self.close)
        top.addWidget(close)

        root.addLayout(top)

        # ===== MAIN GRID =====
        grid = QGridLayout()
        grid.setSpacing(8)

        # ---------- OPENCPN MAP ----------
        map_frame = QGroupBox("OPENCPN · LIVE NAVIGATION")
        self.map_host = QVBoxLayout(map_frame)
        self.map_host.setContentsMargins(5, 12, 5, 5)

        map_title = QLabel(
            "LIVE CHART · GNSS POSITION · HEADING · TRACK"
        )
        map_title.setAlignment(Qt.AlignCenter)
        map_title.setStyleSheet(
            "font-size:11px;color:#80dfff;"
        )
        self.map_host.addWidget(map_title)

        grid.addWidget(map_frame, 0, 0, 1, 2)

        # ---------- CAMERA ----------
        camera = QGroupBox("LIVE CAMERA · JAWAD 1")
        camera_l = QVBoxLayout(camera)

        cam_screen = QLabel(
            "LIVE VIDEO\n\nCAMERA FEED READY"
        )
        cam_screen.setAlignment(Qt.AlignCenter)
        cam_screen.setMinimumHeight(190)
        cam_screen.setStyleSheet("""
            background:#02070c;
            border:1px solid #31536a;
            border-radius:8px;
            font-size:18px;
            font-weight:800;
            color:#7894a5;
        """)
        camera_l.addWidget(cam_screen)

        grid.addWidget(camera, 0, 2, 1, 2)

        # ---------- LIDAR / PLAN VIEW ----------
        lidar = QGroupBox("360° LIDAR · PLAN VIEW · LINE STATUS")
        lidar_l = QVBoxLayout(lidar)
        lidar_screen = LidarPlanView()
        lidar_l.addWidget(lidar_screen)

        line_grid = QGridLayout()

        let_fwd = QPushButton("LET GO FORWARD LINE")
        secure_fwd = QPushButton("SECURE FORWARD LINE")
        let_aft = QPushButton("LET GO AFT LINE")
        secure_aft = QPushButton("SECURE AFT LINE")

        let_fwd.clicked.connect(
            lambda: self.line_action("FORWARD", "RELEASED")
        )
        secure_fwd.clicked.connect(
            lambda: self.line_action("FORWARD", "SECURED")
        )
        let_aft.clicked.connect(
            lambda: self.line_action("AFT", "RELEASED")
        )
        secure_aft.clicked.connect(
            lambda: self.line_action("AFT", "SECURED")
        )

        line_grid.addWidget(let_fwd, 0, 0)
        line_grid.addWidget(secure_fwd, 0, 1)
        line_grid.addWidget(let_aft, 1, 0)
        line_grid.addWidget(secure_aft, 1, 1)

        self.line_status = QLabel(
            "FORWARD: SECURED     |     AFT: SECURED"
        )
        self.line_status.setAlignment(Qt.AlignCenter)

        lidar_l.addLayout(line_grid)
        lidar_l.addWidget(self.line_status)

        grid.addWidget(lidar, 1, 0)

        # ---------- FIREFIGHTING ----------
        firefighting = QGroupBox("FIREFIGHTING CONTROL")
        fire_l = QVBoxLayout(firefighting)

        pump_row = QHBoxLayout()
        pump_on = QPushButton("FIFI PUMP ON")
        pump_off = QPushButton("FIFI PUMP OFF")

        self.pump_status = QLabel("PUMP: OFF")
        self.pump_status.setAlignment(Qt.AlignCenter)

        pump_on.clicked.connect(
            lambda: self.pump_status.setText("PUMP: ON")
        )
        pump_off.clicked.connect(
            lambda: self.pump_status.setText("PUMP: OFF")
        )

        pump_row.addWidget(pump_on)
        pump_row.addWidget(pump_off)
        fire_l.addLayout(pump_row)
        fire_l.addWidget(self.pump_status)

        fire_label = QLabel("FIRE MONITOR AZIMUTH · 360°")
        fire_label.setAlignment(Qt.AlignCenter)
        fire_l.addWidget(fire_label)

        self.fire_dial = QDial()
        self.fire_dial.setRange(0, 359)
        self.fire_dial.setWrapping(True)
        self.fire_dial.setNotchesVisible(True)

        self.fire_angle = QLabel("MONITOR: 000°")
        self.fire_angle.setAlignment(Qt.AlignCenter)

        self.fire_dial.valueChanged.connect(
            lambda v: self.fire_angle.setText(
                "MONITOR: %03d°" % v
            )
        )

        fire_l.addWidget(self.fire_dial)
        fire_l.addWidget(self.fire_angle)

        grid.addWidget(firefighting, 1, 1)

        # ---------- RUDDER ----------
        steering = QGroupBox("HYDRAULIC STEERING · RUDDER")
        steer_l = QVBoxLayout(steering)

        self.rudder_value = QLabel("MIDSHIP · 0°")
        self.rudder_value.setAlignment(Qt.AlignCenter)
        self.rudder_value.setStyleSheet(
            "font-size:19px;font-weight:900;color:#7fd9ff;"
        )

        self.rudder = QSlider(Qt.Horizontal)
        self.rudder.setRange(-30, 30)
        self.rudder.setValue(0)
        self.rudder.setTickInterval(5)
        self.rudder.setTickPosition(QSlider.TicksBelow)
        self.rudder.valueChanged.connect(self.update_rudder)

        rudder_labels = QHBoxLayout()
        rudder_labels.addWidget(QLabel("PORT 30°"))
        rudder_labels.addStretch()
        rudder_labels.addWidget(QLabel("MIDSHIP"))
        rudder_labels.addStretch()
        rudder_labels.addWidget(QLabel("30° STARBOARD"))

        steer_l.addWidget(self.rudder_value)
        steer_l.addWidget(self.rudder)
        steer_l.addLayout(rudder_labels)

        grid.addWidget(steering, 1, 2)

        # ---------- TWIN ENGINE LEVERS ----------
        propulsion = QGroupBox("TWIN DIGITAL ENGINE CONTROL · PORT / STARBOARD")
        prop_l = QHBoxLayout(propulsion)
        self.engine_levers=[]; self.engine_states=[]
        for eng in ("PORT ENGINE", "STARBOARD ENGINE"):
            col=QVBoxLayout(); lab=QLabel(eng); lab.setAlignment(Qt.AlignCenter); lab.setStyleSheet("font-weight:900;color:#7fd9ff;"); col.addWidget(lab)
            col.addWidget(QLabel("AHEAD +100%"))
            lever=QSlider(Qt.Vertical); lever.setRange(-100,100); lever.setValue(0); lever.setTickInterval(10); lever.setTickPosition(QSlider.TicksBothSides)
            state=QLabel("NEUTRAL · 0%"); state.setAlignment(Qt.AlignCenter); state.setStyleSheet("font-size:13px;font-weight:900;color:#7fd9ff;")
            lever.valueChanged.connect(lambda v, st=state: self.update_engine_state_label(st,v))
            col.addWidget(lever,1); col.addWidget(QLabel("ASTERN -100%")); col.addWidget(state)
            self.engine_levers.append(lever); self.engine_states.append(state); prop_l.addLayout(col)
        grid.addWidget(propulsion, 1, 3)

        # ---------- MACHINERY / DATA ----------
        data = QGroupBox("VESSEL DATA · MACHINERY")
        data_l = QGridLayout(data)

        rows = [
            ("LATITUDE", "—"),
            ("LONGITUDE", "—"),
            ("HEADING · KVH", "—"),
            ("GNSS", "CONNECTED"),
            ("ENGINE 1 RPM", "0"),
            ("ENGINE 1 HOURS", "0.0 h"),
            ("ENGINE 1 CONSUMPTION", "0.0 L/h"),
            ("ENGINE 2 RPM", "0"),
            ("ENGINE 2 HOURS", "0.0 h"),
            ("ENGINE 2 CONSUMPTION", "0.0 L/h"),
        ]

        for r, (name, value) in enumerate(rows):
            a = QLabel(name)
            b = QLabel(value)
            b.setStyleSheet(
                "font-weight:800;color:#75e6a5;"
            )
            data_l.addWidget(a, r, 0)
            data_l.addWidget(b, r, 1)

        grid.addWidget(data, 2, 0, 1, 2)

        # ---------- EXISTING STATUS ----------
        self.status_widget = BoatStatusWidget(
            boat["id"],
            boat["name"]
        )
        self.status_widget.logRequested.connect(
            main_window.start_log
        )
        self.status_widget.stopLogRequested.connect(
            main_window.stop_log
        )
        self.status_widget.set_values(boat)
        self.status_widget.set_recording(
            boat["id"] in main_window.recording
        )
        if boat.get("id") == "JAWAD_1":
            self.status_widget.port.hide(); self.status_widget.stbd.hide()
            self.status_widget.heading.setText("HEADING\n0°")
            self.status_widget.log_button.setText("LOG JAWAD 1 MANEUVER")

        status_box = QGroupBox("LIVE TELEMETRY · SYSTEM")
        status_l = QVBoxLayout(status_box)
        status_l.addWidget(self.status_widget)

        grid.addWidget(status_box, 2, 2, 1, 2)

        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)
        grid.setColumnStretch(2, 2)
        grid.setColumnStretch(3, 1)

        grid.setRowStretch(0, 3)
        grid.setRowStretch(1, 4)
        grid.setRowStretch(2, 2)

        root.addLayout(grid, 1)

        # Move the existing embedded OpenCPN window into this page.
        self.moved_map = main_window.map_widget.move_container_to(
            self.map_host
        )

    def update_rudder(self, value):
        if value < 0:
            self.rudder_value.setText(
                "PORT · %d°" % abs(value)
            )
        elif value > 0:
            self.rudder_value.setText(
                "STARBOARD · %d°" % value
            )
        else:
            self.rudder_value.setText("MIDSHIP · 0°")

    def update_engine_state_label(self, label, value):
        if -4 <= value <= 4: label.setText("NEUTRAL · 0%"); return
        label.setText(("AHEAD" if value>0 else "ASTERN") + " · %d%%" % abs(value))

    def update_engine_lever(self, value):
        if hasattr(self, "engine_states") and self.engine_states:
            self.update_engine_state_label(self.engine_states[0], value)

    def line_action(self, line_name, state):
        current = self.line_status.text()

        if line_name == "FORWARD":
            aft = (
                "RELEASED"
                if "AFT: RELEASED" in current
                else "SECURED"
            )
            current = (
                "FORWARD: %s     |     AFT: %s"
                % (state, aft)
            )
        else:
            forward = (
                "RELEASED"
                if "FORWARD: RELEASED" in current
                else "SECURED"
            )
            current = (
                "FORWARD: %s     |     AFT: %s"
                % (forward, state)
            )

        self.line_status.setText(current)

    def show_connections(self):
        from PyQt5.QtWidgets import QMessageBox

        QMessageBox.information(
            self,
            "Connections · System Status",
            "● KVH HEADING            CONNECTED\n"
            "● GNSS                   CONNECTED\n"
            "● ENGINE CONTROL         STANDBY\n"
            "● HYDRAULIC STEERING     STANDBY\n"
            "● FIFI MONITOR CONTROL   STANDBY\n"
            "● FIFI PUMP CONTROL      STANDBY\n"
            "● LINE RELEASE 1         STANDBY\n"
            "● LINE RELEASE 2         STANDBY\n"
            "● LIDAR 360°             STANDBY\n"
            "● CAMERA                  STANDBY\n"
            "● 4G / 5G MODEM          STANDBY\n"
            "● SIGNAL K               CONNECTED\n"
            "● OPENCPN                CONNECTED"
        )

    def closeEvent(self, event):
        if self.moved_map:
            self.main_window.map_widget.restore_container()
        super().closeEvent(event)


class CommandCenter(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent); self.main_window=main_window; self.selected_ids=['JAWAD_1']
        root=QVBoxLayout(self)
        head=QHBoxLayout(); title=QLabel('AI COMMAND CENTER · OPERATOR CONSOLE'); title.setObjectName('pageTitle'); head.addWidget(title); head.addStretch()
        sel=QPushButton('SELECT UNITS'); sel.clicked.connect(self.select_units); head.addWidget(sel); root.addLayout(head)
        self.map_widget=OpenCPNEmbedWidget(); root.addWidget(self.map_widget,3)
        self.units_host=QWidget(); self.units_layout=QGridLayout(self.units_host); root.addWidget(self.units_host,2)
        ai=QFrame(); ai.setObjectName('panel'); al=QHBoxLayout(ai); al.addWidget(QLabel('AI / VOICE CONSOLE')); self.voice=QLineEdit(); self.voice.setPlaceholderText('Voice / mission command'); al.addWidget(self.voice,1); send=QPushButton('SEND / SIMULATE VOICE'); send.clicked.connect(main_window.set_voice); al.addWidget(send); root.addWidget(ai)
        self.cards={}; self.rebuild_units()
    def select_units(self):
        d=QDialog(self); d.setWindowTitle('SELECT COMMAND CENTER UNITS'); d.resize(460,520); l=QVBoxLayout(d); l.addWidget(QLabel('Select up to four fleet units to display in Command Center'))
        q=QListWidget(); q.setSelectionMode(QAbstractItemView.MultiSelection)
        for v in FleetPage.VESSELS:
            it=QListWidgetItem(v['name']); it.setData(Qt.UserRole,v['id']); q.addItem(it); it.setSelected(v['id'] in self.selected_ids)
        l.addWidget(q,1); row=QHBoxLayout(); ok=QPushButton('APPLY'); cancel=QPushButton('CANCEL'); row.addWidget(ok); row.addWidget(cancel); l.addLayout(row)
        ok.clicked.connect(d.accept); cancel.clicked.connect(d.reject)
        if d.exec_()==QDialog.Accepted:
            ids=[it.data(Qt.UserRole) for it in q.selectedItems()][:4]
            self.selected_ids=ids or ['JAWAD_1']; self.main_window.ensure_boats(self.selected_ids); self.rebuild_units()
    def rebuild_units(self):
        while self.units_layout.count():
            it=self.units_layout.takeAt(0); w=it.widget();
            if w: w.deleteLater()
        self.cards={}
        for i,bid in enumerate(self.selected_ids):
            boat=self.main_window.boat_by_id(bid)
            if not boat: continue
            panel=QFrame(); panel.setObjectName('panel'); v=QVBoxLayout(panel); top=QHBoxLayout(); name=QLabel(boat['name']); name.setObjectName('sectionTitle'); top.addWidget(name); top.addStretch()
            ptt=QPushButton('🎙 PUSH TO TALK'); ptt.setToolTip('Operator-to-vessel voice channel placeholder'); ptt.pressed.connect(lambda b=boat: self.ptt(b,True)); ptt.released.connect(lambda b=boat: self.ptt(b,False)); top.addWidget(ptt); v.addLayout(top)
            cam=CameraPanel(boat['name']); cam.setMinimumHeight(120); cam.doubleClicked.connect(lambda bid=bid:self.main_window.open_focus_by_id(bid)); v.addWidget(cam)
            status=BoatStatusWidget(boat['id'],boat['name']); status.setMaximumHeight(260); status.logRequested.connect(self.main_window.start_log); status.stopLogRequested.connect(self.main_window.stop_log)
            if boat.get('type')=='CONVENTIONAL': status.port.hide(); status.stbd.hide()
            status.set_values(boat); v.addWidget(status); self.cards[bid]=status
            self.units_layout.addWidget(panel,i//2,i%2)
    def ptt(self,boat,on):
        self.main_window.voice_text=(f"PTT ACTIVE · {boat['name']}" if on else 'Awaiting command')
    def refresh(self):
        for bid,w in list(self.cards.items()):
            b=self.main_window.boat_by_id(bid)
            if b: w.set_values(b); w.set_recording(bid in self.main_window.recording)

class LibraryPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QHBoxLayout(self)
        left = QVBoxLayout()
        title = QLabel("AI TRAINING & MANEUVER LIBRARY")
        title.setObjectName("pageTitle")
        left.addWidget(title)
        self.list = QListWidget()
        self.list.itemDoubleClicked.connect(self.open_item)
        left.addWidget(self.list)
        refresh = QPushButton("REFRESH LIBRARY")
        refresh.clicked.connect(self.reload)
        left.addWidget(refresh)
        lw = QWidget(); lw.setLayout(left)
        root.addWidget(lw, 1)
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        root.addWidget(self.detail, 2)
        self.reload()

    def reload(self):
        self.list.clear()
        for f in sorted(MISSIONS_DIR.glob("*.jsonl"), key=lambda x: x.stat().st_mtime, reverse=True):
            self.list.addItem(QListWidgetItem(f.stem))

    def open_item(self, item):
        f = MISSIONS_DIR / (item.text()+".jsonl")
        rows = []
        try:
            lines = f.read_text(encoding="utf-8").splitlines()
            for line in lines[-120:]:
                if not line.strip(): continue
                r = json.loads(line)
                b = r.get("boat", {})
                rows.append(
                    f"{r.get('time','')} | {b.get('name','')} | "
                    f"HDG {int(b.get('heading',0))}° | "
                    f"PORT {b.get('port_angle',0)}° / {b.get('port_rpm',0)} RPM | "
                    f"STBD {b.get('stbd_angle',0)}° / {b.get('stbd_rpm',0)} RPM"
                )
            self.detail.setPlainText("\n".join(rows) or "No samples.")
        except Exception as e:
            self.detail.setPlainText(str(e))

class TrainingPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root=QVBoxLayout(self)
        hero=QFrame(); hero.setObjectName('panel'); h=QHBoxLayout(hero); txt=QVBoxLayout()
        z=QLabel('PILOT & TUG MASTER TRAINING · V5.3'); z.setObjectName('pageTitle'); txt.addWidget(z)
        d=QLabel('Professional maneuver training with Mina Zayed chart-style scene, slow target-vessel motion, four ASD tugs and six selectable securing points.'); d.setWordWrap(True); txt.addWidget(d); h.addLayout(txt,1)
        launch=QPushButton('OPEN TRAINING SIMULATOR'); launch.setMinimumHeight(60); launch.clicked.connect(self.open_sim); h.addWidget(launch); root.addWidget(hero)
        grid=QGridLayout()
        for i,(t,d) in enumerate([
            ('PILOT TRAINING','Approach · berth planning · ship speed/rudder · tug allocation.'),
            ('TUG MASTER TRAINING','Clock-angle orders · push/pull power · secure-line approach.'),
            ('6 SECURING POINTS','Center Lead Bow/Aft · Starboard Bow/Quarter · Port Bow/Quarter.'),
            ('TARGET UNITS','Container · Bulk · Tanker · General Cargo · Jack-up Barge · Tug & Barge.')]):
            box=QFrame(); box.setObjectName('panel'); l=QVBoxLayout(box); a=QLabel(t); a.setObjectName('sectionTitle'); b=QLabel(d); b.setWordWrap(True); l.addWidget(a); l.addWidget(b); l.addStretch(); grid.addWidget(box,i//2,i%2)
        root.addLayout(grid); root.addStretch()
    def open_sim(self): SimulatorDialog(self).exec_()

class PropulsionPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        title = QLabel("PROPULSION MANAGER")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        grid = QGridLayout()
        for i,(t,d) in enumerate([
            ("TWIN AZIMUTH", "360° Port + Starboard ASD"),
            ("TWIN SCREW", "Port + Starboard engine / rudder"),
            ("SINGLE SCREW", "Engine + conventional rudder"),
        ]):
            box=QFrame(); box.setObjectName("panel")
            l=QVBoxLayout(box)
            q=QLabel(t); q.setObjectName("sectionTitle")
            l.addWidget(q); l.addWidget(QLabel(d)); l.addStretch()
            grid.addWidget(box,0,i)
        root.addLayout(grid)
        mode = QFrame(); mode.setObjectName("panel")
        ml=QHBoxLayout(mode)
        ml.addWidget(QLabel("CONTROL MODE"))
        self.combo=QComboBox()
        self.combo.addItems(["MANUAL", "ASSISTED", "AUTONOMOUS"])
        ml.addWidget(self.combo)
        ml.addStretch()
        root.addWidget(mode)
        root.addStretch()

class SystemPage(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.manifest = None
        root = QVBoxLayout(self)
        title = QLabel("SYSTEM / UPDATES")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        info = QFrame(); info.setObjectName("panel")
        il=QVBoxLayout(info)
        self.version = QLabel(f"Installed: V{APP_VERSION} · Raspberry Pi 3")
        self.version.setObjectName("sectionTitle")
        il.addWidget(self.version)
        btns=QHBoxLayout()
        health=QPushButton("SYSTEM HEALTH"); health.clicked.connect(self.check_health)
        upd=QPushButton("CHECK FOR UPDATES"); upd.clicked.connect(self.check_updates)
        self.install=QPushButton("DOWNLOAD & INSTALL UPDATE"); self.install.setEnabled(False); self.install.clicked.connect(self.install_update)
        for b in (health,upd,self.install): btns.addWidget(b)
        il.addLayout(btns)
        self.output=QTextEdit(); self.output.setReadOnly(True); self.output.setMinimumHeight(220)
        il.addWidget(self.output)
        root.addWidget(info)
        root.addStretch()

    def check_health(self):
        disk = shutil.disk_usage(str(Path.home()))
        self.output.setPlainText(
            f"DR.BOAT V{APP_VERSION}\n"
            f"CPU temperature: {cpu_temp_c() if cpu_temp_c() is not None else 'N/A'} °C\n"
            f"Available RAM: {mem_available_mb() if mem_available_mb() is not None else 'N/A'} MB\n"
            f"Free disk: {disk.free//(1024**3)} GB\n"
            f"OpenCPN: {'INSTALLED' if shutil.which('opencpn') else 'NOT INSTALLED'}\n"
            f"xdotool: {'INSTALLED' if shutil.which('xdotool') else 'NOT INSTALLED'}\n"
            f"Update manifest: {UPDATE_MANIFEST}"
        )

    def check_updates(self):
        self.output.setPlainText("Checking GitHub update server over HTTPS...")
        QApplication.processEvents()
        try:
            req = urllib.request.Request(UPDATE_MANIFEST, headers={"User-Agent":"DRBOAT-V3"})
            with urllib.request.urlopen(req, timeout=12) as r:
                manifest = json.loads(r.read().decode("utf-8"))
            self.manifest = manifest
            latest = manifest.get("version","0.0.0")
            notes = manifest.get("notes","")
            if isinstance(notes, list): notes = "\n".join("• "+str(x) for x in notes)
            text = (
                f"Current version: {APP_VERSION}\n"
                f"Latest version: {latest}\n"
                f"Server: CONNECTED (HTTPS)\n\n"
                f"Release notes:\n{notes}"
            )
            if version_tuple(latest) > version_tuple(APP_VERSION):
                text += "\n\nUPDATE AVAILABLE."
                self.install.setEnabled(True)
            else:
                text += "\n\nYou are up to date."
                self.install.setEnabled(False)
            self.output.setPlainText(text)
        except Exception as e:
            self.install.setEnabled(False)
            self.output.setPlainText(
                "Update server is not ready yet.\n\n"
                "V3 is already configured to read:\n"
                f"{UPDATE_MANIFEST}\n\n"
                f"Error: {e}\n\n"
                "Upload version.json to your GitHub repository to activate future online updates."
            )

    def install_update(self):
        if not self.manifest:
            return
        url = self.manifest.get("package_url")
        want_sha = self.manifest.get("sha256","").lower()
        if not url:
            QMessageBox.warning(self, "Update", "package_url is missing from version.json")
            return
        if QMessageBox.question(
            self, "Install update",
            "DR.BOAT will download the update, verify it, back up the current version, then restart.\nContinue?",
            QMessageBox.Yes | QMessageBox.No
        ) != QMessageBox.Yes:
            return
        try:
            tmpdir = Path(tempfile.mkdtemp(prefix="drboat-update-"))
            zpath = tmpdir / "update.zip"
            self.output.setPlainText("Downloading update...")
            QApplication.processEvents()
            req = urllib.request.Request(url, headers={"User-Agent":"DRBOAT-V3"})
            with urllib.request.urlopen(req, timeout=60) as r, zpath.open("wb") as f:
                while True:
                    chunk = r.read(1024*128)
                    if not chunk: break
                    f.write(chunk)
            got_sha = hashlib.sha256(zpath.read_bytes()).hexdigest()
            if want_sha and got_sha != want_sha:
                raise RuntimeError(f"SHA256 mismatch.\nExpected: {want_sha}\nReceived: {got_sha}")
            extract = tmpdir / "extract"
            extract.mkdir()
            with zipfile.ZipFile(zpath) as z:
                z.extractall(extract)
            dirs = [p for p in extract.iterdir() if p.is_dir()]
            if not dirs:
                raise RuntimeError("Update package has no application directory.")
            src = dirs[0]
            helper = tmpdir / "apply_update.sh"
            appdir = APP_DIR
            backup = APP_DIR.parent / (APP_DIR.name + ".backup")
            launcher = Path.home()/".local/bin/drboat"
            helper.write_text(f"""#!/bin/bash
set -e
sleep 2
rm -rf "{backup}"
mv "{appdir}" "{backup}"
mkdir -p "{appdir}"
cp -a "{src}/." "{appdir}/"
if [ -d "{backup}/data" ]; then
  rm -rf "{appdir}/data"
  cp -a "{backup}/data" "{appdir}/data"
fi
"{launcher}" >/dev/null 2>&1 &
""")
            os.chmod(helper,0o755)
            subprocess.Popen(["bash", str(helper)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            QApplication.instance().quit()
        except Exception as e:
            QMessageBox.critical(self, "Update failed", str(e))


class FleetCard(QFrame):
    doubleClicked = pyqtSignal(str)
    def __init__(self, vessel, parent=None):
        super().__init__(parent); self.vessel=vessel; self.setObjectName('fleetCard'); self.setMinimumHeight(94)
        l=QVBoxLayout(self); n=QLabel(vessel['name']); n.setStyleSheet('font-size:16px;font-weight:900;color:#eaf8ff;'); l.addWidget(n)
        role=QLabel(vessel.get('type','VESSEL')+' · '+vessel.get('location','FLEET UNIT')); role.setStyleSheet('color:#8fc7dc;'); l.addWidget(role)
        st=QLabel('ONLINE' if vessel.get('active_map') or vessel.get('id')=='JAWAD_1' else 'STANDBY'); st.setStyleSheet('color:#46e39c;font-weight:bold;' if st.text()=='ONLINE' else 'color:#f2c35b;font-weight:bold;'); l.addWidget(st)
        hint=QLabel('DOUBLE CLICK TO OPEN' if vessel.get('id')=='JAWAD_1' else 'DOUBLE CLICK FOR VESSEL DETAILS'); hint.setStyleSheet('font-size:10px;color:#6fa0b3;'); l.addWidget(hint)
    def mouseDoubleClickEvent(self,e): self.doubleClicked.emit(self.vessel['id']); super().mouseDoubleClickEvent(e)




class UTMMapCanvas(QWidget):
    """Layered navigation canvas.

    V8.3 keeps the Natural Earth world map permanently underneath every ENC.
    The vessel owns a geographic position; charts never drag the vessel to their
    centre. Manual pan suspends follow mode and RECENTER restores vessel-follow.
    """
    routeFinished = pyqtSignal(list)
    MINA_ZAYED_LAT = 24.5260
    MINA_ZAYED_LON = 54.3860

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(700, 500); self.setMouseTracking(True)
        z,h,e,n=latlon_to_utm(self.MINA_ZAYED_LAT,self.MINA_ZAYED_LON)
        self.zone=z; self.hemisphere=h; self.easting=e; self.northing=n
        self.vessel_lat=self.MINA_ZAYED_LAT; self.vessel_lon=self.MINA_ZAYED_LON
        self.heading=0.0; self.course=0.0; self.speed=0.0
        self.gnss_live=False; self.position_source='MINA ZAYED START'
        self.grid_step=500.0; self.chart_name='WORLD BASE MAP · NO ENC LOADED'
        self.tool='PAN'; self.route=[]; self.measure=[]; self.track=[]; self.show_track=True
        self.world_basemap=[]; self.world_mode=True
        self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat; self.world_zoom=20.0
        self.vector_features=[]; self.vector_bounds=None; self.vector_chart_name=''
        self._pan_drag=None; self.follow_vessel=True; self.view_mode='NORTH UP'

    def meters_per_pixel(self):
        # approximate local scale at vessel latitude for route / measuring helpers
        px_per_deg=(self.width()/360.0)*max(1.0,self.world_zoom)
        m_per_deg_lon=max(1000.0,111320.0*math.cos(math.radians(self.vessel_lat)))
        return m_per_deg_lon/max(1.0,px_per_deg)

    def _view_rotation(self):
        if self.view_mode=='HEAD UP': return -float(self.heading)
        if self.view_mode=='COURSE UP': return -float(self.course)
        return 0.0

    @staticmethod
    def _rot(dx,dy,deg):
        a=math.radians(deg); c=math.cos(a); s=math.sin(a)
        return dx*c-dy*s, dx*s+dy*c

    def world_to_screen(self,lon,lat):
        w,h=self.width(),self.height(); sx=(w/360.0)*self.world_zoom; sy=(h/180.0)*self.world_zoom
        dlon=((float(lon)-self.world_center_lon+180.0)%360.0)-180.0
        dx=dlon*sx; dy=-(float(lat)-self.world_center_lat)*sy
        dx,dy=self._rot(dx,dy,self._view_rotation())
        return QPointF(w/2+dx,h/2+dy)

    def screen_to_world(self,pos):
        w,h=self.width(),self.height(); sx=(w/360.0)*self.world_zoom; sy=(h/180.0)*self.world_zoom
        dx=pos.x()-w/2; dy=pos.y()-h/2
        dx,dy=self._rot(dx,dy,-self._view_rotation())
        lon=self.world_center_lon+dx/max(1e-9,sx)
        lat=self.world_center_lat-dy/max(1e-9,sy)
        lon=((lon+180.0)%360.0)-180.0; lat=max(-89.0,min(89.0,lat))
        return lat,lon

    def screen_to_utm(self,pos):
        lat,lon=self.screen_to_world(pos); z,h,e,n=latlon_to_utm(lat,lon)
        return e,n

    def utm_to_screen(self,e,n,zone=None,hemisphere=None):
        lat,lon=utm_to_latlon(e,n,zone or self.zone,hemisphere or self.hemisphere)
        return self.world_to_screen(lon,lat)

    def set_tool(self,t):
        self.tool=t; self.measure=[] if t=='MEASURE' else self.measure; self.update()

    def set_view_mode(self,mode):
        mode=str(mode).upper()
        if mode not in {'NORTH UP','HEAD UP','COURSE UP'}: return
        self.view_mode=mode; self.update()

    def recenter_vessel(self):
        self.follow_vessel=True
        self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat
        self.update()

    def zoom_in(self): self.world_zoom=min(900.0,self.world_zoom*1.5); self.update()
    def zoom_out(self): self.world_zoom=max(1.0,self.world_zoom/1.5); self.update()
    def wheelEvent(self,e): self.zoom_in() if e.angleDelta().y()>0 else self.zoom_out()

    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton:
            if self.tool=='PAN':
                self._pan_drag=e.pos(); self.follow_vessel=False; self.setCursor(Qt.ClosedHandCursor); return
            lat,lon=self.screen_to_world(e.pos()); z,h,east,north=latlon_to_utm(lat,lon)
            self.zone=z; self.hemisphere=h; pt=(east,north)
            if self.tool=='ROUTE': self.route.append(pt); self.update()
            elif self.tool=='MEASURE':
                if len(self.measure)>=2: self.measure=[]
                self.measure.append(pt); self.update()
        elif e.button()==Qt.RightButton:
            lat,lon=self.screen_to_world(e.pos()); z,h,east,north=latlon_to_utm(lat,lon)
            QMessageBox.information(self,'MAP COORDINATES',
                f'LAT {lat:.7f}°\nLON {lon:.7f}°\n\nUTM {z}{h}\nE {east:.2f} m\nN {north:.2f} m')

    def mouseMoveEvent(self,e):
        if self._pan_drag is not None and (e.buttons() & Qt.LeftButton):
            dx=e.pos().x()-self._pan_drag.x(); dy=e.pos().y()-self._pan_drag.y()
            # Convert screen drag back through current orientation so geographic layers remain registered.
            dx,dy=self._rot(dx,dy,-self._view_rotation())
            sx=(self.width()/360.0)*self.world_zoom; sy=(self.height()/180.0)*self.world_zoom
            self.world_center_lon-=dx/max(1e-9,sx); self.world_center_lat+=dy/max(1e-9,sy)
            self.world_center_lon=((self.world_center_lon+180.0)%360.0)-180.0
            self.world_center_lat=max(-80.0,min(84.0,self.world_center_lat))
            self._pan_drag=e.pos(); self.update()

    def mouseReleaseEvent(self,e):
        if e.button()==Qt.LeftButton and self._pan_drag is not None:
            self._pan_drag=None; self.unsetCursor()

    def mouseDoubleClickEvent(self,e):
        if self.tool=='ROUTE' and len(self.route)>=2:
            self.routeFinished.emit(self.route[:]); self.tool='PAN'; self.update()

    def set_position(self,easting,northing,zone=None,heading=None,speed=None,course=None,source=None,gnss_live=None):
        self.easting=float(easting); self.northing=float(northing)
        if zone is not None: self.zone=int(zone)
        if heading is not None: self.heading=float(heading)%360
        if course is not None: self.course=float(course)%360
        elif heading is not None and self.speed>0.2: self.course=float(heading)%360
        if speed is not None: self.speed=float(speed)
        if gnss_live is not None: self.gnss_live=bool(gnss_live)
        if source: self.position_source=str(source)
        self.vessel_lat,self.vessel_lon=utm_to_latlon(self.easting,self.northing,self.zone,self.hemisphere)
        if self.follow_vessel: self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat
        self.update()

    def set_gnss_fix(self,lat,lon,heading=None,speed=None,course=None):
        z,h,e,n=latlon_to_utm(lat,lon); self.hemisphere=h
        self.set_position(e,n,z,heading,speed,course,'GNSS',True)

    def set_gnss_lost(self):
        self.gnss_live=False; self.position_source='LAST FIX / DR STANDBY'; self.update()

    def set_chart_name(self,name): self.chart_name=name or 'WORLD BASE MAP'; self.update()

    @staticmethod
    def dist_bearing(a,b):
        de=b[0]-a[0]; dn=b[1]-a[1]
        return math.hypot(de,dn),(math.degrees(math.atan2(de,dn))+360)%360

    def load_world_basemap(self,path=None,reset_view=False):
        p=Path(path) if path else APP_DIR/'charts'/'DRBOAT_WORLD_BASE_NATURAL_EARTH.geojson'
        obj=json.loads(p.read_text(errors='ignore')); rings=[]
        for feat in obj.get('features',[]):
            geom=feat.get('geometry') or {}; typ=geom.get('type'); coords=geom.get('coordinates') or []
            if typ=='Polygon':
                for ring in coords:
                    if len(ring)>=3: rings.append(ring)
            elif typ=='MultiPolygon':
                for poly in coords:
                    for ring in poly:
                        if len(ring)>=3: rings.append(ring)
        if not rings: raise ValueError('World base map contains no polygon geometry.')
        self.world_basemap=rings; self.world_mode=True
        if reset_view:
            self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat; self.world_zoom=20.0
            self.follow_vessel=True
        self.chart_name='NATURAL EARTH VECTOR WORLD BASE MAP' + (f' + {self.vector_chart_name}' if self.vector_chart_name else '')
        self.update(); return len(rings)

    def draw_world_basemap(self,p):
        p.fillRect(self.rect(),QColor('#082b3a'))
        if not self.world_basemap: return
        p.setPen(QPen(QColor('#76939a'),0.8)); p.setBrush(QColor('#344842'))
        for ring in self.world_basemap:
            pts=[self.world_to_screen(float(q[0]),float(q[1])) for q in ring if isinstance(q,(list,tuple)) and len(q)>=2]
            if len(pts)>=3: p.drawPolygon(*pts)

    def draw_global_utm_grid(self,p):
        # Grid is a geographic layer: it stays registered to the earth/chart and rotates only with view mode.
        p.setFont(QFont('Arial',7)); p.setBrush(Qt.NoBrush)
        if self.world_zoom < 6.0:
            p.setPen(QPen(QColor(55,115,135,120),1,Qt.DashLine))
            for lon in range(-180,181,6):
                a=self.world_to_screen(lon,-80); b=self.world_to_screen(lon,84); p.drawLine(a,b)
                if lon<180:
                    q=self.world_to_screen(lon+3,0)
                    if -30<q.x()<self.width()+30 and -30<q.y()<self.height()+30:
                        p.setPen(QColor('#7faebd')); p.drawText(q+QPointF(-7,-3),str(int(((lon+180)//6)+1)))
                        p.setPen(QPen(QColor(55,115,135,120),1,Qt.DashLine))
            for lat in range(-80,85,8): p.drawLine(self.world_to_screen(-180,lat),self.world_to_screen(180,lat))
            return
        # Local fixed UTM metre grid around map centre.
        z,h,ce,cn=latlon_to_utm(self.world_center_lat,self.world_center_lon)
        if self.world_zoom>=180: step=500.0
        elif self.world_zoom>=70: step=1000.0
        elif self.world_zoom>=25: step=5000.0
        else: step=10000.0
        ce0=math.floor(ce/step)*step; cn0=math.floor(cn/step)*step; span=step*8
        p.setPen(QPen(QColor(55,115,135,110),1,Qt.DashLine))
        for i in range(-8,9):
            ee=ce0+i*step
            try:
                lat1,lon1=utm_to_latlon(ee,cn0-span,z,h); lat2,lon2=utm_to_latlon(ee,cn0+span,z,h)
                a=self.world_to_screen(lon1,lat1); b=self.world_to_screen(lon2,lat2); p.drawLine(a,b)
                if 0<a.x()<self.width(): p.drawText(a+QPointF(3,-4),f'E {ee/1000:.0f}k')
            except Exception: pass
        for i in range(-8,9):
            nn=cn0+i*step
            try:
                lat1,lon1=utm_to_latlon(ce0-span,nn,z,h); lat2,lon2=utm_to_latlon(ce0+span,nn,z,h)
                a=self.world_to_screen(lon1,lat1); b=self.world_to_screen(lon2,lat2); p.drawLine(a,b)
                if 0<a.y()<self.height(): p.drawText(a+QPointF(3,-4),f'N {nn/1000:.0f}k')
            except Exception: pass

    def clear_vector_chart(self):
        self.vector_features=[]; self.vector_bounds=None; self.vector_chart_name=''; self.chart_name='WORLD BASE MAP · NO ENC LOADED'; self.update()

    def fit_vector_chart(self):
        if not self.vector_bounds: return
        minlon,minlat,maxlon,maxlat=self.vector_bounds
        self.world_center_lon=(minlon+maxlon)/2; self.world_center_lat=(minlat+maxlat)/2
        lonspan=max(0.01,maxlon-minlon); latspan=max(0.01,maxlat-minlat)
        usable_w=max(240,self.width()-90); usable_h=max(220,self.height()-90)
        zx=usable_w*360.0/(max(1,self.width())*lonspan); zy=usable_h*180.0/(max(1,self.height())*latspan)
        self.world_zoom=max(1.0,min(900.0,min(zx,zy)*0.88)); self.follow_vessel=False; self.update()

    def load_geojson_chart(self,path):
        # Store ENC geometry in geographic coordinates so it remains a true overlay on the world base map.
        obj=json.loads(Path(path).read_text(errors='ignore'))
        feats=obj.get('features',[]) if obj.get('type')=='FeatureCollection' else [{'geometry':obj,'properties':{}}]
        out=[]; lons=[]; lats=[]
        for feat in feats:
            props=feat.get('properties') or {}
            for kind,coords in flatten_geojson_geometry(feat.get('geometry')):
                raw=[coords] if kind=='Point' else coords; pts=[]
                for pair in raw:
                    if not isinstance(pair,(list,tuple)) or len(pair)<2: continue
                    lon,lat=float(pair[0]),float(pair[1]); pts.append((lon,lat)); lons.append(lon); lats.append(lat)
                if pts: out.append({'kind':kind,'pts':pts,'props':props})
        if not out: raise ValueError('No drawable vector features found.')
        self.vector_features=out; self.vector_bounds=(min(lons),min(lats),max(lons),max(lats)); self.world_mode=True
        return len(out)

    def draw_vector_chart(self,p):
        if not self.vector_features: return
        for f in self.vector_features:
            kind=f['kind']; pts=[self.world_to_screen(*q) for q in f['pts']]
            props=f.get('props') or {}; layer=str(props.get('_S57_LAYER','')).upper()
            if kind=='Polygon' and len(pts)>=3:
                if layer in ('DEPARE','DRGARE'): pen=QColor('#366b7a'); brush=QColor('#0d4052')
                elif layer in ('LNDARE','BUAARE'): pen=QColor('#887e63'); brush=QColor('#4b5040')
                elif layer in ('RESARE','ACHARE','FAIRWY'): pen=QColor('#c0a95a'); brush=QColor(50,75,68,110)
                else: pen=QColor('#637c78'); brush=QColor(35,63,66,150)
                p.setPen(QPen(pen,1)); p.setBrush(brush); p.drawPolygon(*pts)
            elif kind=='LineString' and len(pts)>=2:
                p.setBrush(Qt.NoBrush)
                if layer=='COALNE': col=QColor('#d8c98c'); wid=2
                elif layer in ('DEPCNT','DEPLNE'): col=QColor('#5db5d1'); wid=1
                elif layer in ('NAVLNE','RECTRC','FAIRWY'): col=QColor('#e7c85c'); wid=1
                else: col=QColor('#89b4bf'); wid=1
                p.setPen(QPen(col,wid));
                for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
            elif kind=='Point' and pts:
                if layer in ('BOYLAT','BOYCAR','BOYSAW','BCNSPP','BCNLAT','LIGHTS'): col=QColor('#f4dc67'); r=4.0
                elif layer in ('SOUNDG',): col=QColor('#b8dbe5'); r=2.0
                elif layer in ('WRECKS','OBSTRN'): col=QColor('#ef8d71'); r=4.0
                else: col=QColor('#d7e6eb'); r=2.5
                p.setPen(QPen(col,1)); p.setBrush(col); p.drawEllipse(pts[0],r,r)

    def _draw_vessel(self,p):
        pos=self.world_to_screen(self.vessel_lon,self.vessel_lat)
        if pos.x()<-60 or pos.x()>self.width()+60 or pos.y()<-60 or pos.y()>self.height()+60: return
        icon_angle=(self.heading+self._view_rotation())%360
        p.save(); p.translate(pos); p.rotate(icon_angle)
        poly=[QPointF(0,-20),QPointF(10,13),QPointF(0,8),QPointF(-10,13)]
        p.setBrush(QColor('#d8f5ff')); p.setPen(QPen(QColor('#61d7ff'),2)); p.drawPolygon(*poly); p.restore()
        p.setFont(QFont('Arial',8,QFont.Bold)); p.setPen(QColor('#d8f5ff'))
        p.drawText(pos+QPointF(13,-11),'DR BOAT')

    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height()
        self.draw_world_basemap(p); self.draw_vector_chart(p); self.draw_global_utm_grid(p)
        if len(self.route)>0:
            p.setPen(QPen(QColor('#41d7ff'),2)); pts=[self.utm_to_screen(*q) for q in self.route]
            for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
            p.setBrush(QColor('#41d7ff'))
            for i,q in enumerate(pts): p.drawEllipse(q,5,5); p.drawText(q+QPointF(7,-7),f'WP{i+1}')
        if len(self.measure)==2:
            a,b=self.measure; pa,pb=self.utm_to_screen(*a),self.utm_to_screen(*b)
            p.setPen(QPen(QColor('#f2c35b'),2,Qt.DashLine)); p.drawLine(pa,pb)
            d,brg=self.dist_bearing(a,b); mid=(pa+pb)/2; p.drawText(mid+QPointF(8,-8),f'{d:.1f} m / {d/1852:.3f} NM · {brg:.1f}°')
        if self.show_track and len(self.track)>1:
            p.setPen(QPen(QColor('#46e39c'),2)); pts=[self.utm_to_screen(*q) for q in self.track]
            for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
        self._draw_vessel(p)
        p.setPen(QColor('#d9f3fb')); p.setFont(QFont('Arial',10,QFont.Bold))
        src='GNSS LIVE' if self.gnss_live else 'START POSITION · MINA ZAYED · GNSS WAITING'
        p.drawText(14,22,f'{src}   |   {self.view_mode}')
        p.setPen(QColor('#82aebf')); p.setFont(QFont('Arial',9)); p.drawText(14,40,self.chart_name[:105])
        p.setPen(QColor('#79cce8')); p.drawText(w-280,22,f'HDG {self.heading:05.1f}°   COG {self.course:05.1f}°   {self.speed:.1f} kn')
        p.drawText(w-280,40,f'ZOOM {self.world_zoom:.1f}x   FOLLOW {"ON" if self.follow_vessel else "OFF"}')

def utm_to_latlon(easting,northing,zone,hemisphere='N'):
    # WGS84 inverse UTM, dependency-free for the lightweight RPi build.
    a=6378137.0; ecc=0.00669438; k0=0.9996; e1=(1-math.sqrt(1-ecc))/(1+math.sqrt(1-ecc))
    x=easting-500000.0; y=northing
    if str(hemisphere).upper().startswith('S'): y-=10000000.0
    lon0=(int(zone)-1)*6-180+3
    M=y/k0; mu=M/(a*(1-ecc/4-3*ecc**2/64-5*ecc**3/256))
    j1=3*e1/2-27*e1**3/32; j2=21*e1**2/16-55*e1**4/32; j3=151*e1**3/96; j4=1097*e1**4/512
    fp=mu+j1*math.sin(2*mu)+j2*math.sin(4*mu)+j3*math.sin(6*mu)+j4*math.sin(8*mu)
    e2=ecc/(1-ecc); C1=e2*math.cos(fp)**2; T1=math.tan(fp)**2
    N1=a/math.sqrt(1-ecc*math.sin(fp)**2); R1=a*(1-ecc)/(1-ecc*math.sin(fp)**2)**1.5; D=x/(N1*k0)
    lat=fp-(N1*math.tan(fp)/R1)*(D**2/2-(5+3*T1+10*C1-4*C1**2-9*e2)*D**4/24+(61+90*T1+298*C1+45*T1**2-252*e2-3*C1**2)*D**6/720)
    lon=math.radians(lon0)+(D-(1+2*T1+C1)*D**3/6+(5-2*C1+28*T1-3*C1**2+8*e2+24*T1**2)*D**5/120)/math.cos(fp)
    return math.degrees(lat),math.degrees(lon)


def latlon_to_utm(lat,lon):
    # WGS84 forward UTM. Returns zone, hemisphere, easting, northing.
    a=6378137.0; ecc=0.00669438; k0=0.9996
    lat=float(lat); lon=float(lon)
    zone=int((lon+180)//6)+1
    zone=max(1,min(60,zone))
    hemi='N' if lat>=0 else 'S'
    latr=math.radians(lat); lonr=math.radians(lon)
    lon0=math.radians((zone-1)*6-180+3)
    eccp=ecc/(1-ecc)
    N=a/math.sqrt(1-ecc*math.sin(latr)**2)
    T=math.tan(latr)**2
    C=eccp*math.cos(latr)**2
    A=math.cos(latr)*(lonr-lon0)
    M=a*((1-ecc/4-3*ecc**2/64-5*ecc**3/256)*latr
         -(3*ecc/8+3*ecc**2/32+45*ecc**3/1024)*math.sin(2*latr)
         +(15*ecc**2/256+45*ecc**3/1024)*math.sin(4*latr)
         -(35*ecc**3/3072)*math.sin(6*latr))
    e=k0*N*(A+(1-T+C)*A**3/6+(5-18*T+T*T+72*C-58*eccp)*A**5/120)+500000
    n=k0*(M+N*math.tan(latr)*(A*A/2+(5-T+9*C+4*C*C)*A**4/24+(61-58*T+T*T+600*C-330*eccp)*A**6/720))
    if lat<0: n+=10000000
    return zone,hemi,e,n


def flatten_geojson_geometry(geom):
    # Return a list of (kind, coordinates) items using lon/lat coordinates.
    if not geom: return []
    typ=geom.get('type'); c=geom.get('coordinates')
    if typ=='Point': return [('Point',c)]
    if typ=='MultiPoint': return [('Point',p) for p in c]
    if typ=='LineString': return [('LineString',c)]
    if typ=='MultiLineString': return [('LineString',x) for x in c]
    if typ=='Polygon': return [('Polygon',ring) for ring in c]
    if typ=='MultiPolygon':
        out=[]
        for poly in c:
            for ring in poly: out.append(('Polygon',ring))
        return out
    if typ=='GeometryCollection':
        out=[]
        for g in geom.get('geometries',[]): out.extend(flatten_geojson_geometry(g))
        return out
    return []


class PositionSourceCard(QFrame):
    def __init__(self,title,subtitle,status='STANDBY',parent=None):
        super().__init__(parent); self.setObjectName('fleetCard'); self.setMaximumHeight(72)
        l=QVBoxLayout(self); l.setContentsMargins(8,4,8,4); l.setSpacing(1)
        self.title=QLabel(title); self.title.setObjectName('sectionTitle'); l.addWidget(self.title)
        self.sub=QLabel(subtitle); self.sub.setObjectName('smallStatus'); l.addWidget(self.sub)
        self.status=QLabel(status); self.status.setStyleSheet('font-weight:900;color:#f2c35b;'); l.addWidget(self.status)
    def set_status(self,text,ok=False):
        self.status.setText(text); self.status.setStyleSheet('font-weight:900;color:%s;' % ('#46e39c' if ok else '#f2c35b'))


class PositioningSystemPage(QWidget):
    # Update files (.001/.002/...) are deliberately excluded from selectable chart cells.
    CHART_EXTENSIONS={'.kap','.bsb','.000','.001','.002','.003','.004','.005','.s57','.enc','.geojson','.json','.mbtiles','.sqlite','.tif','.tiff','.png','.jpg','.jpeg','.a','.b','.c','.d','.e','.f','.g','.z'}
    def __init__(self,main_window):
        super().__init__(); self.main_window=main_window; self.chart_dir=None; self.chart_files=[]; self.track_recording=False
        root=QVBoxLayout(self); root.setContentsMargins(8,7,8,8); root.setSpacing(5)
        top=QHBoxLayout(); title=QLabel('DR BOAT AI POSITIONING SYSTEM'); title.setObjectName('pageTitle'); top.addWidget(title); top.addStretch()
        self.mode=QLabel('POSITION MODE · MINA ZAYED START · GNSS WAITING'); self.mode.setObjectName('aiBadge'); top.addWidget(self.mode); root.addLayout(top)
        body=QHBoxLayout(); body.setSpacing(6)
        self.left=QFrame(); self.left.setObjectName('mapPanel'); ll=QVBoxLayout(self.left); ll.setContentsMargins(6,6,6,6); ll.setSpacing(4)
        tools1=QHBoxLayout()
        for label,fn in [('ADD CHART DIRECTORY',self.choose_chart_directory),('CHART MANAGER',self.show_chart_manager),('WORLD MAP',self.load_world_map),('FIT ENC',lambda:self.canvas.fit_vector_chart()),('ZOOM +',lambda:self.canvas.zoom_in()),('ZOOM −',lambda:self.canvas.zoom_out()),('RECENTER',self.recenter_vessel)]:
            b=QPushButton(label); b.clicked.connect(fn); tools1.addWidget(b)
        ll.addLayout(tools1)
        tools2=QHBoxLayout()
        for label,fn in [('NORTH UP',lambda:self.canvas.set_view_mode('NORTH UP')),('HEAD UP',lambda:self.canvas.set_view_mode('HEAD UP')),('COURSE UP',lambda:self.canvas.set_view_mode('COURSE UP')),('MEASURE',lambda:self.canvas.set_tool('MEASURE')),('DRAW ROUTE',self.start_route),('TRACK',self.toggle_track),('UTM ↔ LAT/LON',self.show_coordinate_dialog),('MAXIMIZE MAP',self.toggle_maximize)]:
            b=QPushButton(label); b.clicked.connect(fn); tools2.addWidget(b)
        ll.addLayout(tools2)
        self.canvas=UTMMapCanvas(); self.canvas.routeFinished.connect(self.route_finished); ll.addWidget(self.canvas,1)
        lower=QHBoxLayout(); self.chart_combo=QComboBox(); self.chart_combo.currentIndexChanged.connect(self.chart_selected); lower.addWidget(self.chart_combo,1)
        self.chart_status=QLabel('CHART DIRECTORY: NOT SELECTED'); self.chart_status.setObjectName('smallStatus'); lower.addWidget(self.chart_status); ll.addLayout(lower)
        body.addWidget(self.left,7)
        self.side=QScrollArea(); self.side.setWidgetResizable(True); self.side.setMaximumWidth(285); self.side.setFrameShape(QFrame.NoFrame)
        sh=QWidget(); sl=QVBoxLayout(sh); sl.setSpacing(3); self.cards={}
        for a,b,c in [('GNSS','GPS · Galileo · GLONASS · BeiDou','WAITING'),('IMU','KVH / inertial motion','STANDBY'),('INS','Dead reckoning','STANDBY'),('LOG SPEED','Speed through water','STANDBY'),('LiDAR','Local positioning','STANDBY'),('VISION','Visual positioning','STANDBY'),('RADAR','Radar positioning','STANDBY'),('AI POSITIONING SYSTEM','Fused final position','START POSITION')]:
            card=PositionSourceCard(a,b,c); self.cards[a]=card; sl.addWidget(card)
        self.final=QFrame(); self.final.setObjectName('panel'); fl=QGridLayout(self.final); self.final_labels={}
        for r,(a,b) in enumerate([('FINAL POSITION',f'UTM {self.canvas.zone}{self.canvas.hemisphere}'),('EASTING',f'{self.canvas.easting:,.2f} m'),('NORTHING',f'{self.canvas.northing:,.2f} m'),('LAT / LON',f'{self.canvas.vessel_lat:.6f} / {self.canvas.vessel_lon:.6f}'),('HEADING','000.0°'),('SPEED','0.0 kn'),('CONFIDENCE','START POSITION'),('SOURCE','MINA ZAYED / GNSS WAITING')]):
            x=QLabel(a); x.setObjectName('smallStatus'); y=QLabel(b); y.setStyleSheet('font-weight:800;'); fl.addWidget(x,r,0); fl.addWidget(y,r,1); self.final_labels[a]=y
        sl.addWidget(self.final); sl.addStretch(); self.side.setWidget(sh); body.addWidget(self.side,2); root.addLayout(body,1)
        self.maximized=False; self.restore_chart_directory()
        try: self.canvas.load_world_basemap(reset_view=True)
        except Exception as ex: self.canvas.set_chart_name('WORLD BASE MAP LOAD ERROR: '+str(ex))

    def settings_path(self): return DATA_DIR/'positioning_settings.json'
    def route_dir(self): d=DATA_DIR/'route_history'; d.mkdir(parents=True,exist_ok=True); return d
    def track_dir(self): d=DATA_DIR/'track_history'; d.mkdir(parents=True,exist_ok=True); return d

    def restore_chart_directory(self):
        try:
            d=json.loads(self.settings_path().read_text()).get('chart_directory')
            if d and Path(d).is_dir(): self.load_chart_directory(Path(d))
        except Exception: pass

    def load_world_map(self):
        try:
            n=self.canvas.load_world_basemap(reset_view=False)
            # WORLD MAP means show the whole base without moving the vessel itself.
            self.canvas.world_center_lon=0.0; self.canvas.world_center_lat=10.0; self.canvas.world_zoom=1.0; self.canvas.follow_vessel=False
            self.canvas.set_chart_name(f'NATURAL EARTH WORLD VECTOR BASE · {n} POLYGON RINGS' + (f' + {self.canvas.vector_chart_name}' if self.canvas.vector_chart_name else ''))
        except Exception as ex: QMessageBox.warning(self,'WORLD BASE MAP ERROR',str(ex))

    def recenter_vessel(self): self.canvas.recenter_vessel()

    def choose_chart_directory(self):
        d=QFileDialog.getExistingDirectory(self,'Select Marine Chart Directory',str(Path.home()))
        if d: self.load_chart_directory(Path(d))

    @staticmethod
    def _is_s57_base(f):
        return f.suffix.lower() in {'.000','.s57','.enc'}

    def load_chart_directory(self,path):
        self.chart_dir=path
        try: self.chart_files=sorted([x for x in path.rglob('*') if x.is_file() and (x.suffix.lower() in self.CHART_EXTENSIONS or x.name.upper() in ('CHRLIST.BIN','SERIALNO.TXT'))])[:10000]
        except Exception: self.chart_files=[]
        self.chart_combo.blockSignals(True); self.chart_combo.clear(); self.chart_combo.addItem('WORLD BASE MAP · NO ENC SELECTED',None)
        if any(x.suffix.lower() in {'.a','.b','.c','.d','.e','.f','.g','.z'} for x in self.chart_files): self.chart_combo.addItem('CM93 CHART DATABASE',str(path))
        for f in self.chart_files[:2000]:
            if self._is_s57_base(f) or f.suffix.lower() in {'.geojson','.json'}: self.chart_combo.addItem(f.name,str(f))
        self.chart_combo.blockSignals(False)
        base_count=sum(1 for f in self.chart_files if self._is_s57_base(f)); upd_count=sum(1 for f in self.chart_files if re.fullmatch(r'\.\d{3}',f.suffix.lower()) and f.suffix.lower()!='.000')
        self.chart_status.setText(f'{path} · S-57 BASE CELLS {base_count} · UPDATES {upd_count} HIDDEN')
        try: self.settings_path().write_text(json.dumps({'chart_directory':str(path)},indent=2))
        except Exception: pass

    def chart_cache_dir(self): d=DATA_DIR/'chart_cache'; d.mkdir(parents=True,exist_ok=True); return d

    def convert_s57_to_geojson(self,path):
        p=Path(path)
        if re.fullmatch(r'\.\d{3}',p.suffix.lower()) and p.suffix.lower()!='.000':
            raise RuntimeError('Select the S-57 base cell (.000). Update files (.001/.002/...) are applied by GDAL to the base cell and are not standalone charts.')
        ogr2=shutil.which('ogr2ogr'); ogri=shutil.which('ogrinfo')
        if not ogr2 or not ogri: raise RuntimeError('S-57 support requires GDAL tools. Re-run install.sh to install gdal-bin.')
        cache=self.chart_cache_dir(); merged=cache/(p.stem+'_s57_merged.geojson')
        # Open ONLY the .000 base cell. GDAL applies matching S-57 update files automatically.
        cp=subprocess.run([ogri,'-ro','-so',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=90)
        if cp.returncode!=0: raise RuntimeError((cp.stderr or cp.stdout or 'Unable to inspect S-57 ENC')[-1500:])
        layers=[]
        for line in cp.stdout.splitlines():
            m=re.match(r'\s*\d+:\s*([A-Za-z0-9_]+)',line)
            if m: layers.append(m.group(1))
        if not layers: raise RuntimeError('GDAL opened the file but found no S-57 feature layers.')
        features=[]
        for i,layer in enumerate(layers):
            tmp=cache/(p.stem+f'_{i}_{layer}.geojson')
            c=subprocess.run([ogr2,'-f','GeoJSON',str(tmp),str(p),layer,'-skipfailures'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
            if c.returncode==0 and tmp.exists():
                try:
                    obj=json.loads(tmp.read_text(errors='ignore'))
                    for f in obj.get('features',[]): f.setdefault('properties',{})['_S57_LAYER']=layer
                    features.extend(obj.get('features',[]))
                except Exception: pass
                try: tmp.unlink()
                except Exception: pass
        if not features: raise RuntimeError('S-57 cell opened, but no drawable features could be exported.')
        merged.write_text(json.dumps({'type':'FeatureCollection','features':features})); return merged

    def load_chart_path(self,path):
        p=Path(str(path))
        if not p.exists(): QMessageBox.warning(self,'CHART LOAD ERROR',f'Chart file not found:\n{p}'); return False
        try:
            ext=p.suffix.lower()
            if ext in {'.geojson','.json'}: gj=p; prefix='VECTOR CHART'
            elif ext in {'.000','.s57','.enc'}: gj=self.convert_s57_to_geojson(p); prefix='S-57 ENC'
            elif re.fullmatch(r'\.\d{3}',ext):
                QMessageBox.information(self,'S-57 UPDATE FILE',f'{p.name} is an ENC update, not a standalone chart.\n\nSelect {p.stem}.000 instead.'); return False
            else:
                QMessageBox.information(self,'CHART FORMAT',f'{p.name}\n\nV8.3 overlays S-57 ENC and GeoJSON on the permanent world base map. CM93 remains detection-only.'); return False
            n=self.canvas.load_geojson_chart(gj); self.canvas.vector_chart_name=p.name; self.canvas.fit_vector_chart()
            self.canvas.set_chart_name(f'WORLD BASE + {prefix} · {p.name} · {n} FEATURES')
            return True
        except Exception as ex: QMessageBox.warning(self,'CHART LOAD ERROR',str(ex)); return False

    def load_demo_chart(self):
        demo=APP_DIR/'charts'/'DRBOAT_DEMO_VECTOR.geojson'
        if not demo.exists(): QMessageBox.warning(self,'DEMO CHART','Bundled demo vector file is missing.'); return False
        ok=self.load_chart_path(demo)
        if ok: self.canvas.set_chart_name('WORLD BASE + DR BOAT DEMO VECTOR · TEST ONLY')
        return ok

    def chart_selected(self,idx):
        data=self.chart_combo.itemData(idx)
        if not data: return
        p=Path(str(data))
        if p.is_dir(): QMessageBox.information(self,'CM93 DATABASE','CM93 files are detected but not decoded. Load an S-57 .000 cell or GeoJSON.'); return
        self.load_chart_path(p)

    def show_chart_manager(self):
        d=QDialog(self); d.setWindowTitle(f'DR BOAT VECTOR CHART MANAGER · V{APP_VERSION}'); d.resize(800,560)
        lay=QVBoxLayout(d); info=QLabel('S-57 base cells (.000) and GeoJSON are selectable. ENC update files (.001/.002/...) are hidden and automatically belong to their .000 base cell. Loaded charts remain geographic overlays on the permanent world map.')
        info.setWordWrap(True); lay.addWidget(info); lst=QListWidget(); lay.addWidget(lst,1)
        cm=base=updates=geo=0
        for f in self.chart_files:
            ext=f.suffix.lower(); typ=None
            if ext in {'.a','.b','.c','.d','.e','.f','.g','.z'}: typ='CM93'; cm+=1
            elif self._is_s57_base(f): typ='S-57 ENC'; base+=1
            elif re.fullmatch(r'\.\d{3}',ext): updates+=1; continue
            elif ext in {'.geojson','.json'}: typ='GeoJSON'; geo+=1
            if typ:
                item=QListWidgetItem(f'[{typ}]  {f.name}'); item.setToolTip(str(f)); item.setData(Qt.UserRole,str(f)); lst.addItem(item)
            if lst.count()>=1500: break
        stats=QLabel(f'Detected: CM93 cells {cm} · S-57 BASE cells {base} · S-57 updates {updates} hidden · GeoJSON {geo}'); stats.setObjectName('smallStatus'); lay.addWidget(stats)
        row=QHBoxLayout(); load=QPushButton('LOAD SELECTED CHART'); demo=QPushButton('LOAD DEMO VECTOR'); add=QPushButton('ADD / CHANGE DIRECTORY'); close=QPushButton('CLOSE')
        def do_load(item=None):
            it=item or lst.currentItem()
            if not it: QMessageBox.information(d,'CHART MANAGER','Select a chart first.'); return
            fp=it.data(Qt.UserRole); ext=Path(fp).suffix.lower()
            if ext in {'.a','.b','.c','.d','.e','.f','.g','.z'}: QMessageBox.information(d,'CM93','CM93 is detection-only in V8.3. Select an S-57 .000 cell.'); return
            if self.load_chart_path(fp): d.accept()
        load.clicked.connect(lambda:do_load()); lst.itemDoubleClicked.connect(do_load); demo.clicked.connect(lambda:(d.accept(),self.load_demo_chart())); add.clicked.connect(lambda:(d.accept(),self.choose_chart_directory())); close.clicked.connect(d.accept)
        row.addWidget(load); row.addWidget(demo); row.addWidget(add); row.addStretch(); row.addWidget(close); lay.addLayout(row); d.exec_()

    def start_route(self):
        self.canvas.route=[]; self.canvas.set_tool('ROUTE'); QMessageBox.information(self,'DRAW ROUTE','Click WP1, then WP2, WP3…\nDouble-click the final waypoint to finish and save the route.')

    def route_finished(self,route):
        legs=[]; total=0
        for i in range(len(route)-1): d,b=self.canvas.dist_bearing(route[i],route[i+1]); total+=d; legs.append((i+1,i+2,d,b))
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); path=self.route_dir()/f'route_{stamp}.json'
        path.write_text(json.dumps({'created':datetime.now().isoformat(),'zone':self.canvas.zone,'hemisphere':self.canvas.hemisphere,'waypoints':[{'wp':i+1,'easting':p[0],'northing':p[1]} for i,p in enumerate(route)],'total_m':total,'total_nm':total/1852},indent=2))
        rows='\n'.join([f'WP{a} → WP{b}: {d:.1f} m / {d/1852:.3f} NM · BRG {brg:.1f}°' for a,b,d,brg in legs]); QMessageBox.information(self,'ROUTE SUMMARY',f'{rows}\n\nTOTAL: {total:.1f} m / {total/1852:.3f} NM\nWAYPOINTS: {len(route)}\nSaved to Route History.')

    def toggle_track(self):
        if not self.track_recording:
            self.track_recording=True; self.canvas.track=[]; self.canvas.show_track=True; QMessageBox.information(self,'TRACK','Track recording started. Press TRACK again to stop and save.')
        else:
            self.track_recording=False; stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); path=self.track_dir()/f'track_{stamp}.json'; path.write_text(json.dumps({'created':datetime.now().isoformat(),'points':[{'easting':p[0],'northing':p[1]} for p in self.canvas.track]},indent=2)); QMessageBox.information(self,'TRACK','Track stopped and saved to Track History.')

    def toggle_maximize(self):
        self.maximized=not self.maximized; self.side.setVisible(not self.maximized); self.chart_status.setVisible(not self.maximized); self.chart_combo.setVisible(not self.maximized)

    def show_coordinate_dialog(self):
        d=QDialog(self); d.setWindowTitle('UTM ↔ LAT / LON'); lay=QGridLayout(d)
        zone=QLineEdit(str(self.canvas.zone)); hemi=QComboBox(); hemi.addItems(['N','S']); e=QLineEdit(f'{self.canvas.easting:.2f}'); n=QLineEdit(f'{self.canvas.northing:.2f}'); out=QLabel(''); btn=QPushButton('CONVERT UTM → LAT / LON')
        lay.addWidget(QLabel('UTM Zone'),0,0); lay.addWidget(zone,0,1); lay.addWidget(hemi,0,2); lay.addWidget(QLabel('Easting (m)'),1,0); lay.addWidget(e,1,1,1,2); lay.addWidget(QLabel('Northing (m)'),2,0); lay.addWidget(n,2,1,1,2); lay.addWidget(btn,3,0,1,3); lay.addWidget(out,4,0,1,3)
        def conv():
            try:
                lat,lon=utm_to_latlon(float(e.text()),float(n.text()),int(zone.text()),hemi.currentText()); out.setText(f'Latitude: {lat:.7f}°\nLongitude: {lon:.7f}°')
            except Exception: out.setText('Invalid coordinate values.')
        btn.clicked.connect(conv); d.exec_()

    def apply_gnss_fix(self,lat,lon,heading=None,speed=None,course=None):
        """Public adapter hook for the future USB GNSS/NMEA input."""
        self.canvas.set_gnss_fix(lat,lon,heading,speed,course); self.mode.setText('POSITION MODE · GNSS LIVE')
        self.cards['GNSS'].set_status('ONLINE · LIVE FIX',True); self.cards['AI POSITIONING SYSTEM'].set_status('GNSS POSITION ACTIVE',True)
        self._refresh_final_labels()

    def set_gnss_lost(self):
        self.canvas.set_gnss_lost(); self.mode.setText('POSITION MODE · GNSS LOST · LAST POSITION HELD'); self.cards['GNSS'].set_status('LOST',False)

    def _refresh_final_labels(self):
        c=self.canvas; self.final_labels['FINAL POSITION'].setText(f'UTM {c.zone}{c.hemisphere}'); self.final_labels['EASTING'].setText(f'{c.easting:,.2f} m'); self.final_labels['NORTHING'].setText(f'{c.northing:,.2f} m'); self.final_labels['LAT / LON'].setText(f'{c.vessel_lat:.6f} / {c.vessel_lon:.6f}'); self.final_labels['HEADING'].setText(f'{c.heading:05.1f}°'); self.final_labels['SPEED'].setText(f'{c.speed:.1f} kn'); self.final_labels['SOURCE'].setText('GNSS LIVE' if c.gnss_live else 'MINA ZAYED / GNSS WAITING')

    def refresh(self):
        # Do NOT move the navigation vessel from the simulator/fleet demo. Until a real
        # GNSS adapter calls apply_gnss_fix(), the vessel remains at Mina Zayed.
        if self.track_recording: self.canvas.track.append((self.canvas.easting,self.canvas.northing))
        self._refresh_final_labels(); self.canvas.update()
        if not self.canvas.gnss_live:
            self.cards['GNSS'].set_status('WAITING FOR RECEIVER',False); self.cards['AI POSITIONING SYSTEM'].set_status('START POSITION · MINA ZAYED',True)

class FleetPage(QWidget):
    VESSELS = [
        {'id':'SEMAIH','name':'M/T SEMAIH','type':'ASD','location':'Mina Zayed','active_map':True},
        {'id':'AL_FANCI','name':'M/T AL FANCI','type':'ASD','location':'Mina Zayed','active_map':True},
        {'id':'SILA','name':'M/T SILA','type':'ASD'},
        {'id':'AL_AIN','name':'M/T AL AIN','type':'ASD'},
        {'id':'DURAH','name':'M/T DURAH','type':'ASD'},
        {'id':'BUTTINA_1','name':'EM/T BUTTINA 1','type':'ASD'},
        {'id':'BUTTINA_2','name':'EM/T BUTTINA 2','type':'ASD'},
        {'id':'KIZAD','name':'M/T KIZAD','type':'ASD'},
        {'id':'DAS','name':'M/T DAS','type':'ASD'},
        {'id':'MARIA','name':'M/T MARIA','type':'ASD'},
        {'id':'MQTA','name':'M/T MQTA','type':'CONVENTIONAL'},
        {'id':'SAFFER_1','name':'P/B SAFFER 1','type':'CONVENTIONAL'},
        {'id':'SAFFER_2','name':'P/B SAFFER 2','type':'CONVENTIONAL'},
        {'id':'SAFFER_3','name':'P/B SAFFER 3','type':'CONVENTIONAL'},
        {'id':'JAWAD_1','name':'Fire Fighting & Security Boat JAWAD 1','type':'CONVENTIONAL','location':'Yas Marina','active_map':True,'firefighting':True},
    ]
    def __init__(self, main_window, parent=None):
        super().__init__(parent); self.main_window=main_window
        root=QVBoxLayout(self); title=QLabel('FLEET LIST · 15 VESSELS'); title.setObjectName('pageTitle'); root.addWidget(title)
        note=QLabel('JAWAD 1 is managed inside Fleet List only. Double-click JAWAD 1 to open its dedicated remote-control screen.'); note.setObjectName('note'); root.addWidget(note)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); body=QWidget(); grid=QGridLayout(body); grid.setSpacing(8)
        for i,v in enumerate(self.VESSELS):
            c=FleetCard(v); c.doubleClicked.connect(self.open_vessel); grid.addWidget(c,i//3,i%3)
        scroll.setWidget(body); root.addWidget(scroll,1)
    def open_vessel(self, vid):
        v=next(x for x in self.VESSELS if x['id']==vid)
        if vid=='JAWAD_1':
            idx=next((i for i,b in enumerate(self.main_window.boats) if b.get('id')=='JAWAD_1'),None)
            if idx is not None: self.main_window.open_focus(idx)
            return
        QMessageBox.information(self, v['name'], f"{v['name']}\nPROPULSION: {v.get('type','—')}\nSTATUS: FLEET PROFILE READY\n\nLive hardware integration will use the vessel-specific profile.")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"DOCTOR BOAT CONTROL · MARINE INTELLIGENCE V{APP_VERSION}")
        self.resize(1100,650)
        self.setMinimumSize(720,480)
        self.recording = {}
        self.system_state = "READY"
        self.voice_text = "Awaiting command"
        self.boats = []
        for i,v in enumerate(FleetPage.VESSELS):
            self.boats.append({"id":v["id"],"name":v["name"],"type":v.get("type","ASD"),"heading":float((35+i*17)%360),"battery":100 if v["id"]=="JAWAD_1" else 90,"link":100 if v.get("active_map") else 92,"port_angle":0,"stbd_angle":0,"port_rpm":0,"stbd_rpm":0})

        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(0,0,0,0)

        header = QFrame(); header.setObjectName("header")
        hl=QHBoxLayout(header)
        logo_path=APP_DIR/"static"/"drboat_logo.png"
        logo=QLabel()
        if logo_path.exists():
            pm=QPixmap(str(logo_path)).scaled(92,92,Qt.KeepAspectRatio,Qt.SmoothTransformation)
            logo.setPixmap(pm)
        hl.addWidget(logo)
        tt=QVBoxLayout()
        a=QLabel("DR.BOAT"); a.setObjectName("brandTitle")
        b=QLabel(f"DOCTOR BOAT CONTROL · MARINE INTELLIGENCE · V{APP_VERSION}"); b.setObjectName("brandSub")
        tt.addWidget(a); tt.addWidget(b)
        hl.addLayout(tt); hl.addStretch()
        ai_badge=QLabel(f"AI MARINE OPERATIONS · V{APP_VERSION}"); ai_badge.setObjectName("aiBadge"); hl.addWidget(ai_badge)

        root.addWidget(header)

        nav=QFrame(); nav.setObjectName("nav")
        nl=QHBoxLayout(nav)
        names = [
            ("COMMAND CENTER",0),
            ("DOCTOR BOAT AI POSITIONING SYSTEM",1),
            ("FLEET CONTROL",2),
            ("AI TRAINING & MANEUVER LIBRARY",3),
            ("PILOT & TUG MASTER TRAINING",4),
            ("SYSTEM / UPDATES",5),
        ]
        for text,idx in names:
            q=QPushButton(text)
            q.clicked.connect(lambda _,i=idx:self.pages.setCurrentIndex(i))
            nl.addWidget(q)
        root.addWidget(nav)

        self.pages=QStackedWidget()
        self.command=CommandCenter(self)
        self.map_widget=self.command.map_widget
        self.positioning=PositioningSystemPage(self)
        self.fleet=FleetPage(self)
        self.library=LibraryPage()
        self.training=TrainingPage()
        self.system=SystemPage(self)
        for x in (self.command,self.positioning,self.fleet,self.library,self.training,self.system):
            scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setWidget(x)
            self.pages.addWidget(scroll)
        root.addWidget(self.pages,1)
        self.setCentralWidget(central)

        self.apply_style()
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1500)
        self.tick()

    def apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background:#06141e; color:#dcebf2; font-family:Arial; }
        QFrame#header { background:#092333; border-bottom:1px solid #315e72; }
        QFrame#nav { background:#071c28; border-bottom:1px solid #244b5c; }
        QLabel#brandTitle { font-size:30px; font-weight:bold; letter-spacing:3px; }
        QLabel#brandSub { color:#91b4c3; font-size:11px; }
        QLabel#aiBadge { border:1px solid #397b98; border-radius:12px; padding:8px 14px; color:#9ee7ff; font-weight:bold; letter-spacing:1px; background:#0a293a; }
        QPushButton { background:#123648; color:#e2eff4; border:1px solid #3d7186; border-radius:9px; padding:8px 11px; font-weight:600; }
        QPushButton:hover { background:#17455b; }
        QPushButton#recordButton { background:#8b1d26; border-color:#d04450; font-weight:bold; }
        QFrame#panel, QFrame#mapPanel { background:#0b2635; border:1px solid #2f6074; border-radius:12px; }
        QFrame#fleetCard { background:#0d2939; border:1px solid #2e6b86; border-radius:9px; }
        QLabel#camera { background:#081923; border:1px solid #3e7186; color:#9abac8; font-size:14px; }
        QLabel#metric { background:#071923; border:1px solid #173646; padding:7px; font-weight:bold; }
        QLabel#sectionTitle { font-size:15px; font-weight:bold; color:#eaf5fa; }
        QLabel#pageTitle { font-size:21px; font-weight:bold; padding:6px; letter-spacing:1px; }
        QLabel#smallStatus { color:#86aab9; font-size:10px; }
        QLabel#mapPlaceholder { background:#071923; border:1px solid #21475a; color:#86aab9; font-size:15px; }
        QLabel#note { color:#8eb1c0; padding:12px; }
        QLineEdit, QTextEdit, QListWidget, QComboBox { background:#071923; border:1px solid #315e72; color:#e3eef3; padding:7px; }
        """)

    def tick(self):
        for i,b in enumerate(self.boats):
            b["heading"]=(b["heading"]+0.18+(i*0.03))%360
            # Small stable simulation movement until real telemetry is wired.
            b["port_rpm"]=max(0, b["port_rpm"] + (1 if int(time.time())%4==0 else -1 if int(time.time())%5==0 else 0))
            b["stbd_rpm"]=max(0, b["stbd_rpm"] + (1 if int(time.time())%5==0 else -1 if int(time.time())%6==0 else 0))
        self.command.refresh()
        self.positioning.refresh()
        self.append_logs()

    def boat_by_id(self, boat_id):
        return next((b for b in self.boats if b.get("id")==boat_id),None)

    def ensure_boats(self, ids):
        # Fleet profiles are preloaded; method kept for future live-discovered units.
        return

    def open_focus_by_id(self, boat_id):
        idx=next((i for i,b in enumerate(self.boats) if b.get("id")==boat_id),None)
        if idx is not None: self.open_focus(idx)

    def append_logs(self):
        now=datetime.now().isoformat(timespec="milliseconds")
        for boat_id, name in list(self.recording.items()):
            b=next((x for x in self.boats if x["id"]==boat_id),None)
            if not b: continue
            with (MISSIONS_DIR/(name+".jsonl")).open("a",encoding="utf-8") as f:
                f.write(json.dumps({"time":now,"boat":dict(b)},ensure_ascii=False)+"\n")

    def start_log(self, boat_id):
        name, ok = self.get_mission_name()
        if not ok: return
        safe="".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name) or "Maneuver"
        mission=f"{safe}_{boat_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.recording[boat_id]=mission
        self.library.reload()

    def get_mission_name(self):
        # Keep V3 dependency-light: use a small custom dialog instead of QInputDialog.
        d=QDialog(self); d.setWindowTitle("Log Maneuver")
        l=QVBoxLayout(d)
        l.addWidget(QLabel("Maneuver name"))
        e=QLineEdit("Cast_Off"); l.addWidget(e)
        row=QHBoxLayout()
        okb=QPushButton("START LOG"); cb=QPushButton("CANCEL")
        row.addWidget(okb); row.addWidget(cb); l.addLayout(row)
        result={"ok":False}
        okb.clicked.connect(lambda:(result.update(ok=True),d.accept()))
        cb.clicked.connect(d.reject)
        d.exec_()
        return e.text().strip(), result["ok"]

    def stop_log(self, boat_id):
        self.recording.pop(boat_id,None)
        self.library.reload()

    def set_voice(self):
        self.voice_text=self.command.voice.text().strip() or "Awaiting command"
        QMessageBox.information(self,"AI Console",f"Simulation command received:\n{self.voice_text}")

    def estop(self):
        self.system_state="SIM E-STOP"
        for b in self.boats:
            b["port_rpm"]=0; b["stbd_rpm"]=0

    def reset_estop(self):
        self.system_state="READY"

    def open_focus(self, boat_index):
        d=FocusDialog(self,boat_index)
        d.exec_()


def refresh_desktop_shortcut():
    """Keep the desktop launcher name/path aligned with the running release."""
    try:
        desk=Path.home()/"Desktop"
        desk.mkdir(exist_ok=True)
        target=desk/f"Doctor Boat Control Marine Intelligence V{APP_VERSION}.desktop"
        content=("[Desktop Entry]\n"
                 "Version=1.0\nType=Application\n"
                 f"Name=Doctor Boat Control Marine Intelligence V{APP_VERSION}\n"
                 f"Comment=DR.BOAT AI Marine Control V{APP_VERSION}\n"
                 f"Exec={Path.home()}/.local/bin/drboat\n"
                 f"Icon={APP_DIR/'static/drboat_logo.png'}\n"
                 "Terminal=false\nCategories=Utility;\nStartupNotify=true\n")
        # remove obsolete Doctor Boat version launchers, leave unrelated DR-BOAT launcher untouched
        for old in desk.glob("Doctor Boat Control Marine Intelligence V*.desktop"):
            if old != target:
                try: old.unlink()
                except Exception: pass
        target.write_text(content,encoding='utf-8'); os.chmod(target,0o755)
    except Exception:
        pass

def main():
    refresh_desktop_shortcut()
    app=QApplication(sys.argv)
    w=MainWindow()
    w.show()
    sys.exit(app.exec_())

if __name__=="__main__":
    main()
