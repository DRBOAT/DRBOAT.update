
import os, sys, json, math, time, shutil, hashlib, zipfile, tempfile, subprocess, urllib.request, re, socket, threading
from pathlib import Path
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QUrl, QProcess, QSize, QPointF, QRectF
from PyQt5.QtGui import QPixmap, QPainter, QPen, QColor, QFont, QWindow, QImage, QKeySequence
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QGridLayout, QStackedWidget, QFrame, QMessageBox, QSplitter, QDialog, QListWidget,
    QListWidgetItem, QTextEdit, QLineEdit, QComboBox, QProgressBar, QScrollArea, QSlider,
    QGroupBox, QDial, QAbstractItemView, QFileDialog, QMenu, QAction, QTableWidget,
    QTableWidgetItem, QHeaderView, QDoubleSpinBox, QInputDialog, QCheckBox, QShortcut, QSpinBox
)

APP_VERSION = "10.0.0"
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
MISSIONS_DIR = DATA_DIR / "missions"
MISSIONS_DIR.mkdir(parents=True, exist_ok=True)
UPDATE_MANIFEST = "https://raw.githubusercontent.com/DRBOAT/DRBOAT.update/main/version.json"

def version_tuple(v):
    out = []
    for p in str(v).split("."):
        m = "".join(ch for ch in p if ch.isdigit())
        out.append(int(m or 0))
    return tuple((out + [0,0,0])[:3])

def mem_available_mb():
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) // 1024
    except Exception:
        pass
    return None

def cpu_temp_c():
    try:
        return int(Path("/sys/class/thermal/thermal_zone0/temp").read_text().strip()) / 1000.0
    except Exception:
        return None


class ManeuverCanvas(QWidget):
    """Interactive tug-maneuver trainer with simple force/moment physics.

    V9.1 training rules:
    - 1..4 active tugs, each assignable to any station.
    - Every tug can PULL, STOP/FOLLOW, or PUSH.
    - Center-lead bow/aft stations remain attached to the vessel and follow its motion.
    - Clock orders are relative to the vessel heading (12 = dead ahead).
    - Quays are solid training boundaries; the vessel cannot pass through them.
    - HDG / SOG / ROT are derived live from the simulated motion.
    """
    SECURE_POINTS = [
        ("CENTER LEAD BOW",       0.000, -0.102, 'TOW'),
        ("CENTER LEAD AFT",       0.000,  0.102, 'TOW'),
        ("STARBOARD BOW",         0.038, -0.060, 'SIDE'),
        ("STARBOARD QUARTER",     0.038,  0.060, 'SIDE'),
        ("PORT BOW",             -0.038, -0.060, 'SIDE'),
        ("PORT QUARTER",         -0.038,  0.060, 'SIDE'),
    ]
    # Fixed operational clock sectors requested for each lead. Invalid hours are never accepted.
    ALLOWED_CLOCKS = {
        0: [7,8,9,10,11,12,1,2,3,4,5],
        1: [3,4,5,6,7,8,9],
        2: [12,1,2,3,4,5],
        3: [11,12,1,2,3,4,5,6],
        4: [12,11,10,9,8,7,6],
        5: [11,10,9,8,7,6],
    }
    VESSEL_DIMS = {
        'CONTAINER SHIP':(220.,32.2), 'BULK CARRIER':(190.,32.0), 'TANKER':(185.,32.2),
        'GENERAL CARGO':(175.,28.0), 'JACK-UP BARGE':(150.,50.0), 'TUG & BARGE':(150.,45.0)
    }
    TUG_DIMS=(30.,11.)
    # x, y, width, height in normalized map coordinates.
    SOLID_QUAYS = [
        (.785, .18, .030, .66),
        (.605, .105, .365, .030),
        (.000, .745, .355, .032),
        (.115, .545, .165, .026),
    ]
    PULL_LEVELS = {
        'TIGHT LINE': .10,
        'SLOW TIGHT LINE': .32,
        'HALF TIGHT LINE': .62,
        'FULL TIGHT LINE': 1.00,
    }
    PUSH_LEVELS = {
        'LEAN ON': .08,
        'MINI PUSH': .20,
        'SLOW PUSH': .38,
        'HALF POWER PUSH': .65,
        'FULL POWER PUSH': 1.00,
    }

    def __init__(self,parent=None):
        super().__init__(parent)
        self.setMinimumSize(720,560); self.setMouseTracking(True)
        self.running=False; self.secured=False
        self.ship_x=.50; self.ship_y=.56; self.ship_heading=157.0; self.ship_speed_cmd=15.0/6200.0; self.rudder=0.
        self.vx=0.; self.vy=0.; self.omega=0.
        self.zoom=1.; self.pan_x=0.; self.pan_y=0.; self._drag=None
        self.view_mode='TRAINING VECTOR'; self.ship_type='CONTAINER SHIP'; self.active_tug_count=4
        self.start_lat=24.5472670; self.start_lon=54.3818479; self.start_heading=157.0
        self.time_scale=1; self.voice_orders=False; self.wave_phase=0.0
        self.tile_cache_dir=DATA_DIR/'training_tile_cache'; self.tile_cache_dir.mkdir(parents=True,exist_ok=True)
        self._tile_active=set(); self._tile_lock=threading.Lock(); self._tile_max_active=4
        defaults=[0,1,2,5]
        self.tugs=[]
        for i in range(4):
            self.tugs.append({
                'name':f'TUG {i+1}','x':.41+i*.06,'y':.40,'angle':0.,'visual_angle':157.,
                'secured':False,'point':defaults[i],'action':'STOP / FOLLOW','level':'TIGHT LINE'
            })
        self.timer=QTimer(self); self.timer.timeout.connect(self.step); self.timer.start(50)
        self._build_ship_overlay()

    def _build_ship_overlay(self):
        self.ship_overlay=QFrame(self)
        self.ship_overlay.setObjectName('panel')
        self.ship_overlay.setStyleSheet('QFrame{background:rgba(4,25,36,215);border:1px solid #41616b;border-radius:7px;} QPushButton{min-height:20px;padding:1px 5px;font-size:8px;} QLabel{font-size:8px;}')
        lay=QVBoxLayout(self.ship_overlay); lay.setContentsMargins(6,4,6,4); lay.setSpacing(2)
        head=QLabel('SHIP CONTROL'); head.setAlignment(Qt.AlignCenter); lay.addWidget(head)
        row=QHBoxLayout(); row.setSpacing(2)
        self.speed_orders=[('FULL AST',-15.),('HALF AST',-8.),('MIN AST',-6.),('D.SLOW AST',-2.),('STOP',0.),('D.SLOW AHD',2.),('MIN AHD',6.),('HALF AHD',10.),('FULL AHD',15.)]
        for text,kn in self.speed_orders:
            b=QPushButton(text); b.setMinimumWidth(40); b.clicked.connect(lambda _,q=kn:self.set_speed_order(q)); row.addWidget(b)
        lay.addLayout(row)
        rudrow=QHBoxLayout(); rudrow.setSpacing(4)
        lab=QLabel('RUDDER'); rudrow.addWidget(lab)
        self.overlay_rudder=QSlider(Qt.Horizontal); self.overlay_rudder.setRange(-35,35); self.overlay_rudder.setFixedWidth(115); self.overlay_rudder.valueChanged.connect(lambda x:setattr(self,'rudder',x)); rudrow.addWidget(self.overlay_rudder)
        self.overlay_rudder_label=QLabel('0°'); self.overlay_rudder_label.setFixedWidth(30); self.overlay_rudder.valueChanged.connect(lambda x:self.overlay_rudder_label.setText(f'{x:+d}°')); rudrow.addWidget(self.overlay_rudder_label)
        lay.addLayout(rudrow)
        self.ship_overlay.adjustSize(); self.ship_overlay.raise_()

    def set_speed_order(self,knots):
        # Convert ordered knots to the simulator's normalized target velocity.
        self.ship_speed_cmd=float(knots)/6200.0

    def set_time_scale(self,n):
        self.time_scale=max(1,min(5,int(n))); self.update()

    def execute_voice_order(self,text):
        t=' '.join(str(text).upper().replace('-',' ').split())
        m=re.search(r'TUG\s*(?:NUMBER\s*)?(ONE|TWO|THREE|FOUR|1|2|3|4)',t)
        if not m: return False,'Tug number not understood'
        mp={'ONE':0,'TWO':1,'THREE':2,'FOUR':3,'1':0,'2':1,'3':2,'4':3}; i=mp[m.group(1)]
        if i>=self.active_tug_count: return False,f'TUG {i+1} is not active'
        if 'PROCEED' in t and 'SECURE' in t:
            self.secured=True; return True,f'PILOT, TUG {i+1}: PROCEEDING TO SECURE'
        if 'STOP' in t: self.tugs[i]['action']='STOP / FOLLOW'; return True,f'PILOT, TUG {i+1}: STOP / FOLLOW'
        if 'PULL' in t: self.tugs[i]['action']='PULL'; return True,f'PILOT, TUG {i+1}: PULLING'
        if 'PUSH' in t: self.tugs[i]['action']='PUSH'; return True,f'PILOT, TUG {i+1}: PUSHING'
        return False,'Order not recognized'

    def resizeEvent(self,e):
        super().resizeEvent(e)
        if hasattr(self,'ship_overlay'):
            self.ship_overlay.adjustSize()
            m=12
            self.ship_overlay.move(max(m,self.width()-self.ship_overlay.width()-m), max(72,self.height()-self.ship_overlay.height()-m))

    def reset_sim(self):
        self.running=False; self.secured=False
        self.ship_x=.50; self.ship_y=.56; self.ship_heading=157.0; self.ship_speed_cmd=15.0/6200.0; self.rudder=0.
        self.vx=self.vy=self.omega=0.; self.zoom=1.; self.pan_x=self.pan_y=0.
        if hasattr(self,'overlay_rudder'): self.overlay_rudder.setValue(0)
        defaults=[0,1,2,5]
        for i,t in enumerate(self.tugs):
            t.update(x=.41+i*.06,y=.40,angle=0.,visual_angle=157.,secured=False,point=defaults[i],action='STOP / FOLLOW',level='TIGHT LINE')
        self.update()

    def _stage_tugs(self):
        # Waiting formation astern of the target, before PROCEED TO SECURE.
        if self.active_tug_count == 1: xs=[.50]
        elif self.active_tug_count == 2: xs=[.455,.545]
        elif self.active_tug_count == 3: xs=[.43,.50,.57]
        else: xs=[.395,.465,.535,.605]
        for i,t in enumerate(self.tugs):
            if i < self.active_tug_count:
                t['x']=xs[i]; t['y']=.40; t['visual_angle']=self.ship_heading; t['secured']=False

    def start(self):
        self.running=True; self.ship_heading=self.start_heading; self.ship_speed_cmd=15.0/6200.0; self._stage_tugs()
    def secure(self): self.secured=True

    def _rot_point(self, ox, oy):
        a=math.radians(self.ship_heading)
        return (self.ship_x+ox*math.cos(a)-oy*math.sin(a), self.ship_y+ox*math.sin(a)+oy*math.cos(a))

    @staticmethod
    def _clock_vec(deg):
        r=math.radians(deg); return math.sin(r), -math.cos(r)

    def _relative_clock_vec(self,deg):
        return self._clock_vec((self.ship_heading+deg)%360)

    def _meters_per_pixel(self):
        return math.cos(math.radians(24.5260))*2*math.pi*6378137.0/(256.0*(1<<16))

    def _ship_pixel_dims(self):
        L,B=self.VESSEL_DIMS.get(self.ship_type,(180.,30.))
        mpp=self._meters_per_pixel()
        return max(14.,L/mpp), max(5.,B/mpp)

    def _hull_local_normalized(self, idx):
        # Attachment points live on the actual hull border and therefore scale with vessel LOA/beam.
        Lpx,Bpx=self._ship_pixel_dims(); w=max(1.,self.width()); h=max(1.,self.height())
        if idx==0: px,py=0.,-Lpx/2
        elif idx==1: px,py=0.,Lpx/2
        elif idx==2: px,py=Bpx/2,-Lpx*.30
        elif idx==3: px,py=Bpx/2,Lpx*.30
        elif idx==4: px,py=-Bpx/2,-Lpx*.30
        else: px,py=-Bpx/2,Lpx*.30
        return px/w,py/h

    def attach_xy(self, idx):
        ax,ay=self._hull_local_normalized(idx); return self._rot_point(ax,ay)

    def allowed_clocks(self, idx):
        return list(self.ALLOWED_CLOCKS.get(int(idx),[12]))

    def clock_allowed(self,idx,deg):
        hour=12 if int(round(deg/30.0))%12==0 else int(round(deg/30.0))%12
        return hour in self.allowed_clocks(idx)

    def tug_station_xy(self, idx, clock_deg):
        axw,ayw=self.attach_xy(idx)
        dx,dy=self._relative_clock_vec(clock_deg)
        # About 45 m stand-off from the lead, expressed in current map pixels/normalized coordinates.
        stand_px=62.0/self._meters_per_pixel(); w=max(1.,self.width()); h=max(1.,self.height())
        return axw+dx*stand_px/w, ayw+dy*stand_px/h

    @staticmethod
    def _ang_lerp(a,b,k):
        d=(b-a+180)%360-180; return (a+d*k)%360

    def _apply_force(self, fx, fy, ax, ay, magnitude):
        self.vx += fx*magnitude
        self.vy += fy*magnitude
        rx=ax-self.ship_x; ry=ay-self.ship_y
        self.omega += (rx*fy-ry*fx)*magnitude*1450.

    def _tug_level_factor(self,t):
        if t['action']=='PULL': return self.PULL_LEVELS.get(t['level'],0.)
        if t['action']=='PUSH': return self.PUSH_LEVELS.get(t['level'],0.)
        return 0.

    def _resolve_quay_collision(self,oldx,oldy):
        # Approximate the ship footprint by a conservative circle. This intentionally
        # prevents visual penetration and is stable on Raspberry Pi hardware.
        radius=.050
        hit=False
        for qx,qy,qw,qh in self.SOLID_QUAYS:
            ex0,ey0=qx-radius,qy-radius; ex1,ey1=qx+qw+radius,qy+qh+radius
            if ex0 <= self.ship_x <= ex1 and ey0 <= self.ship_y <= ey1:
                hit=True
                # Restore the axis that crossed the boundary first.
                if not (ex0 <= oldx <= ex1):
                    self.ship_x = ex0 if oldx < ex0 else ex1
                    self.vx = 0.
                elif not (ey0 <= oldy <= ey1):
                    self.ship_y = ey0 if oldy < ey0 else ey1
                    self.vy = 0.
                else:
                    # Already touching: keep outside by nearest edge.
                    d=[(abs(self.ship_x-ex0),'x',ex0),(abs(self.ship_x-ex1),'x',ex1),(abs(self.ship_y-ey0),'y',ey0),(abs(self.ship_y-ey1),'y',ey1)]
                    _,axis,val=min(d,key=lambda z:z[0])
                    if axis=='x': self.ship_x=val; self.vx=0.
                    else: self.ship_y=val; self.vy=0.
                self.omega *= .55
        return hit

    def navigation_data(self):
        # Scale normalized map velocity to a deliberately slow training SOG.
        sog=math.hypot(self.vx,self.vy)*6200.0
        rot=self.omega*60.0
        return self.ship_heading%360, sog, rot

    def step(self):
        self.wave_phase=(self.wave_phase+0.12*self.time_scale)%(math.pi*2)
        if not self.running:
            self.update(); return
        dt=.05*self.time_scale
        # Slow own-ship propulsion. Command values represent desired training velocity.
        dx,dy=self._relative_clock_vec(0)
        target_vx=dx*self.ship_speed_cmd; target_vy=dy*self.ship_speed_cmd
        alpha=min(.012*self.time_scale,.07)
        self.vx += (target_vx-self.vx)*alpha
        self.vy += (target_vy-self.vy)*alpha
        self.omega += self.rudder*self.ship_speed_cmd*.0040*dt

        if self.secured:
            for i,t in enumerate(self.tugs):
                if i>=self.active_tug_count: continue
                idx=t['point']; ax,ay=self.attach_xy(idx)
                tx,ty=self.tug_station_xy(idx,t['angle'])
                kind=self.SECURE_POINTS[idx][3]
                if not self.clock_allowed(idx,t['angle']):
                    allowed=self.allowed_clocks(idx); hour=min(allowed,key=lambda q:abs(((q%12)*30-t['angle']+180)%360-180)); t['angle']=(hour%12)*30

                if True:
                    # Every tug orbits its real hull lead; no line or tug is allowed to route through the vessel.
                    cur=math.degrees(math.atan2(t['x']-ax, -(t['y']-ay)))%360
                    target_world=(self.ship_heading+t['angle'])%360
                    cur=self._ang_lerp(cur,target_world,.055*self.time_scale)
                    orbit_x,orbit_y=tx,ty
                    k=min(.035*self.time_scale,.18); t['x']+=(orbit_x-t['x'])*k; t['y']+=(orbit_y-t['y'])*k
                    t['visual_angle']=(cur+180)%360
                    t['secured']=math.hypot(t['x']-orbit_x,t['y']-orbit_y)<.009
                else:
                    # Approach a side stand-off and stop at the hull boundary.
                    k=min(.030*self.time_scale,.16); t['x']+=(tx-t['x'])*k; t['y']+=(ty-t['y'])*k
                    t['secured']=math.hypot(t['x']-tx,t['y']-ty)<.009
                    t['visual_angle']=math.degrees(math.atan2(ax-t['x'], -(ay-t['y'])))%360

                if not t['secured']: continue
                action=t['action']; factor=self._tug_level_factor(t)
                if action=='STOP / FOLLOW':
                    # Hold relative geometry only; no force on target vessel.
                    continue
                ox,oy=self._relative_clock_vec(t['angle'])
                if action=='PULL':
                    fx,fy=ox,oy
                    self._apply_force(fx,fy,ax,ay,factor*.000060)
                elif action=='PUSH':
                    # Push from tug toward the vessel, opposite to its outward clock bearing.
                    fx,fy=-ox,-oy
                    self._apply_force(fx,fy,ax,ay,factor*.000055)

        self.vx*=.994; self.vy*=.994; self.omega*=.982
        oldx,oldy=self.ship_x,self.ship_y
        self.ship_x += self.vx*dt; self.ship_y += self.vy*dt
        self.ship_heading=(self.ship_heading+self.omega*dt)%360
        self._resolve_quay_collision(oldx,oldy)
        self.ship_x=max(.065,min(.935,self.ship_x)); self.ship_y=max(.065,min(.925,self.ship_y))
        self.update()

    def wheelEvent(self,e):
        self.zoom=max(.55,min(4.50,self.zoom*(1.13 if e.angleDelta().y()>0 else 1/1.13))); self.update(); e.accept()
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton: self._drag=e.pos(); self.setCursor(Qt.ClosedHandCursor); e.accept()
    def mouseMoveEvent(self,e):
        if self._drag is not None:
            d=e.pos()-self._drag; self._drag=e.pos(); self.pan_x+=d.x(); self.pan_y+=d.y(); self.update(); e.accept()
    def mouseReleaseEvent(self,e):
        if e.button()==Qt.LeftButton: self._drag=None; self.unsetCursor(); e.accept()
    def mouseDoubleClickEvent(self,e):
        self.zoom=1.; self.pan_x=self.pan_y=0.; self.update(); e.accept()

    def _draw_target(self,p,w,h):
        x,y,hdg=self.ship_x,self.ship_y,self.ship_heading; typ=self.ship_type
        L,B=self._ship_pixel_dims()
        p.save(); p.translate(w*x,h*y); p.rotate(hdg); p.setPen(QPen(QColor('#eaf7fb'),1.0))
        from PyQt5.QtGui import QPolygonF
        if typ=='JACK-UP BARGE':
            p.setBrush(QColor('#536575')); p.drawRect(QRectF(-B/2,-L/2,B,L))
            p.setBrush(QColor('#d7dfe4'))
            for xx in (-B*.42,B*.42):
                for yy in (-L*.40,L*.40): p.drawEllipse(QPointF(xx,yy),max(1.2,B*.06),max(1.2,B*.06))
        elif typ=='TUG & BARGE':
            p.setBrush(QColor('#596b78')); p.drawRect(QRectF(-B/2,-L/2,B,L))
        else:
            color={'TANKER':'#6a6772','BULK CARRIER':'#635f55','GENERAL CARGO':'#486472','CONTAINER SHIP':'#31576b'}.get(typ,'#31576b')
            p.setBrush(QColor(color)); bow=.30
            p.drawPolygon(QPolygonF([QPointF(0,-L/2),QPointF(B/2,-L*bow),QPointF(B/2,L/2),QPointF(-B/2,L/2),QPointF(-B/2,-L*bow)]))
            p.setBrush(QColor('#aabfcb')); p.drawRect(QRectF(-B*.32,-L*.02,B*.64,max(2.,L*.12)))
        p.restore()

    @staticmethod
    def _merc_norm(lon,lat):
        x=(float(lon)+180.)/360.; lat=max(-85.05112878,min(85.05112878,float(lat))); r=math.radians(lat)
        y=(1.-math.log(math.tan(r)+1./math.cos(r))/math.pi)/2.; return x,y

    def _training_tile_url(self,provider,z,x,y):
        if provider=='esri': return f'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
        if provider=='osm': return f'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
        if provider=='seamark': return f'https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png'
        return ''

    def _training_tile_path(self,provider,z,x,y): return self.tile_cache_dir/provider/str(z)/str(x)/(str(y)+'.png')

    def _queue_training_tile(self,provider,z,x,y):
        path=self._training_tile_path(provider,z,x,y); key=(provider,z,x,y)
        if path.exists(): return
        with self._tile_lock:
            if key in self._tile_active or len(self._tile_active)>=self._tile_max_active: return
            self._tile_active.add(key)
        def worker():
            try:
                path.parent.mkdir(parents=True,exist_ok=True); req=urllib.request.Request(self._training_tile_url(provider,z,x,y),headers={'User-Agent':'DRBOAT/10.0 training simulator'})
                with urllib.request.urlopen(req,timeout=8) as r: data=r.read(2000000)
                if data: path.write_bytes(data)
            except Exception: pass
            finally:
                with self._tile_lock: self._tile_active.discard(key)
        threading.Thread(target=worker,daemon=True).start()

    def _draw_training_tiles(self,p,provider):
        # Fixed Mina Zayed training window. Zoom/pan remains local to the simulator overlay.
        z=15; n=1<<z; size=256.; cx,cy=self._merc_norm(54.3860,24.5260); cpx=cx*n*size; cpy=cy*n*size
        left=cpx-self.width()/2; top=cpy-self.height()/2; x0=int(left//size)-1; x1=int((left+self.width())//size)+1; y0=int(top//size)-1; y1=int((top+self.height())//size)+1
        for ty in range(y0,y1+1):
            if ty<0 or ty>=n: continue
            for tx in range(x0,x1+1):
                wx=tx%n; path=self._training_tile_path(provider,z,wx,ty); sx=tx*size-left; sy=ty*size-top
                if path.exists():
                    img=QImage(str(path));
                    if not img.isNull(): p.drawImage(QRectF(sx,sy,size+1,size+1),img)
                else: self._queue_training_tile(provider,z,wx,ty)

    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height()
        sea=QColor('#082d46'); quay=QColor('#56686d'); p.fillRect(self.rect(),sea)
        # One camera transform drives chart, quays, ship and tugs together. This fixes the old static-map behavior.
        p.save(); p.translate(w/2+self.pan_x,h/2+self.pan_y); p.scale(self.zoom,self.zoom); p.translate(-w/2,-h/2)
        # V10 TRAINING VECTOR BASE: geometry is rendered natively, so zoom never pixelates.
        # This is simulator-only and does not alter the AI Positioning System map engine.
        p.fillRect(QRectF(0,0,w,h), QColor('#0b4862'))
        from PyQt5.QtGui import QPolygonF
        land=QColor('#7f887f'); edge=QPen(QColor('#d7d4bd'),2.0)
        p.setPen(edge); p.setBrush(land)
        # Clean training shoreline/quay framework for the selected Mina Zayed training window.
        # Coordinates are local simulator geometry; official berth/buoy survey coordinates are not fabricated.
        polys=[
          [(0,0),(.34,0),(.31,.17),(.25,.28),(.22,.43),(.16,.55),(0,.62)],
          [(.76,0),(1,0),(1,.69),(.91,.65),(.86,.53),(.83,.37),(.78,.22)],
          [(0,.86),(.29,.80),(.36,.88),(.39,1),(0,1)],
          [(.78,.86),(1,.80),(1,1),(.70,1),(.72,.92)]
        ]
        for poly in polys:
            p.drawPolygon(QPolygonF([QPointF(x*w,y*h) for x,y in poly]))
        # Quay faces are solid visual edges, kept separate from moving vessels.
        p.setPen(QPen(QColor('#e7e2cf'),3.0))
        for a,b in [((.31,.17),(.16,.55)),((.78,.22),(.86,.53)),((.29,.80),(.36,.88)),((.78,.86),(.72,.92))]:
            p.drawLine(QPointF(a[0]*w,a[1]*h),QPointF(b[0]*w,b[1]*h))
        # Lightweight animated sea texture; visual only, independent from vessel physics.
        p.setPen(QPen(QColor(145,215,232,34),1))
        for yy in range(20,h,34):
            off=10*math.sin(self.wave_phase+yy*.035)
            p.drawArc(QRectF(-20+off,yy,w*.34,18),0,150*16); p.drawArc(QRectF(w*.42+off,yy+8,w*.28,15),0,145*16)
        # V9.4 clean renderer: quay collision geometry remains active in physics but is not drawn as debug art.
        # Legacy channel line, buoy-like dots and training markers are intentionally hidden.
        # Prop-wash/wake graphics intentionally disabled in V10 until the improved effect is ready.
        self._draw_target(p,w,h)

        for i,t in enumerate(self.tugs):
            if i>=self.active_tug_count: continue
            # Light tug wake and a true-scale top-view tug.
            mpp=self._meters_per_pixel(); tl=max(7.,self.TUG_DIMS[0]/mpp); tb=max(3.,self.TUG_DIMS[1]/mpp)
            p.save(); p.translate(w*t['x'],h*t['y']); p.rotate(t.get('visual_angle',t['angle']))
            p.setBrush(QColor('#d5aa36')); p.setPen(QPen(QColor('#eaf7fb'),1.0)); p.drawRoundedRect(QRectF(-tb/2,-tl/2,tb,tl),max(1.,tb*.18),max(1.,tb*.18)); p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(-tb*.30,-tl*.05,tb*.60,tl*.22)); p.restore()
            if self.secured:
                ax,ay=self.attach_xy(t['point']); p.setPen(QPen(QColor('#ffd765'),1.5)); p.drawLine(int(w*t['x']),int(h*t['y']),int(w*ax),int(h*ay))
        p.restore()

        hdg,sog,rot=self.navigation_data()
        p.setPen(QColor('#dcebf2')); p.setBrush(QColor(4,25,36,220)); p.drawRoundedRect(QRectF(8,8,116,92),7,7)
        p.setPen(QColor('#ffffff')); p.setFont(QFont('Sans',9,QFont.Bold))
        p.drawText(16,29,f'HDG  {hdg:06.1f}°'); p.drawText(16,51,f'SOG  {sog:04.2f} kn'); p.drawText(16,73,f'ROT  {rot:+05.2f}°/m')
        p.setFont(QFont('Sans',7)); p.setPen(QColor('#a8c9d4')); p.drawText(16,91,f'{self.view_mode} · ×{self.time_scale}')
        # Pivot point: visual/physics reference moves forward with ahead motion and aft with astern motion.
        ordered=self.ship_speed_cmd*6200.0; frac=max(-1.0,min(1.0,ordered/15.0)); a=math.radians(self.ship_heading)
        pp_shift=-0.050*frac; ppx=self.ship_x+pp_shift*math.sin(a); ppy=self.ship_y-pp_shift*math.cos(a)
        # Pivot reference is retained internally; no debug dot is drawn in the clean simulator view.


class SimulatorDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle(f'DR.BOAT V{APP_VERSION} · PILOT & TUG MASTER TRAINING SIMULATOR')
        self.resize(1280,800); self.setMinimumSize(820,560)
        root=QHBoxLayout(self); root.setContentsMargins(6,6,6,6)
        self.canvas=ManeuverCanvas(); root.addWidget(self.canvas,1)
        side_scroll=QScrollArea(); side_scroll.setWidgetResizable(True); side_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); side_scroll.setMinimumWidth(170); side_scroll.setMaximumWidth(205)
        side=QFrame(); side.setObjectName('panel'); side.setStyleSheet('QLabel{font-size:8px;} QPushButton,QComboBox,QLineEdit{font-size:8px;min-height:19px;padding:1px 4px;} QCheckBox{font-size:8px;}'); v=QVBoxLayout(side); v.setContentsMargins(6,6,6,6); v.setSpacing(4)
        self.vessel=QComboBox(); self.vessel.addItems(['CONTAINER SHIP','BULK CARRIER','TANKER','GENERAL CARGO','JACK-UP BARGE','TUG & BARGE']); self.vessel.currentTextChanged.connect(lambda x:(setattr(self.canvas,'ship_type',x),self.canvas.update())); self.vessel.hide()
        self.mode=QComboBox(); self.mode.addItems(['TRAINING VECTOR']); self.mode.currentTextChanged.connect(lambda x:(setattr(self.canvas,'view_mode',x),self.canvas.update())); v.addWidget(QLabel('MAP VIEW')); v.addWidget(self.mode)

        self.tug_count=QComboBox(); self.tug_count.addItems(['1 TUG','2 TUGS','3 TUGS','4 TUGS']); self.tug_count.setCurrentIndex(3); self.tug_count.currentIndexChanged.connect(self.set_tug_count); self.tug_count.hide()

        r=QHBoxLayout(); bp=QPushButton('BP CALC'); bp.clicked.connect(self.show_pre_maneuver_assessment); sc=QPushButton('PROCEED TO SECURE'); sc.clicked.connect(self.canvas.secure); r.addWidget(bp); r.addWidget(sc); v.addLayout(r)

        simrow=QHBoxLayout()
        self.sim_speed=QPushButton('SIM ×1'); self.sim_speed.clicked.connect(self.cycle_sim_speed); simrow.addWidget(self.sim_speed)
        self.voice_toggle=QCheckBox('VOICE ORDERS'); self.voice_toggle.toggled.connect(lambda on:setattr(self.canvas,'voice_orders',on)); simrow.addWidget(self.voice_toggle); v.addLayout(simrow)
        self.voice_input=QLineEdit(); self.voice_input.setPlaceholderText('e.g. Tug number one proceed to secure'); self.voice_input.returnPressed.connect(self.run_voice_order); v.addWidget(self.voice_input)
        self.voice_reply=QLabel('VOICE: STANDBY'); self.voice_reply.setWordWrap(True); v.addWidget(self.voice_reply)

        v.addWidget(QLabel('SELECT ACTIVE TUG'))
        self.sel=QComboBox(); self.sel.addItems(['TUG 1','TUG 2','TUG 3','TUG 4']); self.sel.currentIndexChanged.connect(self.sync_tug); v.addWidget(self.sel)
        v.addWidget(QLabel('ASSIGN TUG TO STATION'))
        self.point=QComboBox(); self.point.addItems([x[0] for x in ManeuverCanvas.SECURE_POINTS]); self.point.currentIndexChanged.connect(self.set_point); v.addWidget(self.point)

        v.addWidget(QLabel('TUG CLOCK POSITION · RELATIVE TO SHIP'))
        clockrow=QHBoxLayout(); self.ang=QDial(); self.ang.setRange(0,11); self.ang.setWrapping(True); self.ang.setNotchesVisible(True); self.ang.setFixedSize(78,78); self.ang.valueChanged.connect(self.set_angle); clockrow.addWidget(self.ang)
        self.anglab=QLabel("12 O'CLOCK\n000°"); self.anglab.setAlignment(Qt.AlignCenter); clockrow.addWidget(self.anglab,1); v.addLayout(clockrow)

        v.addWidget(QLabel('TUG ACTION'))
        self.action=QComboBox(); self.action.addItems(['STOP / FOLLOW','PULL','PUSH']); self.action.currentTextChanged.connect(self.set_action); v.addWidget(self.action)
        v.addWidget(QLabel('POWER / LINE ORDER'))
        self.level=QComboBox(); self.level.currentTextChanged.connect(self.set_level); v.addWidget(self.level)
        self.state=QLabel('STOP / FOLLOW · NO FORCE'); self.state.setWordWrap(True); v.addWidget(self.state)

        reset=QPushButton('RESET SCENARIO'); reset.clicked.connect(self.canvas.reset_sim); v.addWidget(reset)
        v.addStretch()
        side_scroll.setWidget(side); root.addWidget(side_scroll)
        self.sync_tug()

    VESSEL_REFERENCE = {
        'CONTAINER SHIP': {'L':220.,'B':32.2,'T':11.0,'H':28.0,'wind_shape':.85,'water_shape':.85,'cd_air':1.10,'cd_water':1.00},
        'BULK CARRIER': {'L':190.,'B':32.0,'T':11.2,'H':17.0,'wind_shape':.82,'water_shape':.88,'cd_air':1.05,'cd_water':1.00},
        'TANKER': {'L':185.,'B':32.2,'T':11.5,'H':14.0,'wind_shape':.78,'water_shape':.90,'cd_air':.90,'cd_water':1.00},
        'GENERAL CARGO': {'L':175.,'B':28.0,'T':10.0,'H':19.0,'wind_shape':.82,'water_shape':.86,'cd_air':1.05,'cd_water':1.00},
        'JACK-UP BARGE': {'L':150.,'B':50.0,'T':6.0,'H':35.0,'wind_shape':.88,'water_shape':.92,'cd_air':1.20,'cd_water':1.05},
        'TUG & BARGE': {'L':150.,'B':45.0,'T':6.5,'H':12.0,'wind_shape':.90,'water_shape':.92,'cd_air':1.10,'cd_water':1.05},
    }

    def _bollard_pull_assessment(self, displacement=50000., wind_gust=29.16, current=.97, tug_bp=50., safety=1.20, wind_area=None, underwater_area=None):
        typ=self.vessel.currentText(); d=self.VESSEL_REFERENCE[typ]
        rho_air=1.225; rho_sea=1025.0; g=9.80665
        aw=float(wind_area) if wind_area is not None else d['L']*d['H']*d['wind_shape']; ac=float(underwater_area) if underwater_area is not None else d['L']*d['T']*d['water_shape']
        # Displacement factor is deliberately mild: it represents handling reserve, not a false direct drag law.
        disp_factor=max(.75,min(1.45,(float(displacement)/50000.)**.18))
        wind_ms=float(wind_gust)*0.514444; current_ms=float(current)*0.514444
        fwind=.5*rho_air*d['cd_air']*aw*wind_ms**2/1000.0
        fcurrent=.5*rho_sea*d['cd_water']*ac*current_ms**2/1000.0
        required_kn=(fwind+fcurrent)*float(safety)*disp_factor; required_t=required_kn/g
        ntugs=self.canvas.active_tug_count; available=ntugs*float(tug_bp); margin=available-required_t
        return required_t,available,margin,fwind,fcurrent

    def show_pre_maneuver_assessment(self):
        dlg=QDialog(self); dlg.setWindowTitle('PRE-MANEUVER · STATIC / DYNAMIC BOLLARD PULL'); dlg.resize(620,520)
        lay=QVBoxLayout(dlg); h=QLabel('BOLLARD PULL REQUIREMENT · LIVE CALCULATOR'); h.setObjectName('pageTitle'); lay.addWidget(h)
        form=QGridLayout(); fields={}
        specs=[('Displacement t',50000,100,500000,100),('Wind kn',29.16,0,140,1.0),('Current kn',.97,0,16,.1),('Safety factor',1.2,1,3,.05),('Bollard pull / tug t',50,1,150,1),('Wind area m²',self.VESSEL_REFERENCE[self.vessel.currentText()]['L']*self.VESSEL_REFERENCE[self.vessel.currentText()]['H']*self.VESSEL_REFERENCE[self.vessel.currentText()]['wind_shape'],10,50000,10),('Underwater area m²',self.VESSEL_REFERENCE[self.vessel.currentText()]['L']*self.VESSEL_REFERENCE[self.vessel.currentText()]['T']*self.VESSEL_REFERENCE[self.vessel.currentText()]['water_shape'],10,20000,10)]
        for r,(name,val,lo,hi,step) in enumerate(specs):
            form.addWidget(QLabel(name),r,0); x=QDoubleSpinBox(); x.setRange(lo,hi); x.setDecimals(2); x.setSingleStep(step); x.setValue(val); fields[name]=x; form.addWidget(x,r,1)
        lay.addLayout(form); result=QLabel(); result.setWordWrap(True); result.setStyleSheet('font-weight:900;font-size:14px;padding:10px;border:1px solid #52717a;border-radius:6px;'); lay.addWidget(result)
        detail=QLabel(); detail.setWordWrap(True); lay.addWidget(detail)
        def calc():
            req,avail,margin,fw,fc=self._bollard_pull_assessment(fields['Displacement t'].value(),fields['Wind kn'].value(),fields['Current kn'].value(),fields['Bollard pull / tug t'].value(),fields['Safety factor'].value(),fields['Wind area m²'].value(),fields['Underwater area m²'].value())
            ok=margin>=0; result.setText(f"REQUIRED {req:.1f} t BP   ·   AVAILABLE {avail:.1f} t BP   ·   MARGIN {margin:+.1f} t\n"+('SUFFICIENT REFERENCE CAPACITY' if ok else 'WARNING · INSUFFICIENT REFERENCE CAPACITY'))
            result.setStyleSheet('font-weight:900;font-size:14px;padding:10px;border:2px solid '+('#45c77a' if ok else '#e65353')+';border-radius:6px;')
            detail.setText(f"Dynamic inputs: wind/current. Static/configuration inputs: vessel reference, displacement, tug count and tug BP. Wind force {fw:.1f} kN · Current force {fc:.1f} kN. Training estimate only; not an approved towage plan.")
        for x in fields.values(): x.valueChanged.connect(calc)
        calc(); row=QHBoxLayout(); close=QPushButton('CLOSE'); go=QPushButton('START MANEUVER'); row.addWidget(close); row.addWidget(go); lay.addLayout(row); close.clicked.connect(dlg.reject)
        def proceed(): self.canvas.start(); dlg.accept()
        go.clicked.connect(proceed); dlg.exec_()

    def cycle_sim_speed(self):
        n=(self.canvas.time_scale % 5)+1
        self.canvas.set_time_scale(n); self.sim_speed.setText(f'SIM ×{n}')

    def run_voice_order(self):
        if not self.voice_toggle.isChecked(): self.voice_reply.setText('VOICE: enable VOICE ORDERS first'); return
        ok,msg=self.canvas.execute_voice_order(self.voice_input.text()); self.voice_reply.setText(('ACK · ' if ok else 'CHECK · ')+msg); self.canvas.update()

    def set_tug_count(self,i):
        self.canvas.active_tug_count=i+1
        self.canvas._stage_tugs()
        if self.sel.currentIndex()>i: self.sel.setCurrentIndex(i)
        self.canvas.update()

    def sync_tug(self):
        i=self.sel.currentIndex(); t=self.canvas.tugs[i]
        self.point.blockSignals(True); self.point.setCurrentIndex(t['point']); self.point.blockSignals(False)
        self.action.blockSignals(True); self.action.setCurrentText(t['action']); self.action.blockSignals(False)
        allowed=self.canvas.allowed_clocks(t['point'])
        cur=12 if int(round((t['angle']%360)/30))%12==0 else int(round((t['angle']%360)/30))%12
        if cur not in allowed: cur=allowed[0]; t['angle']=(cur%12)*30
        self.ang.blockSignals(True); self.ang.setRange(0,max(0,len(allowed)-1)); self.ang.setValue(allowed.index(cur)); self.ang.blockSignals(False)
        self._refresh_levels(t['action'],t.get('level'))
        self.anglab.setText(f"{cur} O'CLOCK\n{(cur%12)*30:03d}°")
        self._refresh_state()

    def set_point(self,x):
        t=self.canvas.tugs[self.sel.currentIndex()]; t['point']=x
        allowed=self.canvas.allowed_clocks(x); cur=12 if int(round((t['angle']%360)/30))%12==0 else int(round((t['angle']%360)/30))%12
        if cur not in allowed: t['angle']=(allowed[0]%12)*30
        self.sync_tug(); self.canvas.update()

    def set_angle(self,x):
        t=self.canvas.tugs[self.sel.currentIndex()]; allowed=self.canvas.allowed_clocks(t['point'])
        if not allowed: return
        idx=max(0,min(int(x),len(allowed)-1)); clock=allowed[idx]; deg=(clock%12)*30; t['angle']=deg
        self.anglab.setText(f"{clock} O'CLOCK\n{deg:03d}°"); self.canvas.update(); self._refresh_state()

    def _refresh_levels(self,action,preferred=None):
        self.level.blockSignals(True); self.level.clear()
        if action=='PULL': items=list(ManeuverCanvas.PULL_LEVELS.keys())
        elif action=='PUSH': items=list(ManeuverCanvas.PUSH_LEVELS.keys())
        else: items=['NO FORCE']
        self.level.addItems(items)
        if preferred in items: self.level.setCurrentText(preferred)
        self.level.blockSignals(False)
        if action!='STOP / FOLLOW': self.canvas.tugs[self.sel.currentIndex()]['level']=self.level.currentText()

    def set_action(self,a):
        t=self.canvas.tugs[self.sel.currentIndex()]; t['action']=a
        self._refresh_levels(a,t.get('level')); self._refresh_state(); self.canvas.update()

    def set_level(self,x):
        if not x: return
        self.canvas.tugs[self.sel.currentIndex()]['level']=x; self._refresh_state()

    def _refresh_state(self):
        t=self.canvas.tugs[self.sel.currentIndex()]
        if t['action']=='STOP / FOLLOW': text='STOP / FOLLOW · tug keeps relative position and applies no force'
        else: text=f"{t['action']} · {t.get('level','')} · {self.anglab.text()}"
        self.state.setText(text)

class DoubleClickLabel(QLabel):
    doubleClicked = pyqtSignal()
    def mouseDoubleClickEvent(self, event):
        self.doubleClicked.emit()
        super().mouseDoubleClickEvent(event)

class ThrusterGauge(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.angle = 0
        self.rpm = 0
        self.setMinimumSize(130, 145)

    def set_values(self, angle, rpm):
        self.angle = float(angle) % 360
        self.rpm = int(rpm)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w/2, 66
        radius = min(w, 110)/2 - 8

        p.setPen(QPen(QColor("#4a8197"), 2))
        p.drawEllipse(int(cx-radius), int(cy-radius), int(radius*2), int(radius*2))

        p.setPen(QColor("#dcebf2"))
        f = QFont()
        f.setPointSize(9)
        f.setBold(True)
        p.setFont(f)
        p.drawText(0, 3, w, 18, Qt.AlignCenter, self.title)

        rad = math.radians(self.angle - 90)
        ex = cx + math.cos(rad) * (radius - 10)
        ey = cy + math.sin(rad) * (radius - 10)
        p.setPen(QPen(QColor("#dcebf2"), 6, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(int(cx), int(cy), int(ex), int(ey))
        p.setBrush(QColor("#dcebf2"))
        p.drawEllipse(int(cx-6), int(cy-6), 12, 12)

        p.setPen(QColor("#9fc3d2"))
        f.setPointSize(8)
        f.setBold(False)
        p.setFont(f)
        p.drawText(0, 118, w, 15, Qt.AlignCenter, f"{int(self.angle)}°")
        p.setPen(QColor("#ffffff"))
        f.setPointSize(10)
        f.setBold(True)
        p.setFont(f)
        p.drawText(0, 132, w, 15, Qt.AlignCenter, f"{self.rpm} RPM")

class BoatStatusWidget(QFrame):
    logRequested = pyqtSignal(str)
    stopLogRequested = pyqtSignal(str)

    def __init__(self, boat_id, name, parent=None):
        super().__init__(parent)
        self.boat_id = boat_id
        self.name = name
        self.recording = False
        self.setObjectName("panel")

        layout = QVBoxLayout(self)
        title = QLabel(name)
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        metrics = QHBoxLayout()
        self.heading = QLabel("HEADING\n0°")
        self.battery = QLabel("BATTERY\n--%")
        self.link = QLabel("LINK\n--%")
        for x in (self.heading, self.battery, self.link):
            x.setAlignment(Qt.AlignCenter)
            x.setObjectName("metric")
            metrics.addWidget(x)
        layout.addLayout(metrics)

        thr = QHBoxLayout()
        self.port = ThrusterGauge("PORT AZIMUTH")
        self.stbd = ThrusterGauge("STBD AZIMUTH")
        thr.addWidget(self.port)
        thr.addWidget(self.stbd)
        layout.addLayout(thr)

        self.log_button = QPushButton(f"LOG MANEUVER · {name}")
        self.log_button.clicked.connect(self.toggle_log)
        layout.addWidget(self.log_button)

    def toggle_log(self):
        if not self.recording:
            self.logRequested.emit(self.boat_id)
        else:
            self.stopLogRequested.emit(self.boat_id)

    def set_recording(self, on):
        self.recording = on
        if on:
            self.log_button.setText(f"STOP LOG · {self.name}")
            self.log_button.setObjectName("recordButton")
        else:
            self.log_button.setText(f"LOG MANEUVER · {self.name}")
            self.log_button.setObjectName("")
        self.log_button.style().unpolish(self.log_button)
        self.log_button.style().polish(self.log_button)

    def set_values(self, boat):
        self.heading.setText(f"HEADING\n{int(boat['heading'])}°")
        self.battery.setText(f"BATTERY\n{boat['battery']}%")
        self.link.setText(f"LINK\n{boat['link']}%")
        self.port.set_values(boat["port_angle"], boat["port_rpm"])
        self.stbd.set_values(boat["stbd_angle"], boat["stbd_rpm"])

class CameraPanel(DoubleClickLabel):
    def __init__(self, boat_name, parent=None):
        super().__init__(parent)
        self.boat_name = boat_name
        self.setAlignment(Qt.AlignCenter)
        self.setObjectName("camera")
        self.setText(f"{boat_name} · LIVE CAMERA\nDOUBLE CLICK")
        self.setMinimumHeight(180)

class OpenCPNEmbedWidget(QFrame):
    embedded = pyqtSignal(bool)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("mapPanel")
        self.main_layout = QVBoxLayout(self)
        head = QHBoxLayout()
        title = QLabel("OPENCPN · LIVE MARINE CHART")
        title.setObjectName("sectionTitle")
        head.addWidget(title)
        head.addStretch()
        self.status = QLabel("NOT EMBEDDED")
        self.status.setObjectName("smallStatus")
        head.addWidget(self.status)
        self.main_layout.addLayout(head)

        self.placeholder = QLabel(
            "OpenCPN will appear inside this DR.BOAT panel.\n"
            "Press EMBED OPENCPN once after DR.BOAT starts."
        )
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.placeholder.setObjectName("mapPlaceholder")
        self.main_layout.addWidget(self.placeholder, 1)

        self.button = QPushButton("EMBED OPENCPN")
        self.button.clicked.connect(self.start_embed)
        self.main_layout.addWidget(self.button)

        self.foreign_window = None
        self.container = None
        self.process = None
        self.try_count = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.try_embed)

    def start_embed(self):
        if self.container is not None:
            return
        if not shutil.which("opencpn"):
            QMessageBox.warning(self, "OpenCPN", "OpenCPN is not installed on this Raspberry Pi.")
            return
        if not shutil.which("xdotool"):
            QMessageBox.warning(self, "OpenCPN", "xdotool is not installed. Run the V3 installer again.")
            return
        free = mem_available_mb()
        if free is not None and free < 260:
            r = QMessageBox.question(
                self, "Low memory",
                f"Only {free} MB RAM is available. OpenCPN may be heavy on Raspberry Pi 3.\nOpen it anyway?",
                QMessageBox.Yes | QMessageBox.No
            )
            if r != QMessageBox.Yes:
                return
        self.status.setText("STARTING...")
        try:
            # Reuse an existing OpenCPN window when possible.
            ids = self.find_windows()
            if not ids:
                self.process = subprocess.Popen(
                    ["opencpn"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            self.try_count = 0
            self.timer.start(700)
        except Exception as e:
            QMessageBox.critical(self, "OpenCPN", str(e))

    def find_windows(self):
        try:
            out = subprocess.check_output(
                ["xdotool", "search", "--onlyvisible", "--name", "OpenCPN"],
                stderr=subprocess.DEVNULL,
                text=True
            )
            return [x.strip() for x in out.splitlines() if x.strip().isdigit()]
        except Exception:
            return []

    def try_embed(self):
        self.try_count += 1
        ids = self.find_windows()
        if ids:
            self.timer.stop()
            try:
                wid = int(ids[-1])
                self.foreign_window = QWindow.fromWinId(wid)
                self.container = QWidget.createWindowContainer(self.foreign_window, self)
                self.container.setMinimumSize(420, 320)
                self.main_layout.insertWidget(1, self.container, 1)
                self.placeholder.hide()
                self.button.hide()
                self.status.setText("EMBEDDED")
                self.embedded.emit(True)
                return
            except Exception as e:
                self.status.setText("EMBED FAILED")
                QMessageBox.warning(self, "OpenCPN", f"Could not embed OpenCPN window:\n{e}")
                return
        if self.try_count > 25:
            self.timer.stop()
            self.status.setText("NOT FOUND")
            QMessageBox.warning(self, "OpenCPN", "OpenCPN started, but its X11 window could not be embedded.")

    def move_container_to(self, target_layout):
        if self.container is None:
            return False
        self.container.setParent(None)
        target_layout.addWidget(self.container, 1)
        return True

    def restore_container(self):
        if self.container is None:
            return
        self.container.setParent(None)
        self.main_layout.insertWidget(1, self.container, 1)

class LidarPlanView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.scan=0.; self.setMinimumHeight(230)
        self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(60)
    def tick(self): self.scan=(self.scan+4)%360; self.update()
    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height(); p.fillRect(self.rect(),QColor('#020b10'))
        # quay on starboard side
        p.setPen(Qt.NoPen); p.setBrush(QColor('#596a70')); p.drawRect(int(w*.78),0,int(w*.22),h)
        p.setPen(QPen(QColor('#9db5bd'),3)); p.drawLine(int(w*.78),0,int(w*.78),h)
        cx,cy=w*.48,h*.52; R=min(w,h)*.38
        for f in (.25,.5,.75,1.): p.setPen(QPen(QColor('#174958'),1)); p.setBrush(Qt.NoBrush); p.drawEllipse(QPointF(cx,cy),R*f,R*f)
        # top-view conventional boat
        from PyQt5.QtGui import QPolygonF
        p.setBrush(QColor('#d4aa3e')); p.setPen(QPen(QColor('#eaf7fb'),1.2)); p.drawPolygon(QPolygonF([QPointF(cx,cy-R*.48),QPointF(cx+18,cy-R*.28),QPointF(cx+18,cy+R*.35),QPointF(cx-18,cy+R*.35),QPointF(cx-18,cy-R*.28)]))
        p.setBrush(QColor('#dcebf2')); p.drawRect(QRectF(cx-10,cy-8,20,24))
        # rotating lidar beam
        a=math.radians(self.scan-90); ex=cx+math.cos(a)*R; ey=cy+math.sin(a)*R; p.setPen(QPen(QColor('#55e9ff'),2)); p.drawLine(QPointF(cx,cy),QPointF(ex,ey))
        p.setPen(QColor('#63e7ff')); p.drawText(10,20,'360° LIDAR LIVE PLAN VIEW'); p.drawText(10,h-12,'JAWAD 1 · QUAY DETECTION · SIMULATED SCAN')

class FocusDialog(QDialog):
    def __init__(self, main_window, boat_index):
        super().__init__(main_window)

        from PyQt5.QtWidgets import (
            QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
            QGridLayout, QGroupBox, QSlider, QDial, QFrame
        )
        from PyQt5.QtCore import Qt

        self.main_window = main_window
        self.boat_index = boat_index
        boat = main_window.boats[boat_index]
        boat_name = boat["name"]

        self.setWindowTitle(
            "DOCTOR BOAT CONTROL MARINE INTELLIGENCE · " + boat_name
        )
        self.resize(1100,650)
        self.setMinimumSize(720,480)

        self.setStyleSheet("""
            QDialog {
                background:#07131f;
                color:#e8f4ff;
            }
            QGroupBox {
                border:1px solid #284c66;
                border-radius:10px;
                margin-top:14px;
                padding:10px;
                font-weight:700;
                color:#7fd9ff;
                background:#0b1c2b;
            }
            QGroupBox::title {
                subcontrol-origin:margin;
                left:12px;
                padding:0 6px;
            }
            QLabel {
                color:#dbeeff;
            }
            QPushButton {
                min-height:32px;
                border-radius:7px;
                border:1px solid #35617e;
                padding:4px 10px;
                background:#123047;
                color:white;
                font-weight:700;
            }
            QPushButton:hover {
                background:#194461;
            }
            QPushButton:pressed {
                background:#07131f;
            }
            QSlider::groove:horizontal {
                height:8px;
                background:#17384f;
                border-radius:4px;
            }
            QSlider::handle:horizontal {
                width:18px;
                margin:-6px 0;
                background:#58cfff;
                border-radius:9px;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 10)
        root.setSpacing(8)

        # ===== TOP BAR =====
        top = QHBoxLayout()

        title = QLabel("DOCTOR BOAT CONTROL · MARINE INTELLIGENCE")
        title.setStyleSheet(
            "font-size:20px;font-weight:900;color:#7fd9ff;"
        )
        top.addWidget(title)

        vessel = QLabel("VESSEL: " + boat_name.upper())
        vessel.setStyleSheet(
            "font-size:15px;font-weight:800;color:white;"
        )
        top.addWidget(vessel)

        top.addStretch()

        self.connection_btn = QPushButton("● CONNECTIONS")
        self.connection_btn.clicked.connect(self.show_connections)
        top.addWidget(self.connection_btn)

        close = QPushButton("BACK TO COMMAND CENTER")
        close.clicked.connect(self.close)
        top.addWidget(close)

        root.addLayout(top)

        # ===== MAIN GRID =====
        grid = QGridLayout()
        grid.setSpacing(8)

        # ---------- OPENCPN MAP ----------
        map_frame = QGroupBox("OPENCPN · LIVE NAVIGATION")
        self.map_host = QVBoxLayout(map_frame)
        self.map_host.setContentsMargins(5, 12, 5, 5)

        map_title = QLabel(
            "LIVE CHART · GNSS POSITION · HEADING · TRACK"
        )
        map_title.setAlignment(Qt.AlignCenter)
        map_title.setStyleSheet(
            "font-size:11px;color:#80dfff;"
        )
        self.map_host.addWidget(map_title)

        grid.addWidget(map_frame, 0, 0, 1, 2)

        # ---------- CAMERA ----------
        camera = QGroupBox("LIVE CAMERA · JAWAD 1")
        camera_l = QVBoxLayout(camera)

        cam_screen = QLabel(
            "LIVE VIDEO\n\nCAMERA FEED READY"
        )
        cam_screen.setAlignment(Qt.AlignCenter)
        cam_screen.setMinimumHeight(190)
        cam_screen.setStyleSheet("""
            background:#02070c;
            border:1px solid #31536a;
            border-radius:8px;
            font-size:18px;
            font-weight:800;
            color:#7894a5;
        """)
        camera_l.addWidget(cam_screen)

        grid.addWidget(camera, 0, 2, 1, 2)

        # ---------- LIDAR / PLAN VIEW ----------
        lidar = QGroupBox("360° LIDAR · PLAN VIEW · LINE STATUS")
        lidar_l = QVBoxLayout(lidar)
        lidar_screen = LidarPlanView()
        lidar_l.addWidget(lidar_screen)

        line_grid = QGridLayout()

        let_fwd = QPushButton("LET GO FORWARD LINE")
        secure_fwd = QPushButton("SECURE FORWARD LINE")
        let_aft = QPushButton("LET GO AFT LINE")
        secure_aft = QPushButton("SECURE AFT LINE")

        let_fwd.clicked.connect(
            lambda: self.line_action("FORWARD", "RELEASED")
        )
        secure_fwd.clicked.connect(
            lambda: self.line_action("FORWARD", "SECURED")
        )
        let_aft.clicked.connect(
            lambda: self.line_action("AFT", "RELEASED")
        )
        secure_aft.clicked.connect(
            lambda: self.line_action("AFT", "SECURED")
        )

        line_grid.addWidget(let_fwd, 0, 0)
        line_grid.addWidget(secure_fwd, 0, 1)
        line_grid.addWidget(let_aft, 1, 0)
        line_grid.addWidget(secure_aft, 1, 1)

        self.line_status = QLabel(
            "FORWARD: SECURED     |     AFT: SECURED"
        )
        self.line_status.setAlignment(Qt.AlignCenter)

        lidar_l.addLayout(line_grid)
        lidar_l.addWidget(self.line_status)

        grid.addWidget(lidar, 1, 0)

        # ---------- FIREFIGHTING ----------
        firefighting = QGroupBox("FIREFIGHTING CONTROL")
        fire_l = QVBoxLayout(firefighting)

        pump_row = QHBoxLayout()
        pump_on = QPushButton("FIFI PUMP ON")
        pump_off = QPushButton("FIFI PUMP OFF")

        self.pump_status = QLabel("PUMP: OFF")
        self.pump_status.setAlignment(Qt.AlignCenter)

        pump_on.clicked.connect(
            lambda: self.pump_status.setText("PUMP: ON")
        )
        pump_off.clicked.connect(
            lambda: self.pump_status.setText("PUMP: OFF")
        )

        pump_row.addWidget(pump_on)
        pump_row.addWidget(pump_off)
        fire_l.addLayout(pump_row)
        fire_l.addWidget(self.pump_status)

        fire_label = QLabel("FIRE MONITOR AZIMUTH · 360°")
        fire_label.setAlignment(Qt.AlignCenter)
        fire_l.addWidget(fire_label)

        self.fire_dial = QDial()
        self.fire_dial.setRange(0, 359)
        self.fire_dial.setWrapping(True)
        self.fire_dial.setNotchesVisible(True)

        self.fire_angle = QLabel("MONITOR: 000°")
        self.fire_angle.setAlignment(Qt.AlignCenter)

        self.fire_dial.valueChanged.connect(
            lambda v: self.fire_angle.setText(
                "MONITOR: %03d°" % v
            )
        )

        fire_l.addWidget(self.fire_dial)
        fire_l.addWidget(self.fire_angle)

        grid.addWidget(firefighting, 1, 1)

        # ---------- RUDDER ----------
        steering = QGroupBox("HYDRAULIC STEERING · RUDDER")
        steer_l = QVBoxLayout(steering)

        self.rudder_value = QLabel("MIDSHIP · 0°")
        self.rudder_value.setAlignment(Qt.AlignCenter)
        self.rudder_value.setStyleSheet(
            "font-size:19px;font-weight:900;color:#7fd9ff;"
        )

        self.rudder = QSlider(Qt.Horizontal)
        self.rudder.setRange(-30, 30)
        self.rudder.setValue(0)
        self.rudder.setTickInterval(5)
        self.rudder.setTickPosition(QSlider.TicksBelow)
        self.rudder.valueChanged.connect(self.update_rudder)

        rudder_labels = QHBoxLayout()
        rudder_labels.addWidget(QLabel("PORT 30°"))
        rudder_labels.addStretch()
        rudder_labels.addWidget(QLabel("MIDSHIP"))
        rudder_labels.addStretch()
        rudder_labels.addWidget(QLabel("30° STARBOARD"))

        steer_l.addWidget(self.rudder_value)
        steer_l.addWidget(self.rudder)
        steer_l.addLayout(rudder_labels)

        grid.addWidget(steering, 1, 2)

        # ---------- TWIN ENGINE LEVERS ----------
        propulsion = QGroupBox("TWIN DIGITAL ENGINE CONTROL · PORT / STARBOARD")
        prop_l = QHBoxLayout(propulsion)
        self.engine_levers=[]; self.engine_states=[]
        for eng in ("PORT ENGINE", "STARBOARD ENGINE"):
            col=QVBoxLayout(); lab=QLabel(eng); lab.setAlignment(Qt.AlignCenter); lab.setStyleSheet("font-weight:900;color:#7fd9ff;"); col.addWidget(lab)
            col.addWidget(QLabel("AHEAD +100%"))
            lever=QSlider(Qt.Vertical); lever.setRange(-100,100); lever.setValue(0); lever.setTickInterval(10); lever.setTickPosition(QSlider.TicksBothSides)
            state=QLabel("NEUTRAL · 0%"); state.setAlignment(Qt.AlignCenter); state.setStyleSheet("font-size:13px;font-weight:900;color:#7fd9ff;")
            lever.valueChanged.connect(lambda v, st=state: self.update_engine_state_label(st,v))
            col.addWidget(lever,1); col.addWidget(QLabel("ASTERN -100%")); col.addWidget(state)
            self.engine_levers.append(lever); self.engine_states.append(state); prop_l.addLayout(col)
        grid.addWidget(propulsion, 1, 3)

        # ---------- MACHINERY / DATA ----------
        data = QGroupBox("VESSEL DATA · MACHINERY")
        data_l = QGridLayout(data)

        rows = [
            ("LATITUDE", "—"),
            ("LONGITUDE", "—"),
            ("HEADING · KVH", "—"),
            ("GNSS", "CONNECTED"),
            ("ENGINE 1 RPM", "0"),
            ("ENGINE 1 HOURS", "0.0 h"),
            ("ENGINE 1 CONSUMPTION", "0.0 L/h"),
            ("ENGINE 2 RPM", "0"),
            ("ENGINE 2 HOURS", "0.0 h"),
            ("ENGINE 2 CONSUMPTION", "0.0 L/h"),
        ]

        for r, (name, value) in enumerate(rows):
            a = QLabel(name)
            b = QLabel(value)
            b.setStyleSheet(
                "font-weight:800;color:#75e6a5;"
            )
            data_l.addWidget(a, r, 0)
            data_l.addWidget(b, r, 1)

        grid.addWidget(data, 2, 0, 1, 2)

        # ---------- EXISTING STATUS ----------
        self.status_widget = BoatStatusWidget(
            boat["id"],
            boat["name"]
        )
        self.status_widget.logRequested.connect(
            main_window.start_log
        )
        self.status_widget.stopLogRequested.connect(
            main_window.stop_log
        )
        self.status_widget.set_values(boat)
        self.status_widget.set_recording(
            boat["id"] in main_window.recording
        )
        if boat.get("id") == "JAWAD_1":
            self.status_widget.port.hide(); self.status_widget.stbd.hide()
            self.status_widget.heading.setText("HEADING\n0°")
            self.status_widget.log_button.setText("LOG JAWAD 1 MANEUVER")

        status_box = QGroupBox("LIVE TELEMETRY · SYSTEM")
        status_l = QVBoxLayout(status_box)
        status_l.addWidget(self.status_widget)

        grid.addWidget(status_box, 2, 2, 1, 2)

        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)
        grid.setColumnStretch(2, 2)
        grid.setColumnStretch(3, 1)

        grid.setRowStretch(0, 3)
        grid.setRowStretch(1, 4)
        grid.setRowStretch(2, 2)

        root.addLayout(grid, 1)

        # Move the existing embedded OpenCPN window into this page.
        self.moved_map = main_window.map_widget.move_container_to(
            self.map_host
        )

    def update_rudder(self, value):
        if value < 0:
            self.rudder_value.setText(
                "PORT · %d°" % abs(value)
            )
        elif value > 0:
            self.rudder_value.setText(
                "STARBOARD · %d°" % value
            )
        else:
            self.rudder_value.setText("MIDSHIP · 0°")

    def update_engine_state_label(self, label, value):
        if -4 <= value <= 4: label.setText("NEUTRAL · 0%"); return
        label.setText(("AHEAD" if value>0 else "ASTERN") + " · %d%%" % abs(value))

    def update_engine_lever(self, value):
        if hasattr(self, "engine_states") and self.engine_states:
            self.update_engine_state_label(self.engine_states[0], value)

    def line_action(self, line_name, state):
        current = self.line_status.text()

        if line_name == "FORWARD":
            aft = (
                "RELEASED"
                if "AFT: RELEASED" in current
                else "SECURED"
            )
            current = (
                "FORWARD: %s     |     AFT: %s"
                % (state, aft)
            )
        else:
            forward = (
                "RELEASED"
                if "FORWARD: RELEASED" in current
                else "SECURED"
            )
            current = (
                "FORWARD: %s     |     AFT: %s"
                % (forward, state)
            )

        self.line_status.setText(current)

    def show_connections(self):
        from PyQt5.QtWidgets import QMessageBox

        QMessageBox.information(
            self,
            "Connections · System Status",
            "● KVH HEADING            CONNECTED\n"
            "● GNSS                   CONNECTED\n"
            "● ENGINE CONTROL         STANDBY\n"
            "● HYDRAULIC STEERING     STANDBY\n"
            "● FIFI MONITOR CONTROL   STANDBY\n"
            "● FIFI PUMP CONTROL      STANDBY\n"
            "● LINE RELEASE 1         STANDBY\n"
            "● LINE RELEASE 2         STANDBY\n"
            "● LIDAR 360°             STANDBY\n"
            "● CAMERA                  STANDBY\n"
            "● 4G / 5G MODEM          STANDBY\n"
            "● SIGNAL K               CONNECTED\n"
            "● DR BOAT MAP ENGINE      CONNECTED"
        )

    def closeEvent(self, event):
        if self.moved_map:
            self.main_window.map_widget.restore_container()
        super().closeEvent(event)


class CommandCenter(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent); self.main_window=main_window; self.selected_ids=[]
        root=QVBoxLayout(self)
        head=QHBoxLayout(); title=QLabel('AI COMMAND CENTER · OPERATOR CONSOLE'); title.setObjectName('pageTitle'); head.addWidget(title); head.addStretch()
        self.cc_layer_combo=QComboBox(); self.cc_layer_combo.addItems(['VECTOR','SATELLITE','HYBRID','MARINE']); self.cc_layer_combo.setMaximumWidth(130); head.addWidget(self.cc_layer_combo)
        sel=QPushButton('SELECT UNITS'); sel.clicked.connect(self.select_units); head.addWidget(sel); root.addLayout(head)
        self.map_widget=UTMMapCanvas(); self.map_widget.setMinimumHeight(300); self.map_widget.load_world_basemap(reset_view=True); self.map_widget.set_map_layer('HYBRID'); self.cc_layer_combo.setCurrentText('HYBRID'); self.cc_layer_combo.currentTextChanged.connect(self.map_widget.set_map_layer); root.addWidget(self.map_widget,3)
        self.units_host=QWidget(); self.units_layout=QGridLayout(self.units_host); root.addWidget(self.units_host,2)
        ai=QFrame(); ai.setObjectName('panel'); al=QHBoxLayout(ai); al.addWidget(QLabel('AI / VOICE CONSOLE')); self.voice=QLineEdit(); self.voice.setPlaceholderText('Voice / mission command'); al.addWidget(self.voice,1); send=QPushButton('SEND / SIMULATE VOICE'); send.clicked.connect(main_window.set_voice); al.addWidget(send); root.addWidget(ai)
        self.cards={}; self.rebuild_units()
    def select_units(self):
        d=QDialog(self); d.setWindowTitle('SELECT COMMAND CENTER UNITS'); d.resize(460,520); l=QVBoxLayout(d); l.addWidget(QLabel('Select up to four fleet units to display in Command Center'))
        q=QListWidget(); q.setSelectionMode(QAbstractItemView.MultiSelection)
        for v in FleetPage.VESSELS:
            it=QListWidgetItem(v['name']); it.setData(Qt.UserRole,v['id']); q.addItem(it); it.setSelected(v['id'] in self.selected_ids)
        l.addWidget(q,1); row=QHBoxLayout(); ok=QPushButton('APPLY'); cancel=QPushButton('CANCEL'); row.addWidget(ok); row.addWidget(cancel); l.addLayout(row)
        ok.clicked.connect(d.accept); cancel.clicked.connect(d.reject)
        if d.exec_()==QDialog.Accepted:
            ids=[it.data(Qt.UserRole) for it in q.selectedItems()][:4]
            self.selected_ids=ids; self.main_window.ensure_boats(self.selected_ids); self.rebuild_units()
    def rebuild_units(self):
        while self.units_layout.count():
            it=self.units_layout.takeAt(0); w=it.widget();
            if w: w.deleteLater()
        self.cards={}
        for i,bid in enumerate(self.selected_ids):
            boat=self.main_window.boat_by_id(bid)
            if not boat: continue
            panel=QFrame(); panel.setObjectName('panel'); v=QVBoxLayout(panel); top=QHBoxLayout(); name=QLabel(boat['name']); name.setObjectName('sectionTitle'); top.addWidget(name); top.addStretch()
            ptt=QPushButton('🎙 PUSH TO TALK'); ptt.setToolTip('Operator-to-vessel voice channel placeholder'); ptt.pressed.connect(lambda b=boat: self.ptt(b,True)); ptt.released.connect(lambda b=boat: self.ptt(b,False)); top.addWidget(ptt); v.addLayout(top)
            cam=CameraPanel(boat['name']); cam.setMinimumHeight(120); cam.doubleClicked.connect(lambda bid=bid:self.main_window.open_focus_by_id(bid)); v.addWidget(cam)
            status=BoatStatusWidget(boat['id'],boat['name']); status.setMaximumHeight(260); status.logRequested.connect(self.main_window.start_log); status.stopLogRequested.connect(self.main_window.stop_log)
            if boat.get('type')=='CONVENTIONAL': status.port.hide(); status.stbd.hide()
            status.set_values(boat); v.addWidget(status); self.cards[bid]=status
            self.units_layout.addWidget(panel,i//2,i%2)
    def ptt(self,boat,on):
        self.main_window.voice_text=(f"PTT ACTIVE · {boat['name']}" if on else 'Awaiting command')
    def refresh(self):
        for bid,w in list(self.cards.items()):
            b=self.main_window.boat_by_id(bid)
            if b: w.set_values(b); w.set_recording(bid in self.main_window.recording)
        # Command Center uses the same DR BOAT navigation engine instead of embedded OpenCPN.
        if hasattr(self.main_window,'positioning'):
            src=self.main_window.positioning.canvas; dst=self.map_widget
            dst.vessel_lat=src.vessel_lat; dst.vessel_lon=src.vessel_lon; dst.easting=src.easting; dst.northing=src.northing; dst.zone=src.zone; dst.hemisphere=src.hemisphere; dst.heading=src.heading; dst.course=src.course; dst.speed=src.speed; dst.gnss_live=src.gnss_live; dst.position_source=src.position_source
            dst.ais_targets=dict(src.ais_targets); dst.fleet_targets=dict(src.fleet_targets); dst.marine_marks=list(src.marine_marks); dst.route=list(src.route); dst.track=list(src.track); dst.show_track=src.show_track
            if dst.follow_vessel: dst.world_center_lon=dst.vessel_lon; dst.world_center_lat=dst.vessel_lat
            dst.update()

class LibraryPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QHBoxLayout(self)
        left = QVBoxLayout()
        title = QLabel("AI TRAINING & MANEUVER LIBRARY")
        title.setObjectName("pageTitle")
        left.addWidget(title)
        self.list = QListWidget()
        self.list.itemDoubleClicked.connect(self.open_item)
        left.addWidget(self.list)
        refresh = QPushButton("REFRESH LIBRARY")
        refresh.clicked.connect(self.reload)
        left.addWidget(refresh)
        lw = QWidget(); lw.setLayout(left)
        root.addWidget(lw, 1)
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        root.addWidget(self.detail, 2)
        self.reload()

    def reload(self):
        self.list.clear()
        for f in sorted(MISSIONS_DIR.glob("*.jsonl"), key=lambda x: x.stat().st_mtime, reverse=True):
            self.list.addItem(QListWidgetItem(f.stem))

    def open_item(self, item):
        f = MISSIONS_DIR / (item.text()+".jsonl")
        rows = []
        try:
            lines = f.read_text(encoding="utf-8").splitlines()
            for line in lines[-120:]:
                if not line.strip(): continue
                r = json.loads(line)
                b = r.get("boat", {})
                rows.append(
                    f"{r.get('time','')} | {b.get('name','')} | "
                    f"HDG {int(b.get('heading',0))}° | "
                    f"PORT {b.get('port_angle',0)}° / {b.get('port_rpm',0)} RPM | "
                    f"STBD {b.get('stbd_angle',0)}° / {b.get('stbd_rpm',0)} RPM"
                )
            self.detail.setPlainText("\n".join(rows) or "No samples.")
        except Exception as e:
            self.detail.setPlainText(str(e))

class TrainingPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root=QVBoxLayout(self); root.setContentsMargins(26,22,26,22); root.setSpacing(14)
        title=QLabel(f'PILOT & TUG MASTER TRAINING · V{APP_VERSION}'); title.setObjectName('pageTitle'); root.addWidget(title)
        card=QFrame(); card.setObjectName('panel'); form=QGridLayout(card); form.setContentsMargins(22,20,22,20); form.setHorizontalSpacing(18); form.setVerticalSpacing(12)
        form.addWidget(QLabel('TRAINING PORT'),0,0); self.port=QComboBox(); self.port.addItems(['MINA ZAYED']); form.addWidget(self.port,0,1)
        form.addWidget(QLabel('TARGET VESSEL / UNIT'),1,0); self.vessel=QComboBox(); self.vessel.addItems(['CONTAINER SHIP','BULK CARRIER','TANKER','GENERAL CARGO','JACK-UP BARGE','TUG & BARGE']); form.addWidget(self.vessel,1,1)
        form.addWidget(QLabel('NUMBER OF TUGS'),2,0); self.tugs=QComboBox(); self.tugs.addItems(['1 TUG','2 TUGS','3 TUGS','4 TUGS']); self.tugs.setCurrentIndex(3); form.addWidget(self.tugs,2,1)
        launch=QPushButton('START MANEUVER'); launch.setMinimumHeight(58); launch.clicked.connect(self.open_sim); form.addWidget(launch,3,0,1,2)
        root.addWidget(card); root.addStretch()
    def open_sim(self):
        d=SimulatorDialog(self); d.vessel.setCurrentText(self.vessel.currentText()); d.set_tug_count(self.tugs.currentIndex()); d.tug_count.setCurrentIndex(self.tugs.currentIndex()); d.exec_()

class PropulsionPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        title = QLabel("PROPULSION MANAGER")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        grid = QGridLayout()
        for i,(t,d) in enumerate([
            ("TWIN AZIMUTH", "360° Port + Starboard ASD"),
            ("TWIN SCREW", "Port + Starboard engine / rudder"),
            ("SINGLE SCREW", "Engine + conventional rudder"),
        ]):
            box=QFrame(); box.setObjectName("panel")
            l=QVBoxLayout(box)
            q=QLabel(t); q.setObjectName("sectionTitle")
            l.addWidget(q); l.addWidget(QLabel(d)); l.addStretch()
            grid.addWidget(box,0,i)
        root.addLayout(grid)
        mode = QFrame(); mode.setObjectName("panel")
        ml=QHBoxLayout(mode)
        ml.addWidget(QLabel("CONTROL MODE"))
        self.combo=QComboBox()
        self.combo.addItems(["MANUAL", "ASSISTED", "AUTONOMOUS"])
        ml.addWidget(self.combo)
        ml.addStretch()
        root.addWidget(mode)
        root.addStretch()

class SystemPage(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.manifest = None
        root = QVBoxLayout(self)
        title = QLabel("SYSTEM / UPDATES")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        info = QFrame(); info.setObjectName("panel")
        il=QVBoxLayout(info)
        self.version = QLabel(f"Installed: V{APP_VERSION} · Raspberry Pi 3")
        self.version.setObjectName("sectionTitle")
        il.addWidget(self.version)
        btns=QHBoxLayout()
        health=QPushButton("SYSTEM HEALTH"); health.clicked.connect(self.check_health)
        upd=QPushButton("CHECK FOR UPDATES"); upd.clicked.connect(self.check_updates)
        self.install=QPushButton("DOWNLOAD & INSTALL UPDATE"); self.install.setEnabled(False); self.install.clicked.connect(self.install_update)
        for b in (health,upd,self.install): btns.addWidget(b)
        il.addLayout(btns)
        self.output=QTextEdit(); self.output.setReadOnly(True); self.output.setMinimumHeight(220)
        il.addWidget(self.output)
        root.addWidget(info)
        root.addStretch()

    def check_health(self):
        disk = shutil.disk_usage(str(Path.home()))
        self.output.setPlainText(
            f"DR.BOAT V{APP_VERSION}\n"
            f"CPU temperature: {cpu_temp_c() if cpu_temp_c() is not None else 'N/A'} °C\n"
            f"Available RAM: {mem_available_mb() if mem_available_mb() is not None else 'N/A'} MB\n"
            f"Free disk: {disk.free//(1024**3)} GB\n"
            f"DR BOAT map engine: BUILT-IN\n"
            f"xdotool: {'INSTALLED' if shutil.which('xdotool') else 'NOT INSTALLED'}\n"
            f"Update manifest: {UPDATE_MANIFEST}"
        )

    def check_updates(self):
        self.output.setPlainText("Checking GitHub update server over HTTPS...")
        QApplication.processEvents()
        try:
            req = urllib.request.Request(UPDATE_MANIFEST, headers={"User-Agent":"DRBOAT-V3"})
            with urllib.request.urlopen(req, timeout=12) as r:
                manifest = json.loads(r.read().decode("utf-8"))
            self.manifest = manifest
            latest = manifest.get("version","0.0.0")
            notes = manifest.get("notes","")
            if isinstance(notes, list): notes = "\n".join("• "+str(x) for x in notes)
            text = (
                f"Current version: {APP_VERSION}\n"
                f"Latest version: {latest}\n"
                f"Server: CONNECTED (HTTPS)\n\n"
                f"Release notes:\n{notes}"
            )
            if version_tuple(latest) > version_tuple(APP_VERSION):
                text += "\n\nUPDATE AVAILABLE."
                self.install.setEnabled(True)
            else:
                text += "\n\nYou are up to date."
                self.install.setEnabled(False)
            self.output.setPlainText(text)
        except Exception as e:
            self.install.setEnabled(False)
            self.output.setPlainText(
                "Update server is not ready yet.\n\n"
                "V3 is already configured to read:\n"
                f"{UPDATE_MANIFEST}\n\n"
                f"Error: {e}\n\n"
                "Upload version.json to your GitHub repository to activate future online updates."
            )

    def install_update(self):
        if not self.manifest:
            return
        url = self.manifest.get("package_url")
        want_sha = self.manifest.get("sha256","").lower()
        if not url:
            QMessageBox.warning(self, "Update", "package_url is missing from version.json")
            return
        if QMessageBox.question(
            self, "Install update",
            "DR.BOAT will download the update, verify it, back up the current version, then restart.\nContinue?",
            QMessageBox.Yes | QMessageBox.No
        ) != QMessageBox.Yes:
            return
        try:
            tmpdir = Path(tempfile.mkdtemp(prefix="drboat-update-"))
            zpath = tmpdir / "update.zip"
            self.output.setPlainText("Downloading update...")
            QApplication.processEvents()
            req = urllib.request.Request(url, headers={"User-Agent":"DRBOAT-V3"})
            with urllib.request.urlopen(req, timeout=60) as r, zpath.open("wb") as f:
                while True:
                    chunk = r.read(1024*128)
                    if not chunk: break
                    f.write(chunk)
            got_sha = hashlib.sha256(zpath.read_bytes()).hexdigest()
            if want_sha and got_sha != want_sha:
                raise RuntimeError(f"SHA256 mismatch.\nExpected: {want_sha}\nReceived: {got_sha}")
            extract = tmpdir / "extract"
            extract.mkdir()
            with zipfile.ZipFile(zpath) as z:
                z.extractall(extract)
            dirs = [p for p in extract.iterdir() if p.is_dir()]
            if not dirs:
                raise RuntimeError("Update package has no application directory.")
            src = dirs[0]
            helper = tmpdir / "apply_update.sh"
            appdir = APP_DIR
            backup = APP_DIR.parent / (APP_DIR.name + ".backup")
            launcher = Path.home()/".local/bin/drboat"
            helper.write_text(f"""#!/bin/bash
set -e
sleep 2
rm -rf "{backup}"
mv "{appdir}" "{backup}"
mkdir -p "{appdir}"
cp -a "{src}/." "{appdir}/"
if [ -d "{backup}/data" ]; then
  rm -rf "{appdir}/data"
  cp -a "{backup}/data" "{appdir}/data"
fi
"{launcher}" >/dev/null 2>&1 &
""")
            os.chmod(helper,0o755)
            subprocess.Popen(["bash", str(helper)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            QApplication.instance().quit()
        except Exception as e:
            QMessageBox.critical(self, "Update failed", str(e))


class FleetCard(QFrame):
    doubleClicked = pyqtSignal(str)
    def __init__(self, vessel, parent=None):
        super().__init__(parent); self.vessel=vessel; self.setObjectName('fleetCard'); self.setMinimumHeight(94)
        l=QVBoxLayout(self); n=QLabel(vessel['name']); n.setStyleSheet('font-size:16px;font-weight:900;color:#eaf8ff;'); l.addWidget(n)
        role=QLabel(vessel.get('type','VESSEL')+' · '+vessel.get('location','FLEET UNIT')); role.setStyleSheet('color:#8fc7dc;'); l.addWidget(role)
        st=QLabel('ONLINE' if vessel.get('active_map') or vessel.get('id')=='JAWAD_1' else 'STANDBY'); st.setStyleSheet('color:#46e39c;font-weight:bold;' if st.text()=='ONLINE' else 'color:#f2c35b;font-weight:bold;'); l.addWidget(st)
        hint=QLabel('DOUBLE CLICK TO OPEN' if vessel.get('id')=='JAWAD_1' else 'DOUBLE CLICK FOR VESSEL DETAILS'); hint.setStyleSheet('font-size:10px;color:#6fa0b3;'); l.addWidget(hint)
    def mouseDoubleClickEvent(self,e): self.doubleClicked.emit(self.vessel['id']); super().mouseDoubleClickEvent(e)




class UTMMapCanvas(QWidget):
    """Layered navigation canvas.

    V8.3 keeps the Natural Earth world map permanently underneath every ENC.
    The vessel owns a geographic position; charts never drag the vessel to their
    centre. Manual pan suspends follow mode and RECENTER restores vessel-follow.
    """
    routeFinished = pyqtSignal(list)
    routeChanged = pyqtSignal(list)
    markDoubleClicked = pyqtSignal(dict)
    marksChanged = pyqtSignal()
    fleetDoubleClicked = pyqtSignal(dict)
    aisDoubleClicked = pyqtSignal(dict)
    routeActionRequested = pyqtSignal(str)
    MINA_ZAYED_LAT = 24.5260
    MINA_ZAYED_LON = 54.3860

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(700, 500); self.setMouseTracking(True)
        z,h,e,n=latlon_to_utm(self.MINA_ZAYED_LAT,self.MINA_ZAYED_LON)
        self.zone=z; self.hemisphere=h; self.easting=e; self.northing=n
        self.vessel_lat=self.MINA_ZAYED_LAT; self.vessel_lon=self.MINA_ZAYED_LON
        self.heading=0.0; self.course=0.0; self.speed=0.0
        self.gnss_live=False; self.position_source='MINA ZAYED START'
        self.grid_step=500.0; self.chart_name='WORLD BASE MAP · NO ENC LOADED'
        self.tool='PAN'; self.route=[]; self.measure=[]; self.track=[]; self.show_track=True
        self.show_ais=True; self.show_fleet=True; self.show_marks=True
        self.ais_targets={}; self.fleet_targets={}; self.marine_marks=[]
        self.active_route=False; self.route_follow=False
        self.show_heading_vector=True; self.vector_minutes=6.0
        self.show_range_rings=False; self.range_ring_nm=0.25
        self.ebl_vrm_point=None
        self.lidar_enabled=False; self.lidar_range_m=200.0; self.lidar_angle=0.0
        self.display_mode='DAY'
        self._drag_wp=None; self._drag_mark=None
        self._lidar_timer=QTimer(self); self._lidar_timer.timeout.connect(self._advance_lidar); self._lidar_timer.start(50)
        self.world_basemap=[]; self.world_mode=True
        self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat; self.world_zoom=20.0
        self.vector_features=[]; self.vector_bounds=None; self.vector_chart_name=''
        self._pan_drag=None; self.follow_vessel=True; self.view_mode='NORTH UP'
        # V8.4 map layers. VECTOR is fully offline; other layers are optional online reference layers.
        self.map_layer='VECTOR'
        self.tile_cache_dir=DATA_DIR/'tile_cache'; self.tile_cache_dir.mkdir(parents=True,exist_ok=True)
        self._tile_active=set(); self._tile_lock=threading.Lock(); self._tile_max_active=4
        self._tile_refresh=QTimer(self); self._tile_refresh.timeout.connect(self.update); self._tile_refresh.start(1200)

    @staticmethod
    def _mercator_norm(lon,lat):
        x=(float(lon)+180.0)/360.0
        lat=max(-85.05112878,min(85.05112878,float(lat)))
        r=math.radians(lat)
        y=(1.0-math.log(math.tan(r)+1.0/math.cos(r))/math.pi)/2.0
        return x,y

    @staticmethod
    def _mercator_lonlat(x,y):
        lon=float(x)*360.0-180.0
        n=math.pi-2.0*math.pi*float(y)
        lat=math.degrees(math.atan(math.sinh(n)))
        return lat,lon

    def set_map_layer(self,layer):
        layer=str(layer).upper().strip()
        if layer not in {'VECTOR','SATELLITE','HYBRID','MARINE'}: return
        self.map_layer=layer
        # Online tile layers need a little more zoom headroom than the Natural Earth base.
        if layer!='VECTOR' and self.world_zoom<8.0: self.world_zoom=8.0
        self.update()

    def _tile_zoom(self):
        # Match the app's continuous zoom to standard 256 px slippy-map tile levels.
        z=int(round(math.log(max(1.0,self.width()*self.world_zoom/256.0),2)))
        return max(1,min(17,z))

    def _tile_path(self,provider,z,x,y):
        return self.tile_cache_dir/provider/str(z)/str(x)/(str(y)+'.png')

    def _tile_url(self,provider,z,x,y):
        if provider=='esri':
            return f'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
        if provider=='osm':
            return f'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
        if provider=='seamark':
            return f'https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png'
        return ''

    def _queue_tile(self,provider,z,x,y):
        n=1<<z; x=x%n
        if y<0 or y>=n: return
        path=self._tile_path(provider,z,x,y)
        if path.exists(): return
        key=(provider,z,x,y)
        with self._tile_lock:
            if key in self._tile_active or len(self._tile_active)>=self._tile_max_active: return
            self._tile_active.add(key)
        def worker():
            try:
                url=self._tile_url(provider,z,x,y)
                if not url: return
                path.parent.mkdir(parents=True,exist_ok=True)
                req=urllib.request.Request(url,headers={'User-Agent':'DRBOAT/9.0 marine research display'})
                with urllib.request.urlopen(req,timeout=8) as r:
                    data=r.read(2_000_000)
                if data:
                    tmp=path.with_suffix('.tmp')
                    tmp.write_bytes(data); tmp.replace(path)
            except Exception:
                pass
            finally:
                with self._tile_lock: self._tile_active.discard(key)
        threading.Thread(target=worker,daemon=True).start()

    def _draw_tile_provider(self,p,provider):
        z=self._tile_zoom(); n=1<<z; size=256.0
        cx,cy=self._mercator_norm(self.world_center_lon,self.world_center_lat)
        cpx=cx*n*size; cpy=cy*n*size
        left=cpx-self.width()/2; top=cpy-self.height()/2
        x0=int(math.floor(left/size))-1; x1=int(math.ceil((left+self.width())/size))+1
        y0=int(math.floor(top/size))-1; y1=int(math.ceil((top+self.height())/size))+1
        p.save()
        # Rotate all online tiles with the same map orientation as vector/own-ship geometry.
        p.translate(self.width()/2,self.height()/2); p.rotate(self._view_rotation()); p.translate(-self.width()/2,-self.height()/2)
        for ty in range(y0,y1+1):
            if ty<0 or ty>=n: continue
            for tx in range(x0,x1+1):
                wx=tx%n
                path=self._tile_path(provider,z,wx,ty)
                sx=tx*size-left; sy=ty*size-top
                if path.exists():
                    img=QImage(str(path))
                    if not img.isNull(): p.drawImage(QRectF(sx,sy,size+1,size+1),img)
                else:
                    self._queue_tile(provider,z,wx,ty)
        p.restore()

    def draw_online_basemap(self,p):
        if self.map_layer=='VECTOR': return False
        p.fillRect(self.rect(),QColor('#082b3a'))
        if self.map_layer in {'SATELLITE','HYBRID'}:
            self._draw_tile_provider(p,'esri')
        elif self.map_layer=='MARINE':
            self._draw_tile_provider(p,'osm')
        if self.map_layer in {'HYBRID','MARINE'}:
            self._draw_tile_provider(p,'seamark')
        return True

    def meters_per_pixel(self):
        # approximate local scale at vessel latitude for route / measuring helpers
        px_per_deg=(self.width()/360.0)*max(1.0,self.world_zoom)
        m_per_deg_lon=max(1000.0,111320.0*math.cos(math.radians(self.vessel_lat)))
        return m_per_deg_lon/max(1.0,px_per_deg)

    def _view_rotation(self):
        if self.view_mode=='HEAD UP': return -float(self.heading)
        if self.view_mode=='COURSE UP': return -float(self.course)
        return 0.0

    @staticmethod
    def _rot(dx,dy,deg):
        a=math.radians(deg); c=math.cos(a); s=math.sin(a)
        return dx*c-dy*s, dx*s+dy*c

    def world_to_screen(self,lon,lat):
        w,h=self.width(),self.height()
        if self.map_layer!='VECTOR':
            z=self._tile_zoom(); scale=256.0*(1<<z)
            x,y=self._mercator_norm(lon,lat); cx,cy=self._mercator_norm(self.world_center_lon,self.world_center_lat)
            dx=(x-cx)*scale
            if dx>scale/2: dx-=scale
            if dx<-scale/2: dx+=scale
            dy=(y-cy)*scale
            dx,dy=self._rot(dx,dy,self._view_rotation())
            return QPointF(w/2+dx,h/2+dy)
        sx=(w/360.0)*self.world_zoom; sy=(h/180.0)*self.world_zoom
        dlon=((float(lon)-self.world_center_lon+180.0)%360.0)-180.0
        dx=dlon*sx; dy=-(float(lat)-self.world_center_lat)*sy
        dx,dy=self._rot(dx,dy,self._view_rotation())
        return QPointF(w/2+dx,h/2+dy)

    def screen_to_world(self,pos):
        w,h=self.width(),self.height(); dx=pos.x()-w/2; dy=pos.y()-h/2
        dx,dy=self._rot(dx,dy,-self._view_rotation())
        if self.map_layer!='VECTOR':
            z=self._tile_zoom(); scale=256.0*(1<<z)
            cx,cy=self._mercator_norm(self.world_center_lon,self.world_center_lat)
            x=(cx+dx/scale)%1.0; y=max(0.0,min(1.0,cy+dy/scale))
            return self._mercator_lonlat(x,y)
        sx=(w/360.0)*self.world_zoom; sy=(h/180.0)*self.world_zoom
        lon=self.world_center_lon+dx/max(1e-9,sx)
        lat=self.world_center_lat-dy/max(1e-9,sy)
        lon=((lon+180.0)%360.0)-180.0; lat=max(-89.0,min(89.0,lat))
        return lat,lon

    def screen_to_utm(self,pos):
        lat,lon=self.screen_to_world(pos); z,h,e,n=latlon_to_utm(lat,lon)
        return e,n

    def utm_to_screen(self,e,n,zone=None,hemisphere=None):
        lat,lon=utm_to_latlon(e,n,zone or self.zone,hemisphere or self.hemisphere)
        return self.world_to_screen(lon,lat)

    def set_tool(self,t):
        # MEASURE and EBL/VRM are true toggles; ROUTE uses a drawing cursor until double-click finish.
        if self.tool==t and t in {'MEASURE','EBLVRM'}:
            self.tool='PAN'
            if t=='MEASURE': self.measure=[]
            if t=='EBLVRM': self.ebl_vrm_point=None
            self.unsetCursor(); self.update(); return
        self.tool=t
        if t=='MEASURE': self.measure=[]; self.setCursor(Qt.CrossCursor)
        elif t=='ROUTE': self.setCursor(Qt.CrossCursor)
        elif t=='EBLVRM': self.setCursor(Qt.CrossCursor)
        else: self.unsetCursor()
        self.update()

    def set_view_mode(self,mode):
        mode=str(mode).upper()
        if mode not in {'NORTH UP','HEAD UP','COURSE UP'}: return
        self.view_mode=mode; self.update()

    def recenter_vessel(self):
        self.follow_vessel=True
        self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat
        self.update()

    def zoom_in(self): self.world_zoom=min(20000.0,self.world_zoom*1.5); self.update()
    def zoom_out(self): self.world_zoom=max(1.0,self.world_zoom/1.5); self.update()
    def wheelEvent(self,e): self.zoom_in() if e.angleDelta().y()>0 else self.zoom_out()

    def _advance_lidar(self):
        if self.lidar_enabled:
            self.lidar_angle=(self.lidar_angle+4.0)%360.0; self.update()

    def set_display_mode(self,mode):
        mode=str(mode).upper().strip()
        if mode not in {'DAY','DUSK','NIGHT','NIGHT RED'}: return
        self.display_mode=mode; self.update()

    def toggle_lidar(self): self.lidar_enabled=not self.lidar_enabled; self.update()
    def toggle_range_rings(self): self.show_range_rings=not self.show_range_rings; self.update()
    def toggle_heading_vector(self): self.show_heading_vector=not self.show_heading_vector; self.update()

    def _hit_route_segment(self,pos,radius=12):
        if len(self.route)<2: return False
        px,py=pos.x(),pos.y()
        for i in range(len(self.route)-1):
            a=self.utm_to_screen(*self.route[i]); b=self.utm_to_screen(*self.route[i+1])
            ax,ay,bx,by=a.x(),a.y(),b.x(),b.y(); vx,vy=bx-ax,by-ay; wx,wy=px-ax,py-ay
            vv=vx*vx+vy*vy
            t=0.0 if vv<1e-9 else max(0.0,min(1.0,(wx*vx+wy*vy)/vv))
            qx,qy=ax+t*vx,ay+t*vy
            if math.hypot(px-qx,py-qy)<=radius: return True
        return False

    def _hit_route_wp(self,pos,radius=12):
        best=None; bd=1e9
        for i,pt in enumerate(self.route):
            q=self.utm_to_screen(*pt); d=math.hypot(q.x()-pos.x(),q.y()-pos.y())
            if d<radius and d<bd: best=i; bd=d
        return best

    def _hit_mark(self,pos,radius=13):
        if not self.show_marks: return None
        best=None; bd=1e9
        for i,m in enumerate(self.marine_marks):
            q=self.world_to_screen(m.get('lon',0),m.get('lat',0)); d=math.hypot(q.x()-pos.x(),q.y()-pos.y())
            if d<radius and d<bd: best=i; bd=d
        return best

    def _hit_geo_target(self,pos,targets,radius=16):
        best=None; bd=1e9
        for key,t in targets.items():
            q=self.world_to_screen(t.get('lon',0),t.get('lat',0)); d=math.hypot(q.x()-pos.x(),q.y()-pos.y())
            if d<radius and d<bd: best=key; bd=d
        return best

    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton:
            # Route waypoints remain directly draggable in normal PAN mode.
            if self.tool=='PAN':
                wp=self._hit_route_wp(e.pos())
                if wp is not None:
                    self._drag_wp=wp; self.follow_vessel=False; self.setCursor(Qt.SizeAllCursor); return
                mk=self._hit_mark(e.pos())
                if mk is not None:
                    self._drag_mark=mk; self.follow_vessel=False; self.setCursor(Qt.SizeAllCursor); return
                self._pan_drag=e.pos(); self.follow_vessel=False; self.setCursor(Qt.ClosedHandCursor); return
            lat,lon=self.screen_to_world(e.pos()); z,h,east,north=latlon_to_utm(lat,lon)
            self.zone=z; self.hemisphere=h; pt=(east,north)
            if self.tool=='ROUTE': self.route.append(pt); self.update()
            elif self.tool=='MEASURE':
                if len(self.measure)>=2: self.measure=[]
                self.measure.append(pt); self.update()
            elif self.tool=='EBLVRM':
                self.ebl_vrm_point=pt; self.update()
            elif self.tool=='MARK':
                self.marine_marks.append({'id':f'MARK-{int(time.time()*1000)}','name':f'Mark {len(self.marine_marks)+1}','symbol':'MARK','lat':lat,'lon':lon,'notes':'','created':datetime.now().isoformat(timespec='seconds')})
                self.tool='PAN'; self.marksChanged.emit(); self.update()
        elif e.button()==Qt.RightButton:
            if self._hit_route_wp(e.pos(),14) is not None or self._hit_route_segment(e.pos(),12):
                menu=QMenu(self)
                if self.active_route:
                    deact=menu.addAction('DEACTIVATE ROUTE')
                else:
                    act=menu.addAction('ACTIVATE ROUTE')
                follow=menu.addAction('FOLLOW ACTIVE ROUTE')
                rev=menu.addAction('REVERSE ROUTE')
                prop=menu.addAction('ROUTE / VOYAGE PROPERTIES')
                delete=menu.addAction('DELETE ROUTE')
                choice=menu.exec_(e.globalPos())
                if choice:
                    txt=choice.text()
                    if txt=='ACTIVATE ROUTE': self.active_route=True; self.route_follow=True; self.routeActionRequested.emit('ACTIVATE')
                    elif txt=='DEACTIVATE ROUTE': self.active_route=False; self.route_follow=False; self.routeActionRequested.emit('DEACTIVATE')
                    elif txt=='FOLLOW ACTIVE ROUTE': self.active_route=True; self.route_follow=True; self.routeActionRequested.emit('FOLLOW')
                    elif txt=='REVERSE ROUTE': self.route=list(reversed(self.route)); self.routeChanged.emit(self.route[:]); self.routeActionRequested.emit('REVERSE')
                    elif txt=='ROUTE / VOYAGE PROPERTIES': self.routeActionRequested.emit('PROPERTIES')
                    elif txt=='DELETE ROUTE': self.route=[]; self.active_route=False; self.route_follow=False; self.routeChanged.emit([]); self.routeActionRequested.emit('DELETE')
                    self.update()
                return
            lat,lon=self.screen_to_world(e.pos()); z,h,east,north=latlon_to_utm(lat,lon)
            QMessageBox.information(self,'MAP COORDINATES',
                f'LAT {lat:.7f}°\nLON {lon:.7f}°\n\nUTM {z}{h}\nE {east:.2f} m\nN {north:.2f} m')

    def mouseMoveEvent(self,e):
        if self._drag_wp is not None and (e.buttons() & Qt.LeftButton):
            lat,lon=self.screen_to_world(e.pos()); z,h,east,north=latlon_to_utm(lat,lon)
            self.route[self._drag_wp]=(east,north); self.zone=z; self.hemisphere=h; self.routeChanged.emit(self.route[:]); self.update(); return
        if self._drag_mark is not None and (e.buttons() & Qt.LeftButton):
            lat,lon=self.screen_to_world(e.pos()); self.marine_marks[self._drag_mark]['lat']=lat; self.marine_marks[self._drag_mark]['lon']=lon; self.update(); return
        if self._pan_drag is not None and (e.buttons() & Qt.LeftButton):
            dx=e.pos().x()-self._pan_drag.x(); dy=e.pos().y()-self._pan_drag.y()
            dx,dy=self._rot(dx,dy,-self._view_rotation())
            if self.map_layer!='VECTOR':
                z=self._tile_zoom(); scale=256.0*(1<<z)
                cx,cy=self._mercator_norm(self.world_center_lon,self.world_center_lat)
                cx=(cx-dx/scale)%1.0; cy=max(0.001,min(0.999,cy-dy/scale))
                self.world_center_lat,self.world_center_lon=self._mercator_lonlat(cx,cy)
            else:
                sx=(self.width()/360.0)*self.world_zoom; sy=(self.height()/180.0)*self.world_zoom
                self.world_center_lon-=dx/max(1e-9,sx); self.world_center_lat+=dy/max(1e-9,sy)
                self.world_center_lon=((self.world_center_lon+180.0)%360.0)-180.0
                self.world_center_lat=max(-80.0,min(84.0,self.world_center_lat))
            self._pan_drag=e.pos(); self.update()

    def mouseReleaseEvent(self,e):
        if e.button()==Qt.LeftButton:
            if self._drag_wp is not None:
                self._drag_wp=None; self.unsetCursor(); self.routeChanged.emit(self.route[:]); return
            if self._drag_mark is not None:
                self._drag_mark=None; self.unsetCursor(); self.marksChanged.emit(); self.update(); return
            if self._pan_drag is not None:
                self._pan_drag=None; self.unsetCursor()

    def mouseDoubleClickEvent(self,e):
        if self.tool=='PAN' and self._hit_route_segment(e.pos(),12):
            self.routeActionRequested.emit('PROPERTIES'); return
        if self.tool=='ROUTE' and len(self.route)>=2:
            if len(self.route)>=2 and self.dist_bearing(self.route[-2],self.route[-1])[0]<1.0: self.route.pop()
            self.routeFinished.emit(self.route[:]); self.tool='PAN'; self.unsetCursor(); self.update(); return
        mk=self._hit_mark(e.pos())
        if mk is not None: self.markDoubleClicked.emit(dict(self.marine_marks[mk])); return
        key=self._hit_geo_target(e.pos(),self.fleet_targets) if self.show_fleet else None
        if key is not None: self.fleetDoubleClicked.emit(dict(self.fleet_targets[key])); return
        key=self._hit_geo_target(e.pos(),self.ais_targets) if self.show_ais else None
        if key is not None: self.aisDoubleClicked.emit(dict(self.ais_targets[key])); return

    def move_container_to(self,target_layout):
        """Compatibility for the vessel-focus screen: move the DR BOAT map itself."""
        try:
            if not hasattr(self,'_home_parent') or self._home_parent is None:
                self._home_parent=self.parentWidget(); self._home_layout=self._home_parent.layout() if self._home_parent else None
            self.setParent(None); target_layout.addWidget(self,1); return True
        except Exception: return False

    def restore_container(self):
        try:
            if getattr(self,'_home_layout',None) is not None:
                self.setParent(None); self._home_layout.addWidget(self,3)
        except Exception: pass

    def set_position(self,easting,northing,zone=None,heading=None,speed=None,course=None,source=None,gnss_live=None):
        self.easting=float(easting); self.northing=float(northing)
        if zone is not None: self.zone=int(zone)
        if heading is not None: self.heading=float(heading)%360
        if course is not None: self.course=float(course)%360
        elif heading is not None and self.speed>0.2: self.course=float(heading)%360
        if speed is not None: self.speed=float(speed)
        if gnss_live is not None: self.gnss_live=bool(gnss_live)
        if source: self.position_source=str(source)
        self.vessel_lat,self.vessel_lon=utm_to_latlon(self.easting,self.northing,self.zone,self.hemisphere)
        if self.follow_vessel: self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat
        self.update()

    def set_gnss_fix(self,lat,lon,heading=None,speed=None,course=None):
        z,h,e,n=latlon_to_utm(lat,lon); self.hemisphere=h
        self.set_position(e,n,z,heading,speed,course,'GNSS',True)

    def set_gnss_lost(self):
        self.gnss_live=False; self.position_source='LAST FIX / DR STANDBY'; self.update()

    def set_chart_name(self,name): self.chart_name=name or 'WORLD BASE MAP'; self.update()

    @staticmethod
    def dist_bearing(a,b):
        de=b[0]-a[0]; dn=b[1]-a[1]
        return math.hypot(de,dn),(math.degrees(math.atan2(de,dn))+360)%360

    def load_world_basemap(self,path=None,reset_view=False):
        p=Path(path) if path else APP_DIR/'charts'/'DRBOAT_WORLD_BASE_NATURAL_EARTH.geojson'
        obj=json.loads(p.read_text(errors='ignore')); rings=[]
        for feat in obj.get('features',[]):
            geom=feat.get('geometry') or {}; typ=geom.get('type'); coords=geom.get('coordinates') or []
            if typ=='Polygon':
                for ring in coords:
                    if len(ring)>=3: rings.append(ring)
            elif typ=='MultiPolygon':
                for poly in coords:
                    for ring in poly:
                        if len(ring)>=3: rings.append(ring)
        if not rings: raise ValueError('World base map contains no polygon geometry.')
        self.world_basemap=rings; self.world_mode=True
        if reset_view:
            self.world_center_lon=self.vessel_lon; self.world_center_lat=self.vessel_lat; self.world_zoom=20.0
            self.follow_vessel=True
        self.chart_name='NATURAL EARTH VECTOR WORLD BASE MAP' + (f' + {self.vector_chart_name}' if self.vector_chart_name else '')
        self.update(); return len(rings)

    def draw_world_basemap(self,p):
        p.fillRect(self.rect(),QColor('#082b3a'))
        if not self.world_basemap: return
        p.setPen(QPen(QColor('#76939a'),0.8)); p.setBrush(QColor('#344842'))
        for ring in self.world_basemap:
            pts=[self.world_to_screen(float(q[0]),float(q[1])) for q in ring if isinstance(q,(list,tuple)) and len(q)>=2]
            if len(pts)>=3: p.drawPolygon(*pts)

    def draw_global_utm_grid(self,p):
        """Low-zoom UTM-zone reference only.

        V8.4 deliberately removes the dense local metre-grid that could stack
        unreadable labels over the vessel/harbour. No local UTM lattice is drawn.
        """
        if self.world_zoom >= 6.0:
            return
        p.setFont(QFont('Arial',7)); p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(55,115,135,120),1,Qt.DashLine))
        for lon in range(-180,181,6):
            a=self.world_to_screen(lon,-80); b=self.world_to_screen(lon,84); p.drawLine(a,b)
            if lon<180:
                q=self.world_to_screen(lon+3,0)
                if -30<q.x()<self.width()+30 and -30<q.y()<self.height()+30:
                    p.setPen(QColor('#7faebd')); p.drawText(q+QPointF(-7,-3),str(int(((lon+180)//6)+1)))
                    p.setPen(QPen(QColor(55,115,135,120),1,Qt.DashLine))
        for lat in range(-80,85,8):
            p.drawLine(self.world_to_screen(-180,lat),self.world_to_screen(180,lat))

    def clear_vector_chart(self):
        self.vector_features=[]; self.vector_bounds=None; self.vector_chart_name=''; self.chart_name='WORLD BASE MAP · NO ENC LOADED'; self.update()

    def fit_vector_chart(self):
        if not self.vector_bounds: return
        minlon,minlat,maxlon,maxlat=self.vector_bounds
        self.world_center_lon=(minlon+maxlon)/2; self.world_center_lat=(minlat+maxlat)/2
        lonspan=max(0.01,maxlon-minlon); latspan=max(0.01,maxlat-minlat)
        usable_w=max(240,self.width()-90); usable_h=max(220,self.height()-90)
        zx=usable_w*360.0/(max(1,self.width())*lonspan); zy=usable_h*180.0/(max(1,self.height())*latspan)
        self.world_zoom=max(1.0,min(900.0,min(zx,zy)*0.88)); self.follow_vessel=False; self.update()

    def load_geojson_chart(self,path):
        # Store ENC geometry in geographic coordinates so it remains a true overlay on the world base map.
        obj=json.loads(Path(path).read_text(errors='ignore'))
        feats=obj.get('features',[]) if obj.get('type')=='FeatureCollection' else [{'geometry':obj,'properties':{}}]
        out=[]; lons=[]; lats=[]
        for feat in feats:
            props=feat.get('properties') or {}
            for kind,coords in flatten_geojson_geometry(feat.get('geometry')):
                raw=[coords] if kind=='Point' else coords; pts=[]
                for pair in raw:
                    if not isinstance(pair,(list,tuple)) or len(pair)<2: continue
                    lon,lat=float(pair[0]),float(pair[1]); pts.append((lon,lat)); lons.append(lon); lats.append(lat)
                if pts: out.append({'kind':kind,'pts':pts,'props':props})
        if not out: raise ValueError('No drawable vector features found.')
        self.vector_features=out; self.vector_bounds=(min(lons),min(lats),max(lons),max(lats)); self.world_mode=True
        return len(out)

    def draw_vector_chart(self,p):
        if not self.vector_features: return
        for f in self.vector_features:
            kind=f['kind']; pts=[self.world_to_screen(*q) for q in f['pts']]
            props=f.get('props') or {}; layer=str(props.get('_S57_LAYER','')).upper()
            if kind=='Polygon' and len(pts)>=3:
                if layer in ('DEPARE','DRGARE'): pen=QColor('#366b7a'); brush=QColor('#0d4052')
                elif layer in ('LNDARE','BUAARE'): pen=QColor('#887e63'); brush=QColor('#4b5040')
                elif layer in ('RESARE','ACHARE','FAIRWY'): pen=QColor('#c0a95a'); brush=QColor(50,75,68,110)
                else: pen=QColor('#637c78'); brush=QColor(35,63,66,150)
                p.setPen(QPen(pen,1)); p.setBrush(brush); p.drawPolygon(*pts)
            elif kind=='LineString' and len(pts)>=2:
                p.setBrush(Qt.NoBrush)
                if layer=='COALNE': col=QColor('#d8c98c'); wid=2
                elif layer in ('DEPCNT','DEPLNE'): col=QColor('#5db5d1'); wid=1
                elif layer in ('NAVLNE','RECTRC','FAIRWY'): col=QColor('#e7c85c'); wid=1
                else: col=QColor('#89b4bf'); wid=1
                p.setPen(QPen(col,wid));
                for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
            elif kind=='Point' and pts:
                if layer in ('BOYLAT','BOYCAR','BOYSAW','BCNSPP','BCNLAT','LIGHTS'): col=QColor('#f4dc67'); r=4.0
                elif layer in ('SOUNDG',): col=QColor('#b8dbe5'); r=2.0
                elif layer in ('WRECKS','OBSTRN'): col=QColor('#ef8d71'); r=4.0
                else: col=QColor('#d7e6eb'); r=2.5
                p.setPen(QPen(col,1)); p.setBrush(col); p.drawEllipse(pts[0],r,r)

    def _draw_range_tools(self,p):
        pos=self.world_to_screen(self.vessel_lon,self.vessel_lat)
        mpp=max(0.05,self.meters_per_pixel())
        if self.show_range_rings:
            p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor('#73d7e8'),1,Qt.DashLine))
            step_m=max(25.0,self.range_ring_nm*1852.0)
            for i in range(1,5):
                r=step_m*i/mpp
                if r>min(self.width(),self.height())*.7: break
                p.drawEllipse(pos,r,r); p.drawText(pos+QPointF(r+4,0),f'{self.range_ring_nm*i:.2f} NM')
        if self.show_heading_vector:
            mins=max(.5,float(self.vector_minutes)); dist_m=self.speed*1852.0*(mins/60.0); px=dist_m/mpp
            if px>8:
                a=math.radians((self.heading+self._view_rotation())%360.0); end=pos+QPointF(math.sin(a)*px,-math.cos(a)*px)
                p.setPen(QPen(QColor('#ff3f4f'),2)); p.drawLine(pos,end); p.drawText(end+QPointF(5,-5),f'HDG VECTOR {mins:g} min')
        if self.ebl_vrm_point is not None:
            q=self.utm_to_screen(*self.ebl_vrm_point); d,b=self.dist_bearing((self.easting,self.northing),self.ebl_vrm_point)
            p.setPen(QPen(QColor('#f3cc5b'),1.5,Qt.DashLine)); p.drawLine(pos,q); p.setBrush(Qt.NoBrush); p.drawEllipse(pos,d/mpp,d/mpp)
            p.drawText((pos+q)/2+QPointF(5,-5),f'EBL {b:.1f}° · VRM {d/1852.0:.3f} NM')
        if self.lidar_enabled:
            r=self.lidar_range_m/mpp
            p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor('#55f0b0'),1.4)); p.drawEllipse(pos,r,r)
            a=math.radians((self.lidar_angle+self._view_rotation())%360.0); end=pos+QPointF(math.sin(a)*r,-math.cos(a)*r)
            p.setPen(QPen(QColor('#79ffd0'),2)); p.drawLine(pos,end); p.drawText(pos+QPointF(12,r if r<120 else 18),f'LIDAR SIM · {self.lidar_range_m:.0f} m RANGE')

    def _draw_vessel(self,p):
        """Professional ECDIS-style own-ship symbol; actual heading is applied directly."""
        pos=self.world_to_screen(self.vessel_lon,self.vessel_lat)
        if pos.x()<-70 or pos.x()>self.width()+70 or pos.y()<-70 or pos.y()>self.height()+70: return
        icon_angle=(self.heading+self._view_rotation())%360
        live=self.gnss_live; edge=QColor('#101010') if live else QColor('#8b1111'); fill=QColor('#f8fbfd') if live else QColor('#ff3434')
        p.save(); p.translate(pos); p.rotate(icon_angle)
        p.setPen(QPen(edge,1.7)); p.setBrush(fill)
        hull=[QPointF(0,-19),QPointF(5,-11),QPointF(6,13),QPointF(0,18),QPointF(-6,13),QPointF(-5,-11)]
        p.drawPolygon(*hull)
        p.setBrush(QColor('#263842') if live else QColor('#6b1515')); p.drawRect(QRectF(-3,-5,6,10))
        p.setPen(QPen(QColor('#101010') if live else QColor('#ffe0e0'),1.2)); p.drawLine(QPointF(-5,7),QPointF(5,7))
        p.restore()
        p.setFont(QFont('Arial',7,QFont.Bold)); p.setPen(QColor('#e6f7ff') if live else QColor('#ff7a73')); p.drawText(pos+QPointF(10,-8),'OWN SHIP')

    def _draw_target_ship(self,p,lat,lon,heading,label,fill,outline=None,size=10):
        q=self.world_to_screen(lon,lat)
        if q.x()<-40 or q.x()>self.width()+40 or q.y()<-40 or q.y()>self.height()+40: return
        p.save(); p.translate(q); p.rotate((float(heading)+self._view_rotation())%360)
        p.setPen(QPen(outline or fill,1.5)); p.setBrush(fill)
        pts=[QPointF(0,-size*1.5),QPointF(size*.7,size),QPointF(0,size*.65),QPointF(-size*.7,size)]
        p.drawPolygon(*pts); p.restore()
        p.setPen(QColor('#eaf8ff')); p.setFont(QFont('Arial',7,QFont.Bold)); p.drawText(q+QPointF(size+3,-3),str(label)[:22])

    def draw_operational_layers(self,p):
        if self.show_track and len(self.track)>1:
            p.setPen(QPen(QColor('#ffd400'),3)); pts=[self.utm_to_screen(*q) for q in self.track]
            for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
        if self.show_marks:
            for m in self.marine_marks:
                q=self.world_to_screen(m.get('lon',0),m.get('lat',0)); sym=str(m.get('symbol','MARK')).upper()
                col=QColor('#f3cf54') if sym not in ('DANGER','WRECK') else QColor('#ff6b61')
                p.setPen(QPen(col,2)); p.setBrush(QColor(0,0,0,0)); p.drawEllipse(q,6,6); p.drawLine(q+QPointF(-8,0),q+QPointF(8,0)); p.drawLine(q+QPointF(0,-8),q+QPointF(0,8))
                p.setPen(QColor('#eaf8ff')); p.setFont(QFont('Arial',7,QFont.Bold)); p.drawText(q+QPointF(10,-8),m.get('name','MARK')[:24])
        if self.show_fleet:
            for t in self.fleet_targets.values():
                self._draw_target_ship(p,t.get('lat',0),t.get('lon',0),t.get('heading',0),t.get('name',t.get('id','FLEET')),QColor('#55d7ff'),QColor('#c6f5ff'),10)
        if self.show_ais:
            now=time.time()
            for t in list(self.ais_targets.values()):
                age=now-float(t.get('rx_time',now)); fill=QColor('#55e59c') if age<60 else QColor('#a5b2b8')
                self._draw_target_ship(p,t.get('lat',0),t.get('lon',0),t.get('heading',t.get('cog',0)),t.get('name') or str(t.get('mmsi','AIS')),fill,QColor('#dfffea'),9)

    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height()
        online=self.draw_online_basemap(p)
        if not online: self.draw_world_basemap(p)
        self.draw_vector_chart(p); self.draw_global_utm_grid(p)
        if len(self.route)>0:
            route_col=QColor('#ff3348') if self.active_route else QColor('#ffd34e')
            p.setPen(QPen(route_col,3 if self.active_route else 2)); pts=[self.utm_to_screen(*q) for q in self.route]
            for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
            p.setBrush(route_col)
            for i,q in enumerate(pts): p.drawEllipse(q,5,5); p.drawText(q+QPointF(7,-7),f'WP{i+1}')
        if len(self.measure)==2:
            a,b=self.measure; pa,pb=self.utm_to_screen(*a),self.utm_to_screen(*b)
            p.setPen(QPen(QColor('#f2c35b'),2,Qt.DashLine)); p.drawLine(pa,pb)
            d,brg=self.dist_bearing(a,b); mid=(pa+pb)/2; p.drawText(mid+QPointF(8,-8),f'{d:.1f} m / {d/1852:.3f} NM · {brg:.1f}°')
        self.draw_operational_layers(p)
        self._draw_range_tools(p)
        self._draw_vessel(p)
        p.setPen(QColor('#d9f3fb')); p.setFont(QFont('Arial',10,QFont.Bold))
        src='GNSS LIVE' if self.gnss_live else 'START POSITION · MINA ZAYED · GNSS WAITING'
        p.drawText(14,22,f'{src}   |   {self.view_mode}')
        p.setPen(QColor('#82aebf')); p.setFont(QFont('Arial',9)); p.drawText(14,40,self.chart_name[:105])
        p.setPen(QColor('#79cce8')); p.drawText(w-280,22,f'HDG {self.heading:05.1f}°   COG {self.course:05.1f}°   {self.speed:.1f} kn')
        p.drawText(w-280,40,f'ZOOM {self.world_zoom:.1f}x   FOLLOW {"ON" if self.follow_vessel else "OFF"}')
        if self.map_layer in {'SATELLITE','HYBRID'}:
            p.setPen(QColor('#d7e6eb')); p.setFont(QFont('Arial',7)); p.drawText(12,h-10,'SATELLITE: Esri World Imagery · online reference layer')
        elif self.map_layer=='MARINE':
            p.setPen(QColor('#d7e6eb')); p.setFont(QFont('Arial',7)); p.drawText(12,h-10,'MARINE: OpenStreetMap + OpenSeaMap seamarks · online reference layer')
        if self.display_mode!='DAY':
            if self.display_mode=='DUSK': col=QColor(25,18,8,85)
            elif self.display_mode=='NIGHT': col=QColor(0,8,18,145)
            else: col=QColor(70,0,0,150)
            p.fillRect(self.rect(),col)
            p.setPen(QColor('#ffb0a8') if self.display_mode=='NIGHT RED' else QColor('#9fb7c2')); p.drawText(12,h-26,f'DISPLAY · {self.display_mode}')

def utm_to_latlon(easting,northing,zone,hemisphere='N'):
    # WGS84 inverse UTM, dependency-free for the lightweight RPi build.
    a=6378137.0; ecc=0.00669438; k0=0.9996; e1=(1-math.sqrt(1-ecc))/(1+math.sqrt(1-ecc))
    x=easting-500000.0; y=northing
    if str(hemisphere).upper().startswith('S'): y-=10000000.0
    lon0=(int(zone)-1)*6-180+3
    M=y/k0; mu=M/(a*(1-ecc/4-3*ecc**2/64-5*ecc**3/256))
    j1=3*e1/2-27*e1**3/32; j2=21*e1**2/16-55*e1**4/32; j3=151*e1**3/96; j4=1097*e1**4/512
    fp=mu+j1*math.sin(2*mu)+j2*math.sin(4*mu)+j3*math.sin(6*mu)+j4*math.sin(8*mu)
    e2=ecc/(1-ecc); C1=e2*math.cos(fp)**2; T1=math.tan(fp)**2
    N1=a/math.sqrt(1-ecc*math.sin(fp)**2); R1=a*(1-ecc)/(1-ecc*math.sin(fp)**2)**1.5; D=x/(N1*k0)
    lat=fp-(N1*math.tan(fp)/R1)*(D**2/2-(5+3*T1+10*C1-4*C1**2-9*e2)*D**4/24+(61+90*T1+298*C1+45*T1**2-252*e2-3*C1**2)*D**6/720)
    lon=math.radians(lon0)+(D-(1+2*T1+C1)*D**3/6+(5-2*C1+28*T1-3*C1**2+8*e2+24*T1**2)*D**5/120)/math.cos(fp)
    return math.degrees(lat),math.degrees(lon)


def latlon_to_utm(lat,lon):
    # WGS84 forward UTM. Returns zone, hemisphere, easting, northing.
    a=6378137.0; ecc=0.00669438; k0=0.9996
    lat=float(lat); lon=float(lon)
    zone=int((lon+180)//6)+1
    zone=max(1,min(60,zone))
    hemi='N' if lat>=0 else 'S'
    latr=math.radians(lat); lonr=math.radians(lon)
    lon0=math.radians((zone-1)*6-180+3)
    eccp=ecc/(1-ecc)
    N=a/math.sqrt(1-ecc*math.sin(latr)**2)
    T=math.tan(latr)**2
    C=eccp*math.cos(latr)**2
    A=math.cos(latr)*(lonr-lon0)
    M=a*((1-ecc/4-3*ecc**2/64-5*ecc**3/256)*latr
         -(3*ecc/8+3*ecc**2/32+45*ecc**3/1024)*math.sin(2*latr)
         +(15*ecc**2/256+45*ecc**3/1024)*math.sin(4*latr)
         -(35*ecc**3/3072)*math.sin(6*latr))
    e=k0*N*(A+(1-T+C)*A**3/6+(5-18*T+T*T+72*C-58*eccp)*A**5/120)+500000
    n=k0*(M+N*math.tan(latr)*(A*A/2+(5-T+9*C+4*C*C)*A**4/24+(61-58*T+T*T+600*C-330*eccp)*A**6/720))
    if lat<0: n+=10000000
    return zone,hemi,e,n


def flatten_geojson_geometry(geom):
    # Return a list of (kind, coordinates) items using lon/lat coordinates.
    if not geom: return []
    typ=geom.get('type'); c=geom.get('coordinates')
    if typ=='Point': return [('Point',c)]
    if typ=='MultiPoint': return [('Point',p) for p in c]
    if typ=='LineString': return [('LineString',c)]
    if typ=='MultiLineString': return [('LineString',x) for x in c]
    if typ=='Polygon': return [('Polygon',ring) for ring in c]
    if typ=='MultiPolygon':
        out=[]
        for poly in c:
            for ring in poly: out.append(('Polygon',ring))
        return out
    if typ=='GeometryCollection':
        out=[]
        for g in geom.get('geometries',[]): out.extend(flatten_geojson_geometry(g))
        return out
    return []


class PositionSourceCard(QFrame):
    def __init__(self,title,subtitle,status='STANDBY',parent=None):
        super().__init__(parent); self.setObjectName('fleetCard'); self.setMaximumHeight(72)
        l=QVBoxLayout(self); l.setContentsMargins(8,4,8,4); l.setSpacing(1)
        self.title=QLabel(title); self.title.setObjectName('sectionTitle'); l.addWidget(self.title)
        self.sub=QLabel(subtitle); self.sub.setObjectName('smallStatus'); l.addWidget(self.sub)
        self.status=QLabel(status); self.status.setStyleSheet('font-weight:900;color:#f2c35b;'); l.addWidget(self.status)
    def set_status(self,text,ok=False):
        self.status.setText(text); self.status.setStyleSheet('font-weight:900;color:%s;' % ('#46e39c' if ok else '#f2c35b'))


class PositioningSystemPage(QWidget):
    # Update files (.001/.002/...) are deliberately excluded from selectable chart cells.
    CHART_EXTENSIONS={'.kap','.bsb','.000','.001','.002','.003','.004','.005','.s57','.enc','.geojson','.json','.mbtiles','.sqlite','.tif','.tiff','.png','.jpg','.jpeg','.a','.b','.c','.d','.e','.f','.g','.z'}
    def __init__(self,main_window):
        super().__init__(); self.main_window=main_window; self.chart_dir=None; self.chart_files=[]; self.track_recording=False
        root=QVBoxLayout(self); root.setContentsMargins(8,7,8,8); root.setSpacing(5)
        top=QHBoxLayout(); title=QLabel('DR BOAT AI POSITIONING SYSTEM'); title.setObjectName('pageTitle'); self.page_title=title; top.addWidget(title); top.addStretch()
        self.mode=QLabel('POSITION MODE · MINA ZAYED START · GNSS WAITING'); self.mode.setObjectName('aiBadge'); top.addWidget(self.mode); root.addLayout(top)
        body=QHBoxLayout(); body.setSpacing(6)
        self.left=QFrame(); self.left.setObjectName('mapPanel'); ll=QVBoxLayout(self.left); ll.setContentsMargins(4,4,4,4); ll.setSpacing(3)
        self.canvas=UTMMapCanvas(); self.canvas.routeFinished.connect(self.route_finished); self.canvas.routeChanged.connect(self.route_changed)
        self.canvas.markDoubleClicked.connect(self.show_mark_info); self.canvas.marksChanged.connect(self._save_marks); self.canvas.fleetDoubleClicked.connect(self.show_fleet_info); self.canvas.aisDoubleClicked.connect(self.show_ais_info); self.canvas.routeActionRequested.connect(self.route_action)

        # V8.4 "C" professional compact toolbar: small high-frequency controls,
        # with map-navigation tools in a narrow vertical rail.
        topbar=QHBoxLayout(); topbar.setSpacing(3); self._top_controls=[]
        def topbtn(text,fn,tip=''):
            b=QPushButton(text); b.setFixedHeight(30); b.setMinimumWidth(58); b.setMaximumWidth(125); self._top_controls.append(b)
            b.setStyleSheet('QPushButton{padding:2px 7px;font-size:10px;font-weight:800;}')
            if tip: b.setToolTip(tip)
            b.clicked.connect(fn); topbar.addWidget(b); return b
        topbtn('CHARTS',self.show_chart_manager,'Marine chart manager')
        topbtn('ADD DIR',self.choose_chart_directory,'Add local chart directory')
        self.layer_combo=QComboBox(); self.layer_combo.setFixedHeight(30); self.layer_combo.setMaximumWidth(145)
        self.layer_combo.addItems(['VECTOR','SATELLITE','HYBRID','MARINE'])
        self.layer_combo.setToolTip('Map layer: offline vector, satellite, hybrid, or marine online reference')
        self.layer_combo.currentTextChanged.connect(self.canvas.set_map_layer); topbar.addWidget(self.layer_combo); self._top_controls.append(self.layer_combo)
        self.display_combo=QComboBox(); self.display_combo.setFixedHeight(30); self.display_combo.setMaximumWidth(105); self.display_combo.addItems(['DAY','DUSK','NIGHT','NIGHT RED']); self.display_combo.currentTextChanged.connect(self.set_display_mode); topbar.addWidget(self.display_combo); self._top_controls.append(self.display_combo)
        topbtn('FIT ENC',lambda:self.canvas.fit_vector_chart())
        topbtn('WORLD',self.load_world_map)
        topbtn('UTM↔LL',self.show_coordinate_dialog,'UTM / Latitude-Longitude')
        topbtn('ROUTES',self.show_route_library,'Saved route / voyage library')
        topbtn('TRACKS',self.show_track_library,'Recorded track library')
        topbtn('LIDAR',self.toggle_lidar,'LiDAR 360° layer / simulation')
        topbtn('AI NAV',self.show_ai_navigation,'AI Navigation status')
        topbtn('AUTO',self.show_autopilot,'Autopilot heading-hold panel')
        topbtn('SAFETY',self.show_safety_tools,'MOB / Anchor Alert')
        self.full_btn=topbtn('FULL',self.toggle_maximize,'True full-screen navigation mode · Esc/F11 exits')
        topbar.addStretch(); ll.addLayout(topbar)

        maprow=QHBoxLayout(); maprow.setSpacing(3); maprow.addWidget(self.canvas,1)
        rail=QFrame(); rail.setObjectName('panel'); rail.setMaximumWidth(72); rl=QVBoxLayout(rail); rl.setContentsMargins(3,3,3,3); rl.setSpacing(3)
        def railbtn(text,fn,tip):
            b=QPushButton(text); b.setFixedSize(64,36); b.setToolTip(tip)
            b.setStyleSheet('QPushButton{padding:1px;font-size:10px;font-weight:900;}')
            b.clicked.connect(fn); rl.addWidget(b); return b
        railbtn('+',lambda:self.canvas.zoom_in(),'Zoom in')
        railbtn('−',lambda:self.canvas.zoom_out(),'Zoom out')
        railbtn('CENTER',self.recenter_vessel,'Recenter / Follow vessel')
        railbtn('N UP',lambda:self.canvas.set_view_mode('NORTH UP'),'North Up')
        railbtn('H UP',lambda:self.canvas.set_view_mode('HEAD UP'),'Head Up')
        railbtn('C UP',lambda:self.canvas.set_view_mode('COURSE UP'),'Course Up')
        railbtn('MEAS',lambda:self.canvas.set_tool('MEASURE'),'Measure distance/bearing')
        railbtn('ROUTE',self.start_route,'Draw route')
        railbtn('TRACK',self.toggle_track,'Start/stop track recording')
        railbtn('MARK',self.add_marine_mark,'Add marine/user mark')
        railbtn('AIS',self.toggle_ais,'Show/hide AIS targets')
        railbtn('FLEET',self.toggle_fleet,'Show/hide own fleet')
        railbtn('VECTOR',self.toggle_heading_vector,'Heading vector')
        railbtn('RINGS',self.toggle_range_rings,'Range rings')
        railbtn('EBL/VRM',lambda:self.canvas.set_tool('EBLVRM'),'Electronic bearing line / variable range marker')
        railbtn('PAN',lambda:self.canvas.set_tool('PAN'),'Pan map')
        self.tool_rail=rail
        rl.addStretch(); maprow.addWidget(rail); ll.addLayout(maprow,1)
        lower=QHBoxLayout(); self.chart_combo=QComboBox(); self.chart_combo.currentIndexChanged.connect(self.chart_selected); lower.addWidget(self.chart_combo,1)
        self.chart_status=QLabel('CHART DIRECTORY: NOT SELECTED'); self.chart_status.setObjectName('smallStatus'); lower.addWidget(self.chart_status); ll.addLayout(lower)
        self.nav_strip=QFrame(); self.nav_strip.setObjectName('panel'); nv=QHBoxLayout(self.nav_strip); nv.setContentsMargins(7,3,7,3); nv.setSpacing(12); self.nav_labels={}
        for k in ['ROUTE','NEXT WP','DTW','BTW','XTE','SOG','TTG','ETA']:
            lab=QLabel(k+' · —'); lab.setStyleSheet('font-size:11px;font-weight:800;'); self.nav_labels[k]=lab; nv.addWidget(lab)
        nv.addStretch(); self.nav_strip.hide(); ll.addWidget(self.nav_strip)
        self.alert_strip=QLabel('NAV ALERTS · READY'); self.alert_strip.setObjectName('smallStatus'); self.alert_strip.setStyleSheet('padding:3px 7px;background:#091c25;border:1px solid #244c5c;color:#9bc2cf;'); ll.addWidget(self.alert_strip)
        body.addWidget(self.left,7)
        self.side=QScrollArea(); self.side.setWidgetResizable(True); self.side.setMaximumWidth(285); self.side.setFrameShape(QFrame.NoFrame)
        sh=QWidget(); sl=QVBoxLayout(sh); sl.setSpacing(3); self.cards={}
        for a,b,c in [('GNSS','GPS · Galileo · GLONASS · BeiDou','WAITING'),('IMU','KVH / inertial motion','STANDBY'),('INS','Dead reckoning','STANDBY'),('LOG SPEED','Speed through water','STANDBY'),('LiDAR','Local positioning','STANDBY'),('VISION','Visual positioning','STANDBY'),('RADAR','Radar positioning','STANDBY'),('AI POSITIONING SYSTEM','Fused final position','START POSITION')]:
            card=PositionSourceCard(a,b,c); self.cards[a]=card; sl.addWidget(card)
        self.final=QFrame(); self.final.setObjectName('panel'); fl=QGridLayout(self.final); self.final_labels={}
        for r,(a,b) in enumerate([('FINAL POSITION',f'UTM {self.canvas.zone}{self.canvas.hemisphere}'),('EASTING',f'{self.canvas.easting:,.2f} m'),('NORTHING',f'{self.canvas.northing:,.2f} m'),('LAT / LON',f'{self.canvas.vessel_lat:.6f} / {self.canvas.vessel_lon:.6f}'),('HEADING','000.0°'),('SPEED','0.0 kn'),('CONFIDENCE','START POSITION'),('SOURCE','MINA ZAYED / GNSS WAITING')]):
            x=QLabel(a); x.setObjectName('smallStatus'); y=QLabel(b); y.setStyleSheet('font-weight:800;'); fl.addWidget(x,r,0); fl.addWidget(y,r,1); self.final_labels[a]=y
        sl.addWidget(self.final); sl.addStretch(); self.side.setWidget(sh); body.addWidget(self.side,2); root.addLayout(body,1)
        self.maximized=False; self.restore_chart_directory()
        try: self.canvas.load_world_basemap(reset_view=True)
        except Exception as ex: self.canvas.set_chart_name('WORLD BASE MAP LOAD ERROR: '+str(ex))
        self._load_marks(); self._start_nmea_udp()
        # Full-screen escape shortcuts must work even when the map or another child owns keyboard focus.
        self._esc_full=QShortcut(QKeySequence('Esc'),self.main_window); self._esc_full.setContext(Qt.ApplicationShortcut); self._esc_full.activated.connect(self.exit_fullscreen)
        self._f11_full=QShortcut(QKeySequence('F11'),self.main_window); self._f11_full.setContext(Qt.ApplicationShortcut); self._f11_full.activated.connect(self.toggle_maximize)
        self.exit_full_btn=QPushButton('EXIT FULL',self.left); self.exit_full_btn.setFixedSize(92,34); self.exit_full_btn.setStyleSheet('QPushButton{background:#7d1c24;border:1px solid #ef6b75;color:white;font-weight:900;border-radius:7px;}'); self.exit_full_btn.clicked.connect(self.exit_fullscreen); self.exit_full_btn.hide()
        self._active_route_speed_mode='ACTUAL'; self._anchor_watch=None

    def _start_nmea_udp(self):
        """Listen for iPhone/external NMEA0183 GNSS over UDP 10110."""
        self._nmea_heading=None; self._last_gnss_rx=0.0; self._gnss_sats=None; self._gnss_hdop=None
        try:
            self._nmea_sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            self._nmea_sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            self._nmea_sock.bind(('0.0.0.0',10110)); self._nmea_sock.setblocking(False)
            self._nmea_timer=QTimer(self); self._nmea_timer.timeout.connect(self._poll_nmea_udp); self._nmea_timer.timeout.connect(self._check_gnss_timeout); self._nmea_timer.start(100)
            self.cards['GNSS'].set_status('UDP 10110 · WAITING',False)
        except Exception as ex:
            self.cards['GNSS'].set_status('UDP ERROR · '+str(ex),False)

    @staticmethod
    def _nmea_coord(value,hemi):
        if not value: return None
        v=float(value); deg=int(v//100); minutes=v-deg*100; out=deg+minutes/60.0
        return -out if hemi in ('S','W') else out

    @staticmethod
    def _ais_payload_bits(payload,fill=0):
        bits=''
        for ch in payload:
            v=ord(ch)-48
            if v>40: v-=8
            bits+=format(v,'06b')
        return bits[:-fill] if fill else bits

    @staticmethod
    def _ais_uint(bits,a,b): return int(bits[a:b],2) if len(bits)>=b else 0
    @staticmethod
    def _ais_sint(bits,a,b):
        v=int(bits[a:b],2) if len(bits)>=b else 0; n=b-a
        return v-(1<<n) if v & (1<<(n-1)) else v

    def _parse_aivdm(self,line):
        try:
            f=line.split('*',1)[0].split(',')
            if len(f)<7 or f[1]!='1': return
            payload=f[5]; fill=int(f[6] or 0); bits=self._ais_payload_bits(payload,fill); typ=self._ais_uint(bits,0,6); mmsi=self._ais_uint(bits,8,38)
            if typ in (1,2,3):
                sog=self._ais_uint(bits,50,60)/10.0; lon=self._ais_sint(bits,61,89)/600000.0; lat=self._ais_sint(bits,89,116)/600000.0; cog=self._ais_uint(bits,116,128)/10.0; hdg=self._ais_uint(bits,128,137)
            elif typ==18:
                sog=self._ais_uint(bits,46,56)/10.0; lon=self._ais_sint(bits,57,85)/600000.0; lat=self._ais_sint(bits,85,112)/600000.0; cog=self._ais_uint(bits,112,124)/10.0; hdg=self._ais_uint(bits,124,133)
            else: return
            if abs(lat)>90 or abs(lon)>180 or (abs(lat)<1e-9 and abs(lon)<1e-9): return
            t=self.canvas.ais_targets.get(mmsi,{'mmsi':mmsi,'name':''}); t.update({'lat':lat,'lon':lon,'sog':0.0 if sog>=102.3 else sog,'cog':0.0 if cog>=360 else cog,'heading':(cog if hdg>=511 else hdg),'rx_time':time.time(),'source':'LOCAL AIS NMEA'})
            self.canvas.ais_targets[mmsi]=t
        except Exception: pass

    def _poll_nmea_udp(self):
        try:
            while True:
                data,_addr=self._nmea_sock.recvfrom(8192)
                text=data.decode('ascii',errors='ignore')
                for line in text.replace('\r','\n').split('\n'):
                    line=line.strip()
                    if line.startswith('!AIVDM') or line.startswith('!AIVDO'):
                        self._parse_aivdm(line); continue
                    if not line.startswith('$'): continue
                    f=line.split('*',1)[0].split(','); sentence=f[0][-3:]
                    if sentence=='HDT' and len(f)>1:
                        try:
                            self._nmea_heading=float(f[1])%360.0
                            # Heading is updated at HDT rate, independently of slower position RMC updates.
                            self.canvas.heading=self._nmea_heading; self.final_labels['HEADING'].setText(f'{self._nmea_heading:05.1f}°'); self.canvas.update()
                        except Exception: pass
                    elif sentence=='GGA' and len(f)>=9:
                        try:
                            self._gnss_sats=int(f[7]) if f[7] else None
                            self._gnss_hdop=float(f[8]) if f[8] else None
                        except Exception: pass
                    elif sentence=='RMC' and len(f)>=9 and f[2]=='A':
                        try:
                            lat=self._nmea_coord(f[3],f[4]); lon=self._nmea_coord(f[5],f[6])
                            speed=float(f[7]) if f[7] else 0.0
                            course=None
                            if f[8]:
                                c=float(f[8]); course=(c%360.0) if c>=0 else None
                            if lat is not None and lon is not None:
                                self._last_gnss_rx=time.time(); self.apply_gnss_fix(lat,lon,self._nmea_heading,speed,course)
                                details=[]
                                if self._gnss_sats is not None: details.append(f'{self._gnss_sats} SAT')
                                if self._gnss_hdop is not None: details.append(f'HDOP {self._gnss_hdop:.1f}')
                                self.cards['GNSS'].sub.setText('MULTI-GNSS AUTO · '+(' · '.join(details) if details else 'NMEA'))
                        except Exception: pass
        except BlockingIOError: pass
        except Exception: pass

    def _check_gnss_timeout(self):
        try:
            if self._last_gnss_rx>0 and time.time()-self._last_gnss_rx>3.0 and self.canvas.gnss_live:
                self.canvas.set_gnss_lost(); self.cards['GNSS'].set_status('GNSS LOST',False)
                self.mode.setText('POSITION MODE · GNSS LOST · DR STANDBY'); self.canvas.update()
        except Exception: pass

    def settings_path(self): return DATA_DIR/'positioning_settings.json'
    def route_dir(self): d=DATA_DIR/'route_history'; d.mkdir(parents=True,exist_ok=True); return d
    def track_dir(self): d=DATA_DIR/'track_history'; d.mkdir(parents=True,exist_ok=True); return d
    def marks_path(self): return DATA_DIR/'marine_marks.json'

    def _load_marks(self):
        try:
            if self.marks_path().exists(): self.canvas.marine_marks=json.loads(self.marks_path().read_text())
        except Exception: self.canvas.marine_marks=[]

    def _save_marks(self):
        try: self.marks_path().write_text(json.dumps(self.canvas.marine_marks,indent=2))
        except Exception: pass

    def restore_chart_directory(self):
        try:
            d=json.loads(self.settings_path().read_text()).get('chart_directory')
            if d and Path(d).is_dir(): self.load_chart_directory(Path(d))
        except Exception: pass

    def load_world_map(self):
        try:
            n=self.canvas.load_world_basemap(reset_view=False)
            # WORLD MAP means show the whole base without moving the vessel itself.
            self.canvas.world_center_lon=0.0; self.canvas.world_center_lat=10.0; self.canvas.world_zoom=1.0; self.canvas.follow_vessel=False
            self.canvas.set_chart_name(f'NATURAL EARTH WORLD VECTOR BASE · {n} POLYGON RINGS' + (f' + {self.canvas.vector_chart_name}' if self.canvas.vector_chart_name else ''))
        except Exception as ex: QMessageBox.warning(self,'WORLD BASE MAP ERROR',str(ex))

    def recenter_vessel(self): self.canvas.recenter_vessel()

    def choose_chart_directory(self):
        d=QFileDialog.getExistingDirectory(self,'Select Marine Chart Directory',str(Path.home()))
        if d: self.load_chart_directory(Path(d))

    @staticmethod
    def _is_s57_base(f):
        return f.suffix.lower() in {'.000','.s57','.enc'}

    def load_chart_directory(self,path):
        self.chart_dir=path
        try: self.chart_files=sorted([x for x in path.rglob('*') if x.is_file() and (x.suffix.lower() in self.CHART_EXTENSIONS or x.name.upper() in ('CHRLIST.BIN','SERIALNO.TXT'))])[:10000]
        except Exception: self.chart_files=[]
        self.chart_combo.blockSignals(True); self.chart_combo.clear(); self.chart_combo.addItem('WORLD BASE MAP · NO ENC SELECTED',None)
        if any(x.suffix.lower() in {'.a','.b','.c','.d','.e','.f','.g','.z'} for x in self.chart_files): self.chart_combo.addItem('CM93 CHART DATABASE',str(path))
        for f in self.chart_files[:2000]:
            if self._is_s57_base(f) or f.suffix.lower() in {'.geojson','.json'}: self.chart_combo.addItem(f.name,str(f))
        self.chart_combo.blockSignals(False)
        base_count=sum(1 for f in self.chart_files if self._is_s57_base(f)); upd_count=sum(1 for f in self.chart_files if re.fullmatch(r'\.\d{3}',f.suffix.lower()) and f.suffix.lower()!='.000')
        self.chart_status.setText(f'{path} · S-57 BASE CELLS {base_count} · UPDATES {upd_count} HIDDEN')
        try: self.settings_path().write_text(json.dumps({'chart_directory':str(path)},indent=2))
        except Exception: pass

    def chart_cache_dir(self): d=DATA_DIR/'chart_cache'; d.mkdir(parents=True,exist_ok=True); return d

    def convert_s57_to_geojson(self,path):
        p=Path(path)
        if re.fullmatch(r'\.\d{3}',p.suffix.lower()) and p.suffix.lower()!='.000':
            raise RuntimeError('Select the S-57 base cell (.000). Update files (.001/.002/...) are applied by GDAL to the base cell and are not standalone charts.')
        ogr2=shutil.which('ogr2ogr'); ogri=shutil.which('ogrinfo')
        if not ogr2 or not ogri: raise RuntimeError('S-57 support requires GDAL tools. Re-run install.sh to install gdal-bin.')
        cache=self.chart_cache_dir(); merged=cache/(p.stem+'_s57_merged.geojson')
        # Open ONLY the .000 base cell. GDAL applies matching S-57 update files automatically.
        cp=subprocess.run([ogri,'-ro','-so',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=90)
        if cp.returncode!=0: raise RuntimeError((cp.stderr or cp.stdout or 'Unable to inspect S-57 ENC')[-1500:])
        layers=[]
        for line in cp.stdout.splitlines():
            m=re.match(r'\s*\d+:\s*([A-Za-z0-9_]+)',line)
            if m: layers.append(m.group(1))
        if not layers: raise RuntimeError('GDAL opened the file but found no S-57 feature layers.')
        features=[]
        for i,layer in enumerate(layers):
            tmp=cache/(p.stem+f'_{i}_{layer}.geojson')
            c=subprocess.run([ogr2,'-f','GeoJSON',str(tmp),str(p),layer,'-skipfailures'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
            if c.returncode==0 and tmp.exists():
                try:
                    obj=json.loads(tmp.read_text(errors='ignore'))
                    for f in obj.get('features',[]): f.setdefault('properties',{})['_S57_LAYER']=layer
                    features.extend(obj.get('features',[]))
                except Exception: pass
                try: tmp.unlink()
                except Exception: pass
        if not features: raise RuntimeError('S-57 cell opened, but no drawable features could be exported.')
        merged.write_text(json.dumps({'type':'FeatureCollection','features':features})); return merged

    def load_chart_path(self,path):
        p=Path(str(path))
        if not p.exists(): QMessageBox.warning(self,'CHART LOAD ERROR',f'Chart file not found:\n{p}'); return False
        try:
            ext=p.suffix.lower()
            if ext in {'.geojson','.json'}: gj=p; prefix='VECTOR CHART'
            elif ext in {'.000','.s57','.enc'}: gj=self.convert_s57_to_geojson(p); prefix='S-57 ENC'
            elif re.fullmatch(r'\.\d{3}',ext):
                QMessageBox.information(self,'S-57 UPDATE FILE',f'{p.name} is an ENC update, not a standalone chart.\n\nSelect {p.stem}.000 instead.'); return False
            else:
                QMessageBox.information(self,'CHART FORMAT',f'{p.name}\n\nV9.0 overlays S-57 ENC and GeoJSON on the permanent world base map. CM93 remains detection-only.'); return False
            n=self.canvas.load_geojson_chart(gj); self.canvas.vector_chart_name=p.name; self.canvas.fit_vector_chart()
            self.canvas.set_chart_name(f'WORLD BASE + {prefix} · {p.name} · {n} FEATURES')
            return True
        except Exception as ex: QMessageBox.warning(self,'CHART LOAD ERROR',str(ex)); return False

    def load_demo_chart(self):
        demo=APP_DIR/'charts'/'DRBOAT_DEMO_VECTOR.geojson'
        if not demo.exists(): QMessageBox.warning(self,'DEMO CHART','Bundled demo vector file is missing.'); return False
        ok=self.load_chart_path(demo)
        if ok: self.canvas.set_chart_name('WORLD BASE + DR BOAT DEMO VECTOR · TEST ONLY')
        return ok

    def chart_selected(self,idx):
        data=self.chart_combo.itemData(idx)
        if not data: return
        p=Path(str(data))
        if p.is_dir(): QMessageBox.information(self,'CM93 DATABASE','CM93 files are detected but not decoded. Load an S-57 .000 cell or GeoJSON.'); return
        self.load_chart_path(p)

    def show_chart_manager(self):
        d=QDialog(self); d.setWindowTitle(f'DR BOAT VECTOR CHART MANAGER · V{APP_VERSION}'); d.resize(800,560)
        lay=QVBoxLayout(d); info=QLabel('S-57 base cells (.000) and GeoJSON are selectable. ENC update files (.001/.002/...) are hidden and automatically belong to their .000 base cell. Loaded charts remain geographic overlays on the permanent world map.')
        info.setWordWrap(True); lay.addWidget(info); lst=QListWidget(); lay.addWidget(lst,1)
        cm=base=updates=geo=0
        for f in self.chart_files:
            ext=f.suffix.lower(); typ=None
            if ext in {'.a','.b','.c','.d','.e','.f','.g','.z'}: typ='CM93'; cm+=1
            elif self._is_s57_base(f): typ='S-57 ENC'; base+=1
            elif re.fullmatch(r'\.\d{3}',ext): updates+=1; continue
            elif ext in {'.geojson','.json'}: typ='GeoJSON'; geo+=1
            if typ:
                item=QListWidgetItem(f'[{typ}]  {f.name}'); item.setToolTip(str(f)); item.setData(Qt.UserRole,str(f)); lst.addItem(item)
            if lst.count()>=1500: break
        stats=QLabel(f'Detected: CM93 cells {cm} · S-57 BASE cells {base} · S-57 updates {updates} hidden · GeoJSON {geo}'); stats.setObjectName('smallStatus'); lay.addWidget(stats)
        row=QHBoxLayout(); load=QPushButton('LOAD SELECTED CHART'); demo=QPushButton('LOAD DEMO VECTOR'); add=QPushButton('ADD / CHANGE DIRECTORY'); close=QPushButton('CLOSE')
        def do_load(item=None):
            it=item or lst.currentItem()
            if not it: QMessageBox.information(d,'CHART MANAGER','Select a chart first.'); return
            fp=it.data(Qt.UserRole); ext=Path(fp).suffix.lower()
            if ext in {'.a','.b','.c','.d','.e','.f','.g','.z'}: QMessageBox.information(d,'CM93','CM93 is detection-only in V9.0. Select an S-57 .000 cell.'); return
            if self.load_chart_path(fp): d.accept()
        load.clicked.connect(lambda:do_load()); lst.itemDoubleClicked.connect(do_load); demo.clicked.connect(lambda:(d.accept(),self.load_demo_chart())); add.clicked.connect(lambda:(d.accept(),self.choose_chart_directory())); close.clicked.connect(d.accept)
        row.addWidget(load); row.addWidget(demo); row.addWidget(add); row.addStretch(); row.addWidget(close); lay.addLayout(row); d.exec_()

    def start_route(self):
        self.canvas.route=[]; self.canvas.set_tool('ROUTE'); QMessageBox.information(self,'DRAW ROUTE','Click WP1, WP2, WP3… then double-click the final waypoint.\nAfter finishing, the professional Voyage Dashboard opens. Waypoints can then be dragged with the mouse.')

    def _route_metrics(self,route):
        legs=[]; total=0.0
        for i in range(len(route)-1):
            d,b=self.canvas.dist_bearing(route[i],route[i+1]); total+=d; legs.append((i+1,i+2,d,b))
        return total,legs

    def route_changed(self,route):
        self.canvas.route=route[:]
        if hasattr(self,'_active_route_path') and self._active_route_path: self.canvas.update()

    def _route_record(self,name,route,speed_kn=8.0):
        total,legs=self._route_metrics(route)
        return {'name':name,'created':datetime.now().isoformat(timespec='seconds'),'updated':datetime.now().isoformat(timespec='seconds'),'zone':self.canvas.zone,'hemisphere':self.canvas.hemisphere,'planned_speed_kn':float(speed_kn),'waypoints':[{'wp':i+1,'easting':q[0],'northing':q[1]} for i,q in enumerate(route)],'total_m':total,'total_nm':total/1852.0,'legs':[{'from':a,'to':b,'distance_m':d,'distance_nm':d/1852.0,'bearing':brg} for a,b,d,brg in legs]}

    def route_finished(self,route):
        name,ok=QInputDialog.getText(self,'SAVE VOYAGE','Voyage / route name:')
        if not ok or not name.strip(): name='Route '+datetime.now().strftime('%Y-%m-%d %H:%M')
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); path=self.route_dir()/f'route_{stamp}.json'; rec=self._route_record(name.strip(),route,8.0); path.write_text(json.dumps(rec,indent=2)); self._active_route_path=path
        self.show_voyage_dashboard(path)

    def show_voyage_dashboard(self,path=None):
        path=Path(path) if path else getattr(self,'_active_route_path',None)
        if not path or not Path(path).exists(): return
        rec=json.loads(Path(path).read_text()); route=[(w['easting'],w['northing']) for w in rec.get('waypoints',[])]; self.canvas.route=route; self._active_route_path=Path(path)
        d=QDialog(self); d.setWindowTitle('DR BOAT · VOYAGE / ROUTE DASHBOARD'); d.resize(850,560); lay=QVBoxLayout(d)
        top=QGridLayout(); name=QLineEdit(rec.get('name','Route')); speed=QDoubleSpinBox(); speed.setRange(0.1,60.0); speed.setDecimals(1); speed.setSuffix(' kn'); speed.setValue(float(rec.get('planned_speed_kn',8.0)))
        total_lbl=QLabel(); duration_lbl=QLabel(); eta_lbl=QLabel(); wp_lbl=QLabel();
        for w in (total_lbl,duration_lbl,eta_lbl,wp_lbl): w.setStyleSheet('font-size:15px;font-weight:800;')
        top.addWidget(QLabel('VOYAGE NAME'),0,0); top.addWidget(name,0,1); top.addWidget(QLabel('PLANNED SPEED'),0,2); top.addWidget(speed,0,3)
        top.addWidget(total_lbl,1,0); top.addWidget(duration_lbl,1,1); top.addWidget(eta_lbl,1,2,1,2); top.addWidget(wp_lbl,2,0,1,2); lay.addLayout(top)
        table=QTableWidget(); table.setColumnCount(5); table.setHorizontalHeaderLabels(['LEG','DISTANCE NM','BEARING','TIME','WAYPOINT']); table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); lay.addWidget(table,1)
        def recalc():
            total,legs=self._route_metrics(self.canvas.route); sp=max(.1,speed.value()); hours=(total/1852.0)/sp; eta=datetime.now().timestamp()+hours*3600; eta_dt=datetime.fromtimestamp(eta)
            total_lbl.setText(f'TOTAL · {total/1852.0:.2f} NM'); duration_lbl.setText(f'DURATION · {int(hours):02d}h {int((hours%1)*60):02d}m'); eta_lbl.setText('ETA · '+eta_dt.strftime('%d %b %Y · %H:%M')); wp_lbl.setText(f'WAYPOINTS · {len(self.canvas.route)} · Drag any WP on the map to edit')
            table.setRowCount(len(legs))
            for r,(a,b,dist,brg) in enumerate(legs):
                leg_h=(dist/1852.0)/sp; vals=[f'WP{a} → WP{b}',f'{dist/1852.0:.3f}',f'{brg:.1f}°',f'{int(leg_h*60):d} min',f'WP{b}']
                for c,v in enumerate(vals): table.setItem(r,c,QTableWidgetItem(v))
        speed.valueChanged.connect(recalc); recalc()
        row=QHBoxLayout(); save=QPushButton('SAVE CHANGES'); close=QPushButton('CLOSE'); row.addWidget(save); row.addStretch(); row.addWidget(close); lay.addLayout(row)
        def save_changes():
            newrec=self._route_record(name.text().strip() or rec.get('name','Route'),self.canvas.route,speed.value()); Path(path).write_text(json.dumps(newrec,indent=2)); QMessageBox.information(d,'VOYAGE','Voyage plan saved. ETA and leg data recalculated.')
        save.clicked.connect(save_changes); close.clicked.connect(d.accept); d.exec_()

    def show_route_library(self):
        d=QDialog(self); d.setWindowTitle('DR BOAT · ROUTE / VOYAGE LIBRARY'); d.resize(720,480); lay=QVBoxLayout(d); lst=QListWidget(); lay.addWidget(lst,1)
        files=sorted(self.route_dir().glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)
        for f in files:
            try: r=json.loads(f.read_text()); txt=f"{r.get('name',f.stem)}   ·   {r.get('total_nm',0):.2f} NM   ·   {r.get('planned_speed_kn',8):.1f} kn" 
            except Exception: txt=f.stem
            it=QListWidgetItem(txt); it.setData(Qt.UserRole,str(f)); lst.addItem(it)
        row=QHBoxLayout(); op=QPushButton('OPEN / EDIT'); ren=QPushButton('RENAME'); dup=QPushButton('DUPLICATE'); dele=QPushButton('DELETE'); close=QPushButton('CLOSE')
        for b in (op,ren,dup,dele): row.addWidget(b)
        row.addStretch(); row.addWidget(close); lay.addLayout(row)
        def current(): return Path(lst.currentItem().data(Qt.UserRole)) if lst.currentItem() else None
        def open_it():
            f=current();
            if f: d.accept(); self.show_voyage_dashboard(f)
        def rename_it():
            f=current();
            if not f:return
            r=json.loads(f.read_text()); n,ok=QInputDialog.getText(d,'Rename Voyage','Name:',text=r.get('name',f.stem));
            if ok and n.strip(): r['name']=n.strip(); f.write_text(json.dumps(r,indent=2)); d.accept(); self.show_route_library()
        def duplicate_it():
            f=current();
            if not f:return
            r=json.loads(f.read_text()); r['name']=r.get('name','Route')+' COPY'; nf=self.route_dir()/('route_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_copy.json'); nf.write_text(json.dumps(r,indent=2)); d.accept(); self.show_route_library()
        def delete_it():
            f=current();
            if f and QMessageBox.question(d,'Delete Voyage',f'Delete {f.name}?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes: f.unlink(); d.accept(); self.show_route_library()
        op.clicked.connect(open_it); lst.itemDoubleClicked.connect(lambda _x:open_it()); ren.clicked.connect(rename_it); dup.clicked.connect(duplicate_it); dele.clicked.connect(delete_it); close.clicked.connect(d.accept); d.exec_()

    def toggle_track(self):
        if not self.track_recording:
            self.track_recording=True; self.canvas.track=[]; self._track_samples=[]; self.canvas.show_track=True; self._track_started=time.time(); QMessageBox.information(self,'TRACK','Track recording started. Press TRACK again to stop and save.')
        else:
            self.track_recording=False; stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); pts=self.canvas.track[:]; total=sum(self.canvas.dist_bearing(pts[i-1],pts[i])[0] for i in range(1,len(pts))); dur=max(0,time.time()-getattr(self,'_track_started',time.time())); avg=(total/1852.0)/(dur/3600.0) if dur>1 else 0
            name,ok=QInputDialog.getText(self,'SAVE TRACK','Track name:'); name=(name.strip() if ok and name.strip() else 'Track '+datetime.now().strftime('%Y-%m-%d %H:%M'))
            path=self.track_dir()/f'track_{stamp}.json'; samples=getattr(self,'_track_samples',[]); path.write_text(json.dumps({'name':name,'created':datetime.now().isoformat(timespec='seconds'),'duration_s':dur,'distance_m':total,'distance_nm':total/1852.0,'average_speed_kn':avg,'points':samples or [{'easting':p[0],'northing':p[1]} for p in pts]},indent=2)); QMessageBox.information(self,'TRACK',f'Track saved.\nDistance {total/1852.0:.2f} NM · Duration {dur/60:.0f} min')

    def show_track_library(self):
        d=QDialog(self); d.setWindowTitle('DR BOAT · TRACK LIBRARY / HISTORY'); d.resize(680,450); lay=QVBoxLayout(d); lst=QListWidget(); lay.addWidget(lst,1)
        for f in sorted(self.track_dir().glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True):
            try:r=json.loads(f.read_text()); txt=f"{r.get('name',f.stem)} · {r.get('distance_nm',0):.2f} NM · {r.get('duration_s',0)/60:.0f} min"
            except Exception: txt=f.stem
            it=QListWidgetItem(txt); it.setData(Qt.UserRole,str(f)); lst.addItem(it)
        row=QHBoxLayout(); show=QPushButton('SHOW'); hide=QPushButton('HIDE TRACK'); dele=QPushButton('DELETE'); close=QPushButton('CLOSE'); row.addWidget(show); row.addWidget(hide); row.addWidget(dele); row.addStretch(); row.addWidget(close); lay.addLayout(row)
        def cur(): return Path(lst.currentItem().data(Qt.UserRole)) if lst.currentItem() else None
        def show_it():
            f=cur();
            if not f:return
            r=json.loads(f.read_text()); self.canvas.track=[(q['easting'],q['northing']) for q in r.get('points',[]) if 'easting' in q and 'northing' in q]; self.canvas.show_track=True; self.canvas.update(); d.accept()
        def del_it():
            f=cur();
            if f and QMessageBox.question(d,'Delete Track',f'Delete {f.name}?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:f.unlink(); d.accept(); self.show_track_library()
        show.clicked.connect(show_it); lst.itemDoubleClicked.connect(lambda _x:show_it()); hide.clicked.connect(lambda:(setattr(self.canvas,'show_track',False),self.canvas.update())); dele.clicked.connect(del_it); close.clicked.connect(d.accept); d.exec_()

    def add_marine_mark(self):
        self.canvas.set_tool('MARK'); QMessageBox.information(self,'MARINE MARK','Click the map where you want the mark. Double-click it afterward to view/edit its details and coordinates.')

    def show_mark_info(self,mark):
        idx=next((i for i,m in enumerate(self.canvas.marine_marks) if m.get('id')==mark.get('id')),None)
        if idx is None:return
        m=self.canvas.marine_marks[idx]; z,h,e,n=latlon_to_utm(m['lat'],m['lon']); d=QDialog(self); d.setWindowTitle('MARINE MARK DETAILS'); lay=QGridLayout(d)
        name=QLineEdit(m.get('name','')); sym=QComboBox(); sym.addItems(['MARK','BUOY','BEACON','ANCHORAGE','PILOT','DANGER','WRECK','BERTH','REPORTING POINT']); sym.setCurrentText(m.get('symbol','MARK')); notes=QLineEdit(m.get('notes',''))
        lay.addWidget(QLabel('NAME'),0,0); lay.addWidget(name,0,1); lay.addWidget(QLabel('SYMBOL'),1,0); lay.addWidget(sym,1,1); lay.addWidget(QLabel(f'LAT / LON  {m["lat"]:.7f} / {m["lon"]:.7f}'),2,0,1,2); lay.addWidget(QLabel(f'UTM {z}{h}  E {e:.2f}  N {n:.2f}'),3,0,1,2); lay.addWidget(QLabel('NOTES'),4,0); lay.addWidget(notes,4,1)
        save=QPushButton('SAVE'); dele=QPushButton('DELETE'); close=QPushButton('CLOSE'); lay.addWidget(save,5,0); lay.addWidget(dele,5,1); lay.addWidget(close,6,0,1,2)
        def save_it(): m['name']=name.text().strip() or 'Mark'; m['symbol']=sym.currentText(); m['notes']=notes.text(); self._save_marks(); self.canvas.update(); d.accept()
        def del_it(): self.canvas.marine_marks.pop(idx); self._save_marks(); self.canvas.update(); d.accept()
        save.clicked.connect(save_it); dele.clicked.connect(del_it); close.clicked.connect(d.accept); d.exec_()

    def set_display_mode(self,mode):
        self.canvas.set_display_mode(mode)

    def toggle_lidar(self):
        self.canvas.toggle_lidar(); self.cards['LiDAR'].set_status(('SIMULATION · %.0f m'%self.canvas.lidar_range_m) if self.canvas.lidar_enabled else 'STANDBY',self.canvas.lidar_enabled)

    def toggle_heading_vector(self): self.canvas.toggle_heading_vector()
    def toggle_range_rings(self): self.canvas.toggle_range_rings()

    def route_action(self,action):
        if action in ('ACTIVATE','FOLLOW'):
            self.canvas.active_route=True; self.canvas.route_follow=True; self.nav_strip.show(); self.alert_strip.setText('NAV ALERTS · ACTIVE ROUTE · MONITORING')
        elif action=='DEACTIVATE':
            self.canvas.active_route=False; self.canvas.route_follow=False; self.nav_strip.hide(); self.alert_strip.setText('NAV ALERTS · READY')
        elif action=='PROPERTIES':
            p=getattr(self,'_active_route_path',None)
            if p and Path(p).exists(): self.show_voyage_dashboard(p)
            else: QMessageBox.information(self,'ROUTE','This route has not been saved yet. Finish/save it first.')
        elif action=='REVERSE':
            self.alert_strip.setText('NAV ALERTS · ROUTE REVERSED')
        self.canvas.update()

    def _active_route_nav(self):
        if not self.canvas.active_route or len(self.canvas.route)<2: return
        own=(self.canvas.easting,self.canvas.northing); route=self.canvas.route
        # Pick nearest upcoming waypoint by distance; simple V9 navigator, no helm output.
        dists=[self.canvas.dist_bearing(own,q)[0] for q in route]
        idx=min(range(len(route)),key=lambda i:dists[i]);
        if idx==0 and len(route)>1: idx=1
        target=route[idx]; dtw,btw=self.canvas.dist_bearing(own,target)
        rem=dtw
        for i in range(idx,len(route)-1): rem+=self.canvas.dist_bearing(route[i],route[i+1])[0]
        sog=max(0.0,self.canvas.speed); ttg_h=(rem/1852.0)/sog if sog>=0.2 else None
        eta=(datetime.fromtimestamp(time.time()+ttg_h*3600).strftime('%H:%M') if ttg_h is not None else '—')
        # XTE relative to previous leg.
        xte=0.0
        if idx>0:
            a=route[idx-1]; b=target; vx,vy=b[0]-a[0],b[1]-a[1]; vv=vx*vx+vy*vy
            if vv>1e-6: xte=((own[0]-a[0])*vy-(own[1]-a[1])*vx)/math.sqrt(vv)
        vals={'ROUTE':'ACTIVE','NEXT WP':f'WP{idx+1}','DTW':f'{dtw/1852.0:.2f} NM','BTW':f'{btw:.1f}°','XTE':f'{xte:.0f} m','SOG':f'{sog:.1f} kn','TTG':('—' if ttg_h is None else f'{int(ttg_h):02d}:{int((ttg_h%1)*60):02d}'),'ETA':eta}
        for k,v in vals.items(): self.nav_labels[k].setText(f'{k} · {v}')
        if abs(xte)>100: self.alert_strip.setText(f'WARNING · XTE {xte:.0f} m · ACTIVE ROUTE')
        elif not self.canvas.gnss_live: self.alert_strip.setText('WARNING · GNSS LOST · ACTIVE ROUTE HELD')
        else: self.alert_strip.setText('NAV ALERTS · ACTIVE ROUTE · NORMAL')

    def show_safety_tools(self):
        d=QDialog(self); d.setWindowTitle('DR BOAT · SAFETY TOOLS'); d.resize(520,330); l=QVBoxLayout(d)
        l.addWidget(QLabel('Quick safety tools. These are operator aids; official watchkeeping and approved navigation equipment remain primary.'))
        mob=QPushButton('MOB · MARK CURRENT POSITION'); anchor=QPushButton('SET ANCHOR ALERT'); clear=QPushButton('CLEAR ANCHOR ALERT'); close=QPushButton('CLOSE')
        def do_mob():
            m={'id':f'MOB-{int(time.time()*1000)}','name':'MOB '+datetime.now().strftime('%H:%M:%S'),'symbol':'DANGER','lat':self.canvas.vessel_lat,'lon':self.canvas.vessel_lon,'notes':'Man Overboard mark created at own-ship position','created':datetime.now().isoformat(timespec='seconds')}
            self.canvas.marine_marks.append(m); self._save_marks(); self.canvas.show_marks=True; self.canvas.update(); self.alert_strip.setText('EMERGENCY MARK · MOB POSITION SAVED'); d.accept()
        def set_anchor():
            r,ok=QInputDialog.getDouble(d,'ANCHOR ALERT','Alert radius (m):',50.0,5.0,5000.0,1)
            if ok:
                self._anchor_watch={'e':self.canvas.easting,'n':self.canvas.northing,'radius':float(r)}; self.alert_strip.setText(f'ANCHOR ALERT · ARMED · {r:.0f} m'); d.accept()
        def clear_anchor(): self._anchor_watch=None; self.alert_strip.setText('NAV ALERTS · READY'); d.accept()
        mob.clicked.connect(do_mob); anchor.clicked.connect(set_anchor); clear.clicked.connect(clear_anchor); close.clicked.connect(d.accept)
        for b in (mob,anchor,clear,close): l.addWidget(b)
        d.exec_()

    def show_ai_navigation(self):
        d=QDialog(self); d.setWindowTitle('DR BOAT · AI NAVIGATION'); d.resize(680,470); l=QVBoxLayout(d)
        h=QLabel('AI NAVIGATION · OBSERVE → ANALYZE → PREPARE DECISION → EXECUTE'); h.setObjectName('pageTitle'); l.addWidget(h)
        info=QLabel('V9 FOUNDATION MODE · advisory architecture only. No autonomous helm output is enabled.'); info.setWordWrap(True); l.addWidget(info)
        g=QGridLayout(); rows=[('POSITION', 'GNSS / INS / AI Positioning System'),('PERCEPTION','LiDAR / Vision / Radar'),('TRAFFIC','AIS / Fleet / CPA-TCPA'),('ROUTE','Active Route / XTE / ETA'),('DECISION','ADVISORY ONLY'),('EXECUTION','LOCKED · AUTOPILOT IS SEPARATE')]
        for r,(a,b) in enumerate(rows): g.addWidget(QLabel(a),r,0); q=QLabel(b); q.setStyleSheet('font-weight:800;'); g.addWidget(q,r,1)
        l.addLayout(g); l.addStretch(); c=QPushButton('CLOSE'); c.clicked.connect(d.accept); l.addWidget(c); d.exec_()

    def show_autopilot(self):
        d=QDialog(self); d.setWindowTitle('DR BOAT · AUTOPILOT · HEADING HOLD'); d.resize(650,520); l=QVBoxLayout(d)
        warn=QLabel('SIMULATION / CALIBRATION FOUNDATION · NO MOTOR-CONTROLLER OUTPUT IN V9.0'); warn.setStyleSheet('font-weight:900;color:#f2c35b;padding:8px;border:1px solid #7e6b2d;'); warn.setWordWrap(True); l.addWidget(warn)
        g=QGridLayout(); cur=QLabel(f'{self.canvas.heading:05.1f}°'); cur.setStyleSheet('font-size:26px;font-weight:900;'); seth=QDoubleSpinBox(); seth.setRange(0,359.9); seth.setDecimals(1); seth.setSuffix('°'); seth.setValue(self.canvas.heading); err=QLabel('0.0°'); out=QLabel('STANDBY')
        g.addWidget(QLabel('CURRENT HEADING'),0,0); g.addWidget(cur,0,1); g.addWidget(QLabel('SET HEADING'),1,0); g.addWidget(seth,1,1); g.addWidget(QLabel('HEADING ERROR'),2,0); g.addWidget(err,2,1); g.addWidget(QLabel('STEERING COMMAND PREVIEW'),3,0); g.addWidget(out,3,1); l.addLayout(g)
        def calc():
            e=((seth.value()-self.canvas.heading+540)%360)-180; err.setText(f'{e:+.1f}°'); out.setText('PORT' if e<-.5 else ('STBD' if e>.5 else 'MIDSHIPS'))
        seth.valueChanged.connect(calc); calc()
        cal=QGroupBox('CALIBRATION WIZARD'); cl=QVBoxLayout(cal); cl.addWidget(QLabel('1 · HEADING SENSOR CHECK   →   2 · STEERING DIRECTION / LIMITS   →   3 · RESPONSE / SEA TRIAL')); sim=QPushButton('RUN SAFE SIMULATION CHECK'); sim.clicked.connect(lambda:QMessageBox.information(d,'AUTOPILOT','Simulation check ready. Hardware output remains locked.')); cl.addWidget(sim); l.addWidget(cal)
        row=QHBoxLayout(); standby=QPushButton('STANDBY'); close=QPushButton('CLOSE'); row.addWidget(standby); row.addStretch(); row.addWidget(close); l.addLayout(row); standby.clicked.connect(lambda:out.setText('STANDBY')); close.clicked.connect(d.accept); d.exec_()

    def toggle_ais(self): self.canvas.show_ais=not self.canvas.show_ais; self.canvas.update()
    def toggle_fleet(self): self.canvas.show_fleet=not self.canvas.show_fleet; self.canvas.update()

    def _ais_cpa_tcpa(self,t):
        try:
            z,h,oe,on=latlon_to_utm(self.canvas.vessel_lat,self.canvas.vessel_lon); z2,h2,te,tn=latlon_to_utm(t['lat'],t['lon'])
            if z2!=z or h2!=h: return None,None
            def vel(sog,cog):
                ms=float(sog)*0.514444; a=math.radians(float(cog)); return ms*math.sin(a),ms*math.cos(a)
            ovx,ovy=vel(self.canvas.speed,self.canvas.course); tvx,tvy=vel(t.get('sog',0),t.get('cog',0)); rx,ry=te-oe,tn-on; vx,vy=tvx-ovx,tvy-ovy; vv=vx*vx+vy*vy
            tcpa=0.0 if vv<1e-6 else max(0.0,-(rx*vx+ry*vy)/vv); cpa=math.hypot(rx+vx*tcpa,ry+vy*tcpa)
            return cpa/1852.0,tcpa/60.0
        except Exception:return None,None

    def show_ais_info(self,t):
        age=max(0,time.time()-float(t.get('rx_time',time.time()))); cpa,tcpa=self._ais_cpa_tcpa(t); cpa_txt='—' if cpa is None else f'{cpa:.2f} NM'; tcpa_txt='—' if tcpa is None else f'{tcpa:.1f} min'
        QMessageBox.information(self,'AIS TARGET',f"NAME: {t.get('name') or '—'}\nMMSI: {t.get('mmsi','—')}\nSOG: {t.get('sog',0):.1f} kn\nCOG: {t.get('cog',0):.1f}°\nHEADING: {t.get('heading',0):.1f}°\nCPA: {cpa_txt}\nTCPA: {tcpa_txt}\nLAT/LON: {t.get('lat',0):.6f} / {t.get('lon',0):.6f}\nSOURCE: {t.get('source','AIS')}\nAGE: {age:.0f} s")

    def apply_fleet_position(self,vessel_id,lat,lon,heading=0.0,sog=0.0,status='ONLINE',name=None):
        """Public hook for future fleet telemetry adapters."""
        b=self.main_window.boat_by_id(vessel_id) if self.main_window else None
        if b is not None:
            b.update({'lat':float(lat),'lon':float(lon),'heading':float(heading)%360,'sog':float(sog),'fleet_status':status,'last_update':datetime.now().strftime('%H:%M:%S')})
            if name: b['name']=name

    def show_fleet_info(self,t):
        QMessageBox.information(self,'OUR FLEET',f"{t.get('name',t.get('id','FLEET'))}\nSTATUS: {t.get('status','ONLINE')}\nHEADING: {t.get('heading',0):.1f}°\nSOG: {t.get('sog',0):.1f} kn\nLAT/LON: {t.get('lat',0):.6f} / {t.get('lon',0):.6f}\nLAST UPDATE: {t.get('last_update','LIVE')}")

    def toggle_maximize(self):
        if self.maximized: self.exit_fullscreen(); return
        self.maximized=True
        self.side.hide(); self.tool_rail.hide(); self.chart_status.hide(); self.chart_combo.hide(); self.page_title.hide(); self.mode.hide()
        for w in self._top_controls: w.hide()
        try:
            self.main_window.header.hide(); self.main_window.nav.hide(); self.main_window.showFullScreen()
        except Exception: pass
        self.exit_full_btn.show(); self.exit_full_btn.raise_(); QTimer.singleShot(120,lambda:self.exit_full_btn.move(max(6,self.left.width()-self.exit_full_btn.width()-10),8))
        self.alert_strip.show(); self.alert_strip.setText('FULL NAVIGATION MODE · EXIT FULL / ESC / F11' + (' · ACTIVE ROUTE' if self.canvas.active_route else ''))

    def exit_fullscreen(self):
        if not self.maximized: return
        self.maximized=False
        self.exit_full_btn.hide()
        self.side.show(); self.tool_rail.show(); self.chart_status.show(); self.chart_combo.show(); self.page_title.show(); self.mode.show()
        for w in self._top_controls: w.show()
        try:
            self.main_window.header.show(); self.main_window.nav.show(); self.main_window.showNormal()
        except Exception: pass
        self.alert_strip.setText('NAV ALERTS · ACTIVE ROUTE · MONITORING' if self.canvas.active_route else 'NAV ALERTS · READY')

    def show_coordinate_dialog(self):
        d=QDialog(self); d.setWindowTitle('UTM ↔ LAT / LON'); lay=QGridLayout(d)
        zone=QLineEdit(str(self.canvas.zone)); hemi=QComboBox(); hemi.addItems(['N','S']); e=QLineEdit(f'{self.canvas.easting:.2f}'); n=QLineEdit(f'{self.canvas.northing:.2f}'); out=QLabel(''); btn=QPushButton('CONVERT UTM → LAT / LON')
        lay.addWidget(QLabel('UTM Zone'),0,0); lay.addWidget(zone,0,1); lay.addWidget(hemi,0,2); lay.addWidget(QLabel('Easting (m)'),1,0); lay.addWidget(e,1,1,1,2); lay.addWidget(QLabel('Northing (m)'),2,0); lay.addWidget(n,2,1,1,2); lay.addWidget(btn,3,0,1,3); lay.addWidget(out,4,0,1,3)
        def conv():
            try:
                lat,lon=utm_to_latlon(float(e.text()),float(n.text()),int(zone.text()),hemi.currentText()); out.setText(f'Latitude: {lat:.7f}°\nLongitude: {lon:.7f}°')
            except Exception: out.setText('Invalid coordinate values.')
        btn.clicked.connect(conv); d.exec_()

    def apply_gnss_fix(self,lat,lon,heading=None,speed=None,course=None):
        """Public GNSS adapter hook used by UDP and future physical receivers."""
        self.canvas.set_gnss_fix(lat,lon,heading,speed,course)
        self.mode.setText('POSITION MODE · GNSS LIVE · FOLLOW %s' % ('ON' if self.canvas.follow_vessel else 'OFF'))
        self.cards['GNSS'].set_status('LIVE',True)
        self.final_labels['FINAL POSITION'].setText(f'UTM {self.canvas.zone}{self.canvas.hemisphere}')
        self.final_labels['EASTING'].setText(f'{self.canvas.easting:,.2f} m')
        self.final_labels['NORTHING'].setText(f'{self.canvas.northing:,.2f} m')
        self.final_labels['LAT / LON'].setText(f'{self.canvas.vessel_lat:.6f} / {self.canvas.vessel_lon:.6f}')
        self.final_labels['HEADING'].setText(f'{self.canvas.heading:05.1f}°')
        self.final_labels['SPEED'].setText(f'{self.canvas.speed:.1f} kn')
        self.final_labels['CONFIDENCE'].setText('GNSS LIVE')
        self.final_labels['SOURCE'].setText('NMEA UDP 10110')

    def _refresh_final_labels(self):
        c=self.canvas
        self.final_labels['FINAL POSITION'].setText(f'UTM {c.zone}{c.hemisphere}')
        self.final_labels['EASTING'].setText(f'{c.easting:,.2f} m')
        self.final_labels['NORTHING'].setText(f'{c.northing:,.2f} m')
        self.final_labels['LAT / LON'].setText(f'{c.vessel_lat:.6f} / {c.vessel_lon:.6f}')
        self.final_labels['HEADING'].setText(f'{c.heading:05.1f}°')
        self.final_labels['SPEED'].setText(f'{c.speed:.1f} kn')
        self.final_labels['CONFIDENCE'].setText('GNSS LIVE' if c.gnss_live else 'GNSS WAITING / DR STANDBY')
        self.final_labels['SOURCE'].setText(c.position_source)

    def refresh(self):
        if self.track_recording:
            pt=(self.canvas.easting,self.canvas.northing)
            if not self.canvas.track or self.canvas.dist_bearing(self.canvas.track[-1],pt)[0]>=1.0:
                self.canvas.track.append(pt)
                if not hasattr(self,'_track_samples'): self._track_samples=[]
                self._track_samples.append({'time':datetime.now().isoformat(timespec='milliseconds'),'easting':pt[0],'northing':pt[1],'lat':self.canvas.vessel_lat,'lon':self.canvas.vessel_lon,'sog_kn':self.canvas.speed,'cog_deg':self.canvas.course,'heading_deg':self.canvas.heading})
        # Fleet layer accepts real positions only; no invented operational coordinates.
        ft={}
        for v in FleetPage.VESSELS:
            b=self.main_window.boat_by_id(v['id']) if self.main_window else None
            lat=(b or {}).get('lat',v.get('lat')); lon=(b or {}).get('lon',v.get('lon'))
            if lat is None or lon is None: continue
            ft[v['id']]={'id':v['id'],'name':v['name'],'lat':float(lat),'lon':float(lon),'heading':float((b or {}).get('heading',0)),'sog':float((b or {}).get('sog',0)),'status':(b or {}).get('fleet_status','ONLINE'),'last_update':(b or {}).get('last_update',datetime.now().strftime('%H:%M:%S'))}
        self.canvas.fleet_targets=ft
        self._refresh_final_labels(); self._active_route_nav()
        # Safety overlays: anchor watch and AIS CPA/TCPA warning use live data only.
        if self._anchor_watch is not None:
            drift=math.hypot(self.canvas.easting-self._anchor_watch['e'],self.canvas.northing-self._anchor_watch['n'])
            if drift>self._anchor_watch['radius']:
                self.alert_strip.setText(f'ALARM · ANCHOR DRAG · {drift:.0f} m / LIMIT {self._anchor_watch["radius"]:.0f} m')
        if self.canvas.show_ais and self.canvas.ais_targets:
            best=None
            for t in self.canvas.ais_targets.values():
                cpa,tcpa=self._ais_cpa_tcpa(t)
                if cpa is not None and tcpa is not None and tcpa<=15 and (best is None or cpa<best[0]): best=(cpa,tcpa,t)
            if best and best[0]<0.5:
                self.alert_strip.setText(f'WARNING · AIS CPA {best[0]:.2f} NM · TCPA {best[1]:.1f} min · MMSI {best[2].get("mmsi","—")}')
        self.canvas.update()
        if not self.canvas.gnss_live:
            self.cards['GNSS'].set_status('WAITING FOR RECEIVER',False); self.cards['AI POSITIONING SYSTEM'].set_status('START POSITION · MINA ZAYED',True)

class FleetPage(QWidget):
    VESSELS = [
        {'id':'SEMAIH','name':'M/T SEMAIH','type':'ASD','location':'Mina Zayed','active_map':True},
        {'id':'AL_FANCI','name':'M/T AL FANCI','type':'ASD','location':'Mina Zayed','active_map':True},
        {'id':'SILA','name':'M/T SILA','type':'ASD'},
        {'id':'AL_AIN','name':'M/T AL AIN','type':'ASD'},
        {'id':'DURAH','name':'M/T DURAH','type':'ASD'},
        {'id':'BUTTINA_1','name':'EM/T BUTTINA 1','type':'ASD'},
        {'id':'BUTTINA_2','name':'EM/T BUTTINA 2','type':'ASD'},
        {'id':'KIZAD','name':'M/T KIZAD','type':'ASD'},
        {'id':'DAS','name':'M/T DAS','type':'ASD'},
        {'id':'MARIA','name':'M/T MARIA','type':'ASD'},
        {'id':'MQTA','name':'M/T MQTA','type':'CONVENTIONAL'},
        {'id':'SAFFER_1','name':'P/B SAFFER 1','type':'CONVENTIONAL'},
        {'id':'SAFFER_2','name':'P/B SAFFER 2','type':'CONVENTIONAL'},
        {'id':'SAFFER_3','name':'P/B SAFFER 3','type':'CONVENTIONAL'},
        {'id':'JAWAD_1','name':'Fire Fighting & Security Boat JAWAD 1','type':'CONVENTIONAL','location':'Yas Marina','active_map':True,'firefighting':True},
    ]
    def __init__(self, main_window, parent=None):
        super().__init__(parent); self.main_window=main_window
        root=QVBoxLayout(self); title=QLabel('FLEET LIST · 15 VESSELS'); title.setObjectName('pageTitle'); root.addWidget(title)
        note=QLabel('JAWAD 1 is managed inside Fleet List only. Double-click JAWAD 1 to open its dedicated remote-control screen.'); note.setObjectName('note'); root.addWidget(note)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); body=QWidget(); grid=QGridLayout(body); grid.setSpacing(8)
        for i,v in enumerate(self.VESSELS):
            c=FleetCard(v); c.doubleClicked.connect(self.open_vessel); grid.addWidget(c,i//3,i%3)
        scroll.setWidget(body); root.addWidget(scroll,1)
    def open_vessel(self, vid):
        v=next(x for x in self.VESSELS if x['id']==vid)
        if vid=='JAWAD_1':
            idx=next((i for i,b in enumerate(self.main_window.boats) if b.get('id')=='JAWAD_1'),None)
            if idx is not None: self.main_window.open_focus(idx)
            return
        QMessageBox.information(self, v['name'], f"{v['name']}\nPROPULSION: {v.get('type','—')}\nSTATUS: FLEET PROFILE READY\n\nLive hardware integration will use the vessel-specific profile.")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"DOCTOR BOAT CONTROL · MARINE INTELLIGENCE V{APP_VERSION}")
        self.resize(1100,650)
        self.setMinimumSize(720,480)
        self.recording = {}
        self.system_state = "READY"
        self.voice_text = "Awaiting command"
        self.boats = []
        for i,v in enumerate(FleetPage.VESSELS):
            self.boats.append({"id":v["id"],"name":v["name"],"type":v.get("type","ASD"),"heading":float((35+i*17)%360),"battery":100 if v["id"]=="JAWAD_1" else 90,"link":100 if v.get("active_map") else 92,"port_angle":0,"stbd_angle":0,"port_rpm":0,"stbd_rpm":0})

        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(0,0,0,0)

        header = QFrame(); header.setObjectName("header")
        hl=QHBoxLayout(header)
        logo_path=APP_DIR/"static"/"drboat_logo.png"
        logo=QLabel()
        if logo_path.exists():
            pm=QPixmap(str(logo_path)).scaled(92,92,Qt.KeepAspectRatio,Qt.SmoothTransformation)
            logo.setPixmap(pm)
        hl.addWidget(logo)
        tt=QVBoxLayout()
        a=QLabel("DR.BOAT"); a.setObjectName("brandTitle")
        b=QLabel(f"DOCTOR BOAT CONTROL · MARINE INTELLIGENCE · V{APP_VERSION}"); b.setObjectName("brandSub")
        tt.addWidget(a); tt.addWidget(b)
        hl.addLayout(tt); hl.addStretch()
        ai_badge=QLabel(f"AI MARINE OPERATIONS · V{APP_VERSION}"); ai_badge.setObjectName("aiBadge"); hl.addWidget(ai_badge)

        self.header=header; root.addWidget(header)

        nav=QFrame(); nav.setObjectName("nav")
        nl=QHBoxLayout(nav)
        names = [
            ("COMMAND CENTER",0),
            ("DOCTOR BOAT AI POSITIONING SYSTEM",1),
            ("FLEET CONTROL",2),
            ("AI TRAINING & MANEUVER LIBRARY",3),
            ("PILOT & TUG MASTER TRAINING",4),
            ("SYSTEM / UPDATES",5),
        ]
        for text,idx in names:
            q=QPushButton(text)
            q.clicked.connect(lambda _,i=idx:self.pages.setCurrentIndex(i))
            nl.addWidget(q)
        self.nav=nav; root.addWidget(nav)

        self.pages=QStackedWidget()
        self.command=CommandCenter(self)
        self.map_widget=self.command.map_widget
        self.positioning=PositioningSystemPage(self)
        self.fleet=FleetPage(self)
        self.library=LibraryPage()
        self.training=TrainingPage()
        self.system=SystemPage(self)
        for x in (self.command,self.positioning,self.fleet,self.library,self.training,self.system):
            scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setWidget(x)
            self.pages.addWidget(scroll)
        root.addWidget(self.pages,1)
        self.setCentralWidget(central)

        self.apply_style()
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1500)
        self.tick()

    def keyPressEvent(self,event):
        # Global fallback: never trap the operator in full-screen mode.
        if event.key() in (Qt.Key_Escape,Qt.Key_F11):
            try:
                if self.positioning.maximized:
                    self.positioning.exit_fullscreen()
                    event.accept(); return
                if event.key()==Qt.Key_F11:
                    self.pages.setCurrentIndex(1); self.positioning.toggle_maximize(); event.accept(); return
            except Exception:
                pass
        super().keyPressEvent(event)

    def apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background:#06141e; color:#dcebf2; font-family:Arial; }
        QFrame#header { background:#092333; border-bottom:1px solid #315e72; }
        QFrame#nav { background:#071c28; border-bottom:1px solid #244b5c; }
        QLabel#brandTitle { font-size:30px; font-weight:bold; letter-spacing:3px; }
        QLabel#brandSub { color:#91b4c3; font-size:11px; }
        QLabel#aiBadge { border:1px solid #397b98; border-radius:12px; padding:8px 14px; color:#9ee7ff; font-weight:bold; letter-spacing:1px; background:#0a293a; }
        QPushButton { background:#123648; color:#e2eff4; border:1px solid #3d7186; border-radius:9px; padding:8px 11px; font-weight:600; }
        QPushButton:hover { background:#17455b; }
        QPushButton#recordButton { background:#8b1d26; border-color:#d04450; font-weight:bold; }
        QFrame#panel, QFrame#mapPanel { background:#0b2635; border:1px solid #2f6074; border-radius:12px; }
        QFrame#fleetCard { background:#0d2939; border:1px solid #2e6b86; border-radius:9px; }
        QLabel#camera { background:#081923; border:1px solid #3e7186; color:#9abac8; font-size:14px; }
        QLabel#metric { background:#071923; border:1px solid #173646; padding:7px; font-weight:bold; }
        QLabel#sectionTitle { font-size:15px; font-weight:bold; color:#eaf5fa; }
        QLabel#pageTitle { font-size:21px; font-weight:bold; padding:6px; letter-spacing:1px; }
        QLabel#smallStatus { color:#86aab9; font-size:10px; }
        QLabel#mapPlaceholder { background:#071923; border:1px solid #21475a; color:#86aab9; font-size:15px; }
        QLabel#note { color:#8eb1c0; padding:12px; }
        QLineEdit, QTextEdit, QListWidget, QComboBox { background:#071923; border:1px solid #315e72; color:#e3eef3; padding:7px; }
        """)

    def tick(self):
        for i,b in enumerate(self.boats):
            b["heading"]=(b["heading"]+0.18+(i*0.03))%360
            # Small stable simulation movement until real telemetry is wired.
            b["port_rpm"]=max(0, b["port_rpm"] + (1 if int(time.time())%4==0 else -1 if int(time.time())%5==0 else 0))
            b["stbd_rpm"]=max(0, b["stbd_rpm"] + (1 if int(time.time())%5==0 else -1 if int(time.time())%6==0 else 0))
        self.command.refresh()
        self.positioning.refresh()
        self.append_logs()

    def boat_by_id(self, boat_id):
        return next((b for b in self.boats if b.get("id")==boat_id),None)

    def ensure_boats(self, ids):
        # Fleet profiles are preloaded; method kept for future live-discovered units.
        return

    def open_focus_by_id(self, boat_id):
        idx=next((i for i,b in enumerate(self.boats) if b.get("id")==boat_id),None)
        if idx is not None: self.open_focus(idx)

    def append_logs(self):
        now=datetime.now().isoformat(timespec="milliseconds")
        for boat_id, name in list(self.recording.items()):
            b=next((x for x in self.boats if x["id"]==boat_id),None)
            if not b: continue
            with (MISSIONS_DIR/(name+".jsonl")).open("a",encoding="utf-8") as f:
                f.write(json.dumps({"time":now,"boat":dict(b)},ensure_ascii=False)+"\n")

    def start_log(self, boat_id):
        name, ok = self.get_mission_name()
        if not ok: return
        safe="".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name) or "Maneuver"
        mission=f"{safe}_{boat_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.recording[boat_id]=mission
        self.library.reload()

    def get_mission_name(self):
        # Keep V3 dependency-light: use a small custom dialog instead of QInputDialog.
        d=QDialog(self); d.setWindowTitle("Log Maneuver")
        l=QVBoxLayout(d)
        l.addWidget(QLabel("Maneuver name"))
        e=QLineEdit("Cast_Off"); l.addWidget(e)
        row=QHBoxLayout()
        okb=QPushButton("START LOG"); cb=QPushButton("CANCEL")
        row.addWidget(okb); row.addWidget(cb); l.addLayout(row)
        result={"ok":False}
        okb.clicked.connect(lambda:(result.update(ok=True),d.accept()))
        cb.clicked.connect(d.reject)
        d.exec_()
        return e.text().strip(), result["ok"]

    def stop_log(self, boat_id):
        self.recording.pop(boat_id,None)
        self.library.reload()

    def set_voice(self):
        self.voice_text=self.command.voice.text().strip() or "Awaiting command"
        QMessageBox.information(self,"AI Console",f"Simulation command received:\n{self.voice_text}")

    def estop(self):
        self.system_state="SIM E-STOP"
        for b in self.boats:
            b["port_rpm"]=0; b["stbd_rpm"]=0

    def reset_estop(self):
        self.system_state="READY"

    def open_focus(self, boat_index):
        d=FocusDialog(self,boat_index)
        d.exec_()


def refresh_desktop_shortcut():
    """Keep the desktop launcher name/path aligned with the running release."""
    try:
        desk=Path.home()/"Desktop"
        desk.mkdir(exist_ok=True)
        target=desk/f"Doctor Boat Control Marine Intelligence V{APP_VERSION}.desktop"
        content=("[Desktop Entry]\n"
                 "Version=1.0\nType=Application\n"
                 f"Name=Doctor Boat Control Marine Intelligence V{APP_VERSION}\n"
                 f"Comment=DR.BOAT AI Marine Control V{APP_VERSION}\n"
                 f"Exec={Path.home()}/.local/bin/drboat\n"
                 f"Icon={APP_DIR/'static/drboat_logo.png'}\n"
                 "Terminal=false\nCategories=Utility;\nStartupNotify=true\n")
        # remove obsolete Doctor Boat version launchers, leave unrelated DR-BOAT launcher untouched
        for old in desk.glob("Doctor Boat Control Marine Intelligence V*.desktop"):
            if old != target:
                try: old.unlink()
                except Exception: pass
        target.write_text(content,encoding='utf-8'); os.chmod(target,0o755)
    except Exception:
        pass

def main():
    refresh_desktop_shortcut()
    app=QApplication(sys.argv)
    w=MainWindow()
    w.showMaximized()
    sys.exit(app.exec_())

if __name__=="__main__":
    main()
