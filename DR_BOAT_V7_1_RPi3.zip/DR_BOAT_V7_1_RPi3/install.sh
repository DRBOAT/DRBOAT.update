#!/bin/bash
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
APPDIR="$HOME/.local/share/drboat"
BINDIR="$HOME/.local/bin"
DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
[ -z "$DESKTOP_DIR" ] && DESKTOP_DIR="$HOME/Desktop"
LAUNCHER="$BINDIR/drboat"
DESKTOP_FILE="$DESKTOP_DIR/DR-BOAT.desktop"

echo "Installing DR.BOAT V7.1 for Raspberry Pi 3..."

# OpenPlotter images may contain an obsolete NodeSource Node 18 repository.
# Disable only that obsolete source if it exists so apt can update safely.
if [ -f /etc/apt/sources.list.d/openplotterNodejs.list ] && grep -q "node_18" /etc/apt/sources.list.d/openplotterNodejs.list; then
  echo "Disabling obsolete OpenPlotter NodeSource Node 18 repository..."
  sudo mv /etc/apt/sources.list.d/openplotterNodejs.list /etc/apt/sources.list.d/openplotterNodejs.list.disabled || true
fi
if [ -f /etc/apt/sources.list.d/nodesource.list ] && grep -q "node_18" /etc/apt/sources.list.d/nodesource.list; then
  sudo rm -f /etc/apt/sources.list.d/nodesource.list
fi

sudo apt-get update
sudo apt-get install -y python3 python3-pyqt5 xdotool gdal-bin python3-gdal

mkdir -p "$BINDIR" "$DESKTOP_DIR"

# Backup the current installation and preserve user maneuver mission logs.
BACKUP="$HOME/.local/share/drboat-pre-v7.1-backup"
rm -rf "$BACKUP"
if [ -d "$APPDIR" ]; then
  cp -a "$APPDIR" "$BACKUP"
fi

TMPDATA=""
if [ -d "$APPDIR/data" ]; then
  TMPDATA="$(mktemp -d)"
  mkdir -p "$TMPDATA/data"
  for d in missions route_history track_history chart_cache; do
    if [ -d "$APPDIR/data/$d" ]; then
      mkdir -p "$TMPDATA/data/$d"
      cp -a "$APPDIR/data/$d/." "$TMPDATA/data/$d/" || true
    fi
  done
  for f in positioning_settings.json fleet.json vessels.json; do
    if [ -f "$APPDIR/data/$f" ]; then
      cp -a "$APPDIR/data/$f" "$TMPDATA/data/$f" || true
    fi
  done
fi

rm -rf "$APPDIR"
mkdir -p "$APPDIR"
cp -a "$SRC/." "$APPDIR/"

if [ -n "$TMPDATA" ] && [ -d "$TMPDATA/data" ]; then
  mkdir -p "$APPDIR/data"
  cp -a "$TMPDATA/data/." "$APPDIR/data/" || true
  rm -rf "$TMPDATA"
fi

cat > "$LAUNCHER" <<EOF
#!/bin/bash
cd "$APPDIR"
exec python3 "$APPDIR/main.py"
EOF
chmod +x "$LAUNCHER"

rm -f "$DESKTOP_DIR/DoctorBot.desktop" \
      "$DESKTOP_DIR/DrBoat.desktop" \
      "$DESKTOP_DIR/DR-BOAT-V2.desktop" \
      "$DESKTOP_DIR/DR-BOAT.desktop"

cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=DR.BOAT V7.1
Comment=Intelligent Marine Control, Training and AI Center
Exec=$LAUNCHER
Icon=$APPDIR/static/drboat_logo.png
Terminal=false
Categories=Utility;
StartupNotify=true
EOF
chmod +x "$DESKTOP_FILE"
gio set "$DESKTOP_FILE" metadata::trusted true >/dev/null 2>&1 || true

echo
echo "DONE."
echo "DR.BOAT V7.1 installation complete."
echo "Your previous application backup is: $BACKUP"
echo "Your maneuver data has been preserved."
echo "Double-click the DR.BOAT V7.1 icon on the Desktop."
