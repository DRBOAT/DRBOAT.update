DR.BOAT V5.3 — Raspberry Pi 3 / OpenPlotter

V5.3 maneuver-simulator update highlights
- Choose 1, 2, 3 or 4 active tugs for each maneuver.
- Any tug can be assigned to any of six working stations.
- Each tug has three operating modes: STOP/FOLLOW, PULL and PUSH.
- PULL orders: Tight Line, Slow Tight Line, Half Tight Line, Full Tight Line.
- PUSH orders: Lean On, Mini Push, Slow Push, Half Power Push, Full Power Push.
- Tug clock position is relative to vessel heading: 12 o'clock is dead ahead.
- Center Lead Bow stays ahead of the bow fairlead and follows the vessel dynamically.
- Center Lead Aft follows the aft fairlead dynamically.
- STOP/FOLLOW keeps the tug in relative position without force on the target vessel.
- Tug forces generate vessel translation and rotation with damping/inertia.
- Simplified solid-quay collision boundaries stop the vessel passing through training berths.
- Live HDG, SOG and ROT are shown on the maneuver chart.
- Vessel movement is deliberately slower for training.
- Long station labels were removed from the chart; small securing-point markers remain.
- Larger training map with wheel zoom, mouse drag pan and double-click view reset.
- Current control is mouse-based; action/station structure is kept ready for future voice-command mapping.

Important
This is a simplified training simulator and is NOT a certified ship-handling model or navigation system.
The Mina Zayed-style background is a training representation only and is NOT FOR NAVIGATION.

=== V5.4 UPDATE ===
- Full Ahead own-ship reference speed tuned to approximately 10 kn in the training model.
- Compact ship propulsion and rudder controls moved onto the chart at the lower-right.
- Tug approach/clock response increased significantly.
- PULL and PUSH force response strengthened with progressive power levels.
- Side PUSH tugs now approach the hull/fender contact position before force is applied.
- START MANEUVER now opens a pre-maneuver technical Bollard Pull Assessment.
- Assessment assumes 50,000 t displacement and 50 t bollard pull per selected tug in this phase.
- Assessment shows vessel reference dimensions, windage area, underwater lateral area, wind/current forces, available BP, required BP and margin.
- Reference calculation uses drag-force form F = 0.5*rho*Cd*A*V^2 with a 20% operating margin.
- Training assessment only: not a certified or port-approved towage plan.
- Desktop launcher generation now points to the stable ~/.local/bin/drboat launcher to prevent repeat double-click failures.

=== V5.5 UPDATE — DOCTOR BOAT AI POSITIONING SYSTEM ===
- New top-level dashboard: DOCTOR BOAT AI POSITIONING SYSTEM.
- Independent metric UTM grid display inside DR.BOAT; OpenCPN is not required to open this page.
- Add Chart Directory selector for local marine-chart folders on Raspberry Pi.
- Chart index recognizes common OpenCPN chart-file families including BSB/KAP, S-57/ENC, MBTiles/SQLite and raster files.
- UTM own-ship display includes Zone, Easting, Northing and Heading.
- Position source cards: GNSS, IMU, INS, Log Speed, LiDAR, Vision, Radar and AI Positioning System.
- GNSS panel explicitly identifies GPS, Galileo, GLONASS and BeiDou.
- Final Position panel prepared for Easting, Northing, Lat/Lon, Heading, Speed, Confidence and active source.
- Chart-directory choice is stored in data/positioning_settings.json.
- Architecture is prepared for future physical-sensor feeds and sensor-fusion logic.

Chart renderer status
V5.5 indexes native OpenCPN chart directories without launching OpenCPN. The UTM display is fully independent.
Native decoding/drawing of encrypted/proprietary or vector BSB/S-57 chart content is not bundled in this dependency-light Raspberry Pi 3 build yet; the chart-file selection/API is in place for the next decoder integration step.

V5.6 POSITIONING UPDATE
- DR Boat AI Positioning System naming
- Larger map and compact sensor panel
- Zoom controls and mouse-wheel zoom
- Heading + speed on map
- Measure Distance: metres, NM and bearing
- Draw Route with sequential waypoints, leg summary and Route History
- Track recording and Track History
- Working WGS84 UTM to Latitude/Longitude conversion
- Maximize map mode
- CM93 directory detection/indexing

V6.0 VECTOR CHART UPDATE
- Built-in DR Boat Vector Chart Manager
- Native GeoJSON vector chart rendering on the UTM map
- S-57 ENC (.000/.001/.002/.s57/.enc) support through GDAL/ogr2ogr
- V6 installer installs gdal-bin automatically
- S-57 is converted locally to a cached GeoJSON layer and displayed inside DR Boat
- CM93 databases are detected and indexed; no false rendering claim is made because CM93 needs a dedicated decoder
- Route, Track, Measure Distance, vessel symbol and UTM grid remain overlaid above vector charts
- Existing positioning settings, route history and track history are preserved during V6 install


V7.0 FIRST-VECTOR-CHART UPDATE
- Actual S-57 extraction uses Python GDAL (python3-gdal), iterating every S-57 layer and rendering the resulting vector features inside DR Boat.
- Chart Manager now has LOAD SELECTED CHART and double-click loading.
- Pan by dragging the map in PAN mode; mouse wheel or buttons zoom.
- FIT CHART centers and fits the loaded vector chart.
- Built-in DR Boat demo vector chart proves the renderer immediately; it is explicitly TEST ONLY / NOT FOR NAVIGATION.
- CM93 remains detected/indexed but is not falsely claimed as decoded.
